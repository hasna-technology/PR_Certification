(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween51 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#CCCCCC","rgba(102,102,102,0.451)","rgba(102,102,102,0)"],[0.004,0.4,0.992],0,0,0,0,0,10.3).s().p("AgMBkQgxgDgkgaIgMgLQgKgJgGgKQgLgTAAgWQAAgMADgMQAEgKAGgJIAHgJQAIgKALgIQAUgOAYgHIAUgFIARgCIAMgBIAEAAQAQAAAPACQAOACANAFQAUAHAQALIADACQANAJAIAKQATAXAAAcQABAognAdIgCACQgQALgTAIQgcAKgiAAIgMAAg");
	this.shape.setTransform(-16,1.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#CCCCCC","rgba(102,102,102,0.451)","rgba(102,102,102,0)"],[0.004,0.4,0.992],1.3,4.7,0,1.3,4.7,10.3).s().p("AgKAjQgNgFgOgCQgPgCgQAAIgFAAIgLAAIgRACIgVAFQAFggAigYQAogdA4AAQA5AAAoAdIANALQgkAGgcATQgYASgKAWQgQgMgTgGg");
	this.shape_1.setTransform(-9.2,-11);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#CCCCCC","rgba(102,102,102,0.451)","rgba(102,102,102,0)"],[0.004,0.4,0.992],-0.9,0,0,-0.9,0,10.3).s().p("AhqBGIgNgKIgIgJIANABQAjAAAcgLQASgHAQgMIACgBQAmgcAAgoQAAgdgTgXIARACQAOACANAFQAWAHARANQApAdAAApQAAAognAdIgCABQgQAMgSAHQgcALgiAAQg5AAgogeg");
	this.shape_2.setTransform(-4.6,6.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["#CCCCCC","rgba(102,102,102,0.451)","rgba(102,102,102,0)"],[0.004,0.4,0.992],0.3,5.1,0,0.3,5.1,10.3).s().p("AhWAqIgSgBQgIgLgNgJIgDgBQAKgWAYgRQAcgUAkgGQAQgDARAAQA5AAAoAdQATAOAKAPQgPgCgQAAQgRAAgQADQgkAGgcAUIgCACQgPAAgOACQgPADgOAFQgNgEgOgDg");
	this.shape_3.setTransform(6.2,-7.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["#CCCCCC","rgba(102,102,102,0.451)","rgba(102,102,102,0)"],[0.004,0.4,0.992],-3.7,0,0,-3.7,0,10.3).s().p("AhfBbQATgHAQgMIACgCQAmgcAAgoQAAgpgogdQgSgNgVgIQAOgFAPgCQAOgDAPAAIAEAAQAQAAAPACQAlAGAcAVQApAdAAApQAAAognAdIgCABQgoAeg4AAQgfAAgbgJg");
	this.shape_4.setTransform(10.3,6.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["#CCCCCC","rgba(102,102,102,0.451)","rgba(102,102,102,0)"],[0.004,0.4,0.992],-1.8,0,0,-1.8,0,10.3).s().p("AAXAfQAAgpgngdQgdgVgmgGQgOgCgQAAIgFAAIADgCQAcgUAkgGQAQgDARAAQAQAAAOACQAmAGAcAVQApAdAAApQAAAqgpAdQgmAcg2ABQAlgdAAgog");
	this.shape_5.setTransform(17.9,3.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-29.8,-16.3,59.6,32.7);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FF0000","#FF9900"],[0,1],-4.1,0.1,4.4,0.1).s().p("Ag5AAIArghIAAAUIBIAAIAAAYIhIAAIAAAXg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.8,-3.4,11.6,6.9);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.094)").s().p("AjqGeQgCgCAAgFIAApKQAAg1ATggQASggAngLIGGhsQACgBACADQADADAAAEQAAAEgDAEQgCAEgCABImGBsQg9ARAABUIAAJLQAAAEgDAEQgCAEgCABIgCAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQgBgBAAAAgADmmbImGBsQglALgSAeQgSAfAAAzIAAJKIABAFQAAAAABAAQAAABABAAQAAAAABAAQAAAAABgBIACgCIACgFIAApLQAAhZBAgSIGGhsQAAAAAAAAQABAAAAgBQABAAAAAAQAAgBAAAAQACgDAAgDQAAAAAAgBQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAAAAAAAQgBgBAAAAQAAAAgBAAIAAAAg");
	this.shape.setTransform(24.9,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.196)").s().p("AjoGbIgBgFIAApKQAAgzASgfQASgeAlgLIGGhsQAAAAAAAAQABAAAAAAQABABAAAAQAAAAAAABQABAAAAAAQAAABABAAQAAABAAAAQAAABAAAAQAAADgCADQAAAAAAABQAAAAgBAAQAAABgBAAQAAAAAAAAImGBsQhAASAABZIAAJLIgCAFIgCACIgCABIgCgBgADmmWImGBsQgjAKgTAdQgQAdAAAxIAAJKIAAACIACAAIAAgBIABAAIAAgBIAApLQAAhdBDgTIGGhsIAAgBIABAAIAAgCIAAgBIgBAAIAAAAIAAAAg");
	this.shape_1.setTransform(24.9,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.294)").s().p("AjmGXIAAgBIAApLQAAgxAQgdQATgdAjgKIGGhsIAAAAIABAAIAAABIAAACIgBAAIAAABImGBsQhDATAABdIAAJLIAAACIgBAAIAAAAIgBAAIgBAAg");
	this.shape_2.setTransform(24.9,0);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.294)").s().p("AD0F9IAAAAIgBgCIAApAQAAhchHgNImfhMIgBAAIgBAAIAAgCIAAgBIABAAIABAAIGfBLQAlAIAUAbQARAaAAAxIAAJAIAAACIgBABIgBgCg");
	this.shape_3.setTransform(-23.4,1.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.196)").s().p("ADxGAQgBgCAAgDIAApAQAAhXhFgNImehMQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBgBAAIgBgFQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABAAIGeBMQAoAHATAdQATAcAAAzIAAJAQAAADgBACIgEABQAAAAgBgBQAAAAAAAAQgBAAAAgBQgBAAAAgBgAj1l9IAAABIAAACIABAAIABABIGeBMQBIANAABcIAAJAIAAACIABAAIAAABIACgBIAAgCIAApAQAAgwgSgbQgTgbgmgHImehMIgBAAg");
	this.shape_4.setTransform(-23.4,1.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.094)").s().p("AD0GHQgDgBgCgDQgDgEAAgEIAApAQAAhUhBgMImehMQgEAAgCgEQgCgEAAgEQAAgEACgDQACgCAEAAIGeBMQApAIAUAeQAUAeAAA0IAAJAQAAAEgCADQgCACgDAAIgBAAgAj3mAQAAAAAAAAQgBABAAAAQAAABAAAAQAAABAAABIABAFQABAAAAAAQAAABABAAQAAAAABABQAAAAABAAIGeBMQBFANAABXIAAJAQAAADABACQAAABABAAQAAAAABABQAAAAAAAAQABAAAAABIAEgBQABgCAAgDIAApAQAAgzgTgcQgTgdgogHImehMIgBAAQAAAAgBAAQAAAAAAAAQgBABAAAAQAAAAgBABg");
	this.shape_5.setTransform(-23.4,1.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-48.6,-41.6,97.2,83.2);


(lib.Tswween5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["rgba(255,255,255,0)","rgba(161,161,161,0.361)"],[0,1],-0.2,16.9,0,-0.2,16.9,31.2).s().p("AlUDQQACgiADgfIABgHQAFgcAFgaQAri/CRhiIERAAQBuBLA0CCQgnBdBMA2QAEAeABAhg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.1,-20.7,68.3,41.5);


(lib.temp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgGAaQgFgCgDgDQgDgDgCgFQgCgGAAgHQAAgFACgGQACgFADgEQADgDAFgCQAFgCAFAAIAJABIAKAEIAAAJIgBAAQgFgEgEgCQgEgCgFAAQgEAAgCACIgHADIgDAHQgCAEAAAFQAAAFACAFQABAEACACIAHAEQACACAEAAQAFAAAFgCQAEgCAEgDIABAAIAAAIIgEACIgEABIgFABIgGABQgEAAgGgCg");
	this.shape.setTransform(-7.9,-3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgFARQgEgBgCgCIgDgGQgCgDABgFQgBgDACgDIADgGQACgDAEgBQADgBACAAQAEAAADABQADABACADIADAFQABAEAAADQAAAFgBADIgDAGIgFADIgHABIgFgBgAgHgJQgEADAAAGQAAAHAEAEQADADAEAAQAGAAADgDQADgEAAgHQAAgGgDgDQgDgEgGAAQgEAAgDAEg");
	this.shape_1.setTransform(-12.5,-4.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgOAbIAAgFIAMAAIAAgjIgMAAIAAgGIAFAAIAEgBIADgCIABgEIAFAAIAAAwIALAAIAAAFg");
	this.shape_2.setTransform(-19.3,-3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgNAVQgFgGAAgPQAAgNAFgHQAEgHAJAAQAKAAAEAHQAFAHAAANQAAAOgFAIQgFAGgJAAQgJAAgEgHgAgFgTQgCAAgBADQgCADAAAEIAAAJIAAAJIACAHQABADACABQACACADAAQADAAADgCQACgBABgDIACgHIAAgJIAAgJIgCgHQgBgDgCAAQgDgCgDAAQgCAAgDACg");
	this.shape_3.setTransform(-24.1,-3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgOAbIAAgFIAMAAIAAgjIgMAAIAAgGIAFAAIAEgBIADgCIABgEIAFAAIAAAwIALAAIAAAFg");
	this.shape_4.setTransform(-28.7,-3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgRAcIAAgIIAHgHIAHgGIAJgKQACgEAAgFQAAgEgCgCQgDgCgEgBIgHACQgEABgEADIAAAAIAAgIIAHgCIAIgBQAHAAAFADQAFAEAAAHIgBAGIgCAFIgDAEIgFAEIgHAHIgIAHIAcAAIAAAHg");
	this.shape_5.setTransform(-19.3,-3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgKAbIgHgCIAAgIIABAAIAHADIAIACIAEgBIAEgCIADgDIABgGIgBgEIgDgEIgEgBIgEgBIgDAAIAAgEIACAAQAFgBADgCQADgCAAgEIAAgEIgDgCIgDgBIgDgBIgHACQgEABgEACIAAAAIAAgIIAHgCIAIgBIAGAAIAFADQADABABADQACADAAADQAAAEgDADQgEAEgEABIAAABIAEAAIAEACIADAEIABAGIgBAHIgEAFQgDACgEACIgHABIgJgBg");
	this.shape_6.setTransform(-19.4,-3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAFAbIAAgPIgYAAIAAgIIAZgeIAGAAIAAAgIAIAAIAAAGIgIAAIAAAPgAgPAGIAUAAIAAgYg");
	this.shape_7.setTransform(-19.4,-3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgKAbIgHgDIAAgHIABAAIAHADIAIABIADgBQADAAACgCIACgEIABgEIgBgGIgCgCIgFgCIgFAAIgGAAIgGABIAAgbIAgAAIAAAGIgZAAIAAAOIAEAAIADAAIAHAAIAFADQAEACABADQABACAAAGIgBAHIgEAFIgGAFIgHABIgJgBg");
	this.shape_8.setTransform(-19.3,-2.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgGAbIgGgEQgCgDgCgFQgCgFAAgGQAAgHACgGQABgFADgFQAEgEAEgCQAEgCAHAAIAEAAIADABIAAAHIgBAAIgCgBIgFgBQgGAAgFAFQgFAFgBAJIAHgEIAGgBIAFABIAGADQADACABACQACAEAAAEQAAAJgFAFQgGAFgHAAIgHgBgAgFAAIgGABIAAACIAAACIABAJIAEAFIADADIAEAAQAFAAADgDQADgDAAgGIgBgGIgEgEQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAIgEgBIgFABg");
	this.shape_9.setTransform(-19.3,-3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgNAbIAaguIgfAAIAAgHIAlAAIAAAIIgYAtg");
	this.shape_10.setTransform(-19.3,-3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgNAYQgFgFAAgHQAAgEACgEQADgDAFgCQgFgCgCgDQgCgDAAgEQAAgGAFgEQAFgEAHAAQAIAAAFAEQAFAEAAAGQAAADgDAEQgCADgEACIAAABQAFABACADQADADAAAFQAAAHgFAFQgGAEgIAAQgIAAgFgEgAgJAFQgCADAAAEQAAAFADADQAEADAEAAQAFAAADgDQAEgCAAgFQAAgDgCgCIgGgFIgDgBIgFgCQgDACgCADgAgHgUQgDADAAADQAAABAAAAQAAABABABQAAAAAAABQAAAAABABIAEADIAEACIAEACIAFgFIABgGQAAgEgDgCQgDgDgEAAQgEAAgDACg");
	this.shape_11.setTransform(-19.4,-3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgKAcIgDgBIAAgHIADACIAFAAQAHAAAEgFQAFgFABgIQgEACgDABIgFAAIgGAAIgGgCIgFgGQgBgDAAgFQAAgHAFgGQAGgFAHAAIAHABIAGAEQADADABAEQACAFAAAIQAAAGgBAFQgCAHgDADQgEAEgFADQgEACgGAAIgEAAgAgIgSQgDADAAAGIABAGIAEADQAAAAABAAQAAAAAAABQABAAAAAAQABAAAAAAIADAAIAGAAIAGgCIAAgBIAAgCIgBgJQgCgDgCgCQAAAAgBgBQAAAAAAgBQgBAAAAAAQgBAAAAAAIgEgBQgFAAgDADg");
	this.shape_12.setTransform(-19.4,-3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgOAbIAAgFIAMAAIAAgjIgMAAIAAgGIAFAAIAEgBIADgCIABgEIAFAAIAAAwIALAAIAAAFg");
	this.shape_13.setTransform(-28.7,-3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4,p:{x:-28.7}},{t:this.shape_3,p:{x:-24.1}},{t:this.shape_2,p:{x:-19.3}},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2,p:{x:-28.7}},{t:this.shape_3,p:{x:-24.1}},{t:this.shape_5},{t:this.shape_1},{t:this.shape}]},20).to({state:[{t:this.shape_2,p:{x:-28.7}},{t:this.shape_3,p:{x:-24.1}},{t:this.shape_6},{t:this.shape_1},{t:this.shape}]},20).to({state:[{t:this.shape_2,p:{x:-28.7}},{t:this.shape_3,p:{x:-24.1}},{t:this.shape_7},{t:this.shape_1},{t:this.shape}]},20).to({state:[{t:this.shape_2,p:{x:-28.7}},{t:this.shape_3,p:{x:-24.1}},{t:this.shape_8},{t:this.shape_1},{t:this.shape}]},20).to({state:[{t:this.shape_2,p:{x:-28.7}},{t:this.shape_3,p:{x:-24.1}},{t:this.shape_9},{t:this.shape_1},{t:this.shape}]},20).to({state:[{t:this.shape_2,p:{x:-28.7}},{t:this.shape_3,p:{x:-24.1}},{t:this.shape_10},{t:this.shape_1},{t:this.shape}]},20).to({state:[{t:this.shape_2,p:{x:-28.7}},{t:this.shape_3,p:{x:-24.1}},{t:this.shape_11},{t:this.shape_1},{t:this.shape}]},20).to({state:[{t:this.shape_2,p:{x:-28.7}},{t:this.shape_3,p:{x:-24.1}},{t:this.shape_12},{t:this.shape_1},{t:this.shape}]},20).to({state:[{t:this.shape_4,p:{x:-28.7}},{t:this.shape_2,p:{x:-24}},{t:this.shape_3,p:{x:-19.4}},{t:this.shape_1},{t:this.shape}]},20).to({state:[{t:this.shape_13},{t:this.shape_4,p:{x:-24}},{t:this.shape_2,p:{x:-19.3}},{t:this.shape_1},{t:this.shape}]},20).to({state:[{t:this.shape_4,p:{x:-28.7}},{t:this.shape_2,p:{x:-24}},{t:this.shape_5},{t:this.shape_1},{t:this.shape}]},20).wait(21));

	// Layer 3
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgTgaQAKgCAJgEAgaguQAKgCAJgEAghhCQAKgCAJgDAgohWQAKgCAJgDAgvhpQAKgCAJgEAAIA0QAKgCAJgEAAPBIQAKgCAJgDAAWBcQAKgCAJgEAgFANQAJgDAJgDAABAhQAKgDAJgDAgMgGQAKgDAIgDAAdBwQAKgCAJgE");
	this.shape_14.setTransform(-4.7,-11.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1,1,1,3,true).p("AhAgBQBAAGBCgG");
	this.shape_15.setTransform(6.9,18.7,0.3,0.3,-19.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(1,1,1,3,true).p("AhAgBQBAAGBCgG");
	this.shape_16.setTransform(1.5,3.4,0.3,0.3,-19.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(1,1,1,3,true).p("AhAgBQBAAGBCgG");
	this.shape_17.setTransform(0.7,1.2,0.3,0.3,-19.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgTAAQATABAUgB");
	this.shape_18.setTransform(-8.2,-24.1,0.999,0.999,-19.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14}]}).wait(241));

	// Layer 4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_1 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_2 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_3 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_4 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_5 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_6 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_7 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_8 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_9 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_10 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_11 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_12 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_13 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_14 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_15 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_16 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_17 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_18 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_19 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_20 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_21 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_22 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_23 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_24 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_25 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_26 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_27 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_28 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_29 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_30 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_31 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_32 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_33 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_34 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_35 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_36 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_37 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_38 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_39 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_40 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_41 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_42 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_43 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_44 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_45 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_46 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_47 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_48 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_49 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_50 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_51 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_52 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_53 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_54 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_55 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_56 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_57 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_58 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_59 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_60 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_61 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_62 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_63 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_64 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_65 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_66 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_67 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_68 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_69 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_70 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_71 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_72 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_73 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_74 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_75 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_76 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_77 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_78 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_79 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_80 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_81 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_82 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_83 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_84 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_85 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_86 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_87 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_88 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_89 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_90 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_91 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_92 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_93 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_94 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_95 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_96 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_97 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_98 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_99 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_100 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_101 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_102 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_103 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_104 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_105 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_106 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_107 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_108 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_109 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_110 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_111 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_112 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_113 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_114 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_115 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_116 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_117 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_118 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_119 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_120 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_121 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_122 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_123 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_124 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_125 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_126 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_127 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_128 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_129 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_130 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_131 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_132 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_133 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_134 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_135 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_136 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_137 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_138 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_139 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_140 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_141 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_142 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_143 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_144 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_145 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_146 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_147 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_148 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_149 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_150 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_151 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_152 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_153 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_154 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_155 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_156 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_157 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_158 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_159 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_160 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_161 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_162 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_163 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_164 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_165 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_166 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_167 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_168 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_169 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_170 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_171 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_172 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_173 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_174 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_175 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_176 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_177 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_178 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_179 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_180 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_181 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_182 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_183 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_184 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_185 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_186 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_187 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_188 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_189 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_190 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_191 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_192 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_193 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_194 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_195 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_196 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_197 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_198 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_199 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_200 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_201 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_202 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_203 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_204 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_205 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_206 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_207 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_208 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_209 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_210 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_211 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_212 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_213 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_214 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_215 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_216 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_217 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_218 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_219 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_220 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_221 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_222 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_223 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_224 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_225 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_226 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_227 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_228 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_229 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_230 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_231 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_232 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_233 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_234 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_235 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_236 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_237 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_238 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_239 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");
	var mask_graphics_240 = new cjs.Graphics().p("AhtkNQAKgIAOgBIDDIkIgYAJg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:8,y:21.3}).wait(1).to({graphics:mask_graphics_1,x:8,y:21.3}).wait(1).to({graphics:mask_graphics_2,x:8,y:21.2}).wait(1).to({graphics:mask_graphics_3,x:7.9,y:21.1}).wait(1).to({graphics:mask_graphics_4,x:7.9,y:21}).wait(1).to({graphics:mask_graphics_5,x:7.9,y:21}).wait(1).to({graphics:mask_graphics_6,x:7.9,y:20.9}).wait(1).to({graphics:mask_graphics_7,x:7.8,y:20.8}).wait(1).to({graphics:mask_graphics_8,x:7.8,y:20.7}).wait(1).to({graphics:mask_graphics_9,x:7.8,y:20.7}).wait(1).to({graphics:mask_graphics_10,x:7.8,y:20.6}).wait(1).to({graphics:mask_graphics_11,x:7.7,y:20.5}).wait(1).to({graphics:mask_graphics_12,x:7.7,y:20.5}).wait(1).to({graphics:mask_graphics_13,x:7.7,y:20.4}).wait(1).to({graphics:mask_graphics_14,x:7.7,y:20.3}).wait(1).to({graphics:mask_graphics_15,x:7.6,y:20.2}).wait(1).to({graphics:mask_graphics_16,x:7.6,y:20.2}).wait(1).to({graphics:mask_graphics_17,x:7.6,y:20.1}).wait(1).to({graphics:mask_graphics_18,x:7.6,y:20}).wait(1).to({graphics:mask_graphics_19,x:7.5,y:20}).wait(1).to({graphics:mask_graphics_20,x:7.5,y:19.9}).wait(1).to({graphics:mask_graphics_21,x:7.5,y:19.8}).wait(1).to({graphics:mask_graphics_22,x:7.5,y:19.7}).wait(1).to({graphics:mask_graphics_23,x:7.4,y:19.7}).wait(1).to({graphics:mask_graphics_24,x:7.4,y:19.6}).wait(1).to({graphics:mask_graphics_25,x:7.4,y:19.5}).wait(1).to({graphics:mask_graphics_26,x:7.4,y:19.5}).wait(1).to({graphics:mask_graphics_27,x:7.3,y:19.4}).wait(1).to({graphics:mask_graphics_28,x:7.3,y:19.3}).wait(1).to({graphics:mask_graphics_29,x:7.3,y:19.2}).wait(1).to({graphics:mask_graphics_30,x:7.3,y:19.2}).wait(1).to({graphics:mask_graphics_31,x:7.2,y:19.1}).wait(1).to({graphics:mask_graphics_32,x:7.2,y:19}).wait(1).to({graphics:mask_graphics_33,x:7.2,y:19}).wait(1).to({graphics:mask_graphics_34,x:7.2,y:18.9}).wait(1).to({graphics:mask_graphics_35,x:7.1,y:18.8}).wait(1).to({graphics:mask_graphics_36,x:7.1,y:18.7}).wait(1).to({graphics:mask_graphics_37,x:7.1,y:18.7}).wait(1).to({graphics:mask_graphics_38,x:7.1,y:18.6}).wait(1).to({graphics:mask_graphics_39,x:7,y:18.5}).wait(1).to({graphics:mask_graphics_40,x:7,y:18.4}).wait(1).to({graphics:mask_graphics_41,x:7,y:18.4}).wait(1).to({graphics:mask_graphics_42,x:7,y:18.3}).wait(1).to({graphics:mask_graphics_43,x:6.9,y:18.2}).wait(1).to({graphics:mask_graphics_44,x:6.9,y:18.2}).wait(1).to({graphics:mask_graphics_45,x:6.9,y:18.1}).wait(1).to({graphics:mask_graphics_46,x:6.9,y:18}).wait(1).to({graphics:mask_graphics_47,x:6.8,y:17.9}).wait(1).to({graphics:mask_graphics_48,x:6.8,y:17.9}).wait(1).to({graphics:mask_graphics_49,x:6.8,y:17.8}).wait(1).to({graphics:mask_graphics_50,x:6.8,y:17.7}).wait(1).to({graphics:mask_graphics_51,x:6.7,y:17.7}).wait(1).to({graphics:mask_graphics_52,x:6.7,y:17.6}).wait(1).to({graphics:mask_graphics_53,x:6.7,y:17.5}).wait(1).to({graphics:mask_graphics_54,x:6.7,y:17.4}).wait(1).to({graphics:mask_graphics_55,x:6.6,y:17.4}).wait(1).to({graphics:mask_graphics_56,x:6.6,y:17.3}).wait(1).to({graphics:mask_graphics_57,x:6.6,y:17.2}).wait(1).to({graphics:mask_graphics_58,x:6.6,y:17.2}).wait(1).to({graphics:mask_graphics_59,x:6.5,y:17.1}).wait(1).to({graphics:mask_graphics_60,x:6.5,y:17}).wait(1).to({graphics:mask_graphics_61,x:6.5,y:16.9}).wait(1).to({graphics:mask_graphics_62,x:6.5,y:16.9}).wait(1).to({graphics:mask_graphics_63,x:6.4,y:16.8}).wait(1).to({graphics:mask_graphics_64,x:6.4,y:16.7}).wait(1).to({graphics:mask_graphics_65,x:6.4,y:16.7}).wait(1).to({graphics:mask_graphics_66,x:6.4,y:16.6}).wait(1).to({graphics:mask_graphics_67,x:6.3,y:16.5}).wait(1).to({graphics:mask_graphics_68,x:6.3,y:16.4}).wait(1).to({graphics:mask_graphics_69,x:6.3,y:16.4}).wait(1).to({graphics:mask_graphics_70,x:6.3,y:16.3}).wait(1).to({graphics:mask_graphics_71,x:6.2,y:16.2}).wait(1).to({graphics:mask_graphics_72,x:6.2,y:16.1}).wait(1).to({graphics:mask_graphics_73,x:6.2,y:16.1}).wait(1).to({graphics:mask_graphics_74,x:6.2,y:16}).wait(1).to({graphics:mask_graphics_75,x:6.1,y:15.9}).wait(1).to({graphics:mask_graphics_76,x:6.1,y:15.9}).wait(1).to({graphics:mask_graphics_77,x:6.1,y:15.8}).wait(1).to({graphics:mask_graphics_78,x:6.1,y:15.7}).wait(1).to({graphics:mask_graphics_79,x:6,y:15.6}).wait(1).to({graphics:mask_graphics_80,x:6,y:15.6}).wait(1).to({graphics:mask_graphics_81,x:6,y:15.5}).wait(1).to({graphics:mask_graphics_82,x:6,y:15.4}).wait(1).to({graphics:mask_graphics_83,x:5.9,y:15.4}).wait(1).to({graphics:mask_graphics_84,x:5.9,y:15.3}).wait(1).to({graphics:mask_graphics_85,x:5.9,y:15.2}).wait(1).to({graphics:mask_graphics_86,x:5.9,y:15.1}).wait(1).to({graphics:mask_graphics_87,x:5.8,y:15.1}).wait(1).to({graphics:mask_graphics_88,x:5.8,y:15}).wait(1).to({graphics:mask_graphics_89,x:5.8,y:14.9}).wait(1).to({graphics:mask_graphics_90,x:5.8,y:14.9}).wait(1).to({graphics:mask_graphics_91,x:5.7,y:14.8}).wait(1).to({graphics:mask_graphics_92,x:5.7,y:14.7}).wait(1).to({graphics:mask_graphics_93,x:5.7,y:14.6}).wait(1).to({graphics:mask_graphics_94,x:5.7,y:14.6}).wait(1).to({graphics:mask_graphics_95,x:5.6,y:14.5}).wait(1).to({graphics:mask_graphics_96,x:5.6,y:14.4}).wait(1).to({graphics:mask_graphics_97,x:5.6,y:14.4}).wait(1).to({graphics:mask_graphics_98,x:5.6,y:14.3}).wait(1).to({graphics:mask_graphics_99,x:5.5,y:14.2}).wait(1).to({graphics:mask_graphics_100,x:5.5,y:14.1}).wait(1).to({graphics:mask_graphics_101,x:5.5,y:14.1}).wait(1).to({graphics:mask_graphics_102,x:5.5,y:14}).wait(1).to({graphics:mask_graphics_103,x:5.4,y:13.9}).wait(1).to({graphics:mask_graphics_104,x:5.4,y:13.8}).wait(1).to({graphics:mask_graphics_105,x:5.4,y:13.8}).wait(1).to({graphics:mask_graphics_106,x:5.4,y:13.7}).wait(1).to({graphics:mask_graphics_107,x:5.3,y:13.6}).wait(1).to({graphics:mask_graphics_108,x:5.3,y:13.6}).wait(1).to({graphics:mask_graphics_109,x:5.3,y:13.5}).wait(1).to({graphics:mask_graphics_110,x:5.3,y:13.4}).wait(1).to({graphics:mask_graphics_111,x:5.2,y:13.3}).wait(1).to({graphics:mask_graphics_112,x:5.2,y:13.3}).wait(1).to({graphics:mask_graphics_113,x:5.2,y:13.2}).wait(1).to({graphics:mask_graphics_114,x:5.2,y:13.1}).wait(1).to({graphics:mask_graphics_115,x:5.1,y:13.1}).wait(1).to({graphics:mask_graphics_116,x:5.1,y:13}).wait(1).to({graphics:mask_graphics_117,x:5.1,y:12.9}).wait(1).to({graphics:mask_graphics_118,x:5.1,y:12.8}).wait(1).to({graphics:mask_graphics_119,x:5,y:12.8}).wait(1).to({graphics:mask_graphics_120,x:5,y:12.7}).wait(1).to({graphics:mask_graphics_121,x:5,y:12.6}).wait(1).to({graphics:mask_graphics_122,x:5,y:12.6}).wait(1).to({graphics:mask_graphics_123,x:5,y:12.5}).wait(1).to({graphics:mask_graphics_124,x:4.9,y:12.4}).wait(1).to({graphics:mask_graphics_125,x:4.9,y:12.3}).wait(1).to({graphics:mask_graphics_126,x:4.9,y:12.3}).wait(1).to({graphics:mask_graphics_127,x:4.9,y:12.2}).wait(1).to({graphics:mask_graphics_128,x:4.8,y:12.1}).wait(1).to({graphics:mask_graphics_129,x:4.8,y:12.1}).wait(1).to({graphics:mask_graphics_130,x:4.8,y:12}).wait(1).to({graphics:mask_graphics_131,x:4.8,y:11.9}).wait(1).to({graphics:mask_graphics_132,x:4.7,y:11.8}).wait(1).to({graphics:mask_graphics_133,x:4.7,y:11.8}).wait(1).to({graphics:mask_graphics_134,x:4.7,y:11.7}).wait(1).to({graphics:mask_graphics_135,x:4.7,y:11.6}).wait(1).to({graphics:mask_graphics_136,x:4.6,y:11.5}).wait(1).to({graphics:mask_graphics_137,x:4.6,y:11.5}).wait(1).to({graphics:mask_graphics_138,x:4.6,y:11.4}).wait(1).to({graphics:mask_graphics_139,x:4.6,y:11.3}).wait(1).to({graphics:mask_graphics_140,x:4.5,y:11.3}).wait(1).to({graphics:mask_graphics_141,x:4.5,y:11.2}).wait(1).to({graphics:mask_graphics_142,x:4.5,y:11.1}).wait(1).to({graphics:mask_graphics_143,x:4.5,y:11}).wait(1).to({graphics:mask_graphics_144,x:4.4,y:11}).wait(1).to({graphics:mask_graphics_145,x:4.4,y:10.9}).wait(1).to({graphics:mask_graphics_146,x:4.4,y:10.8}).wait(1).to({graphics:mask_graphics_147,x:4.4,y:10.8}).wait(1).to({graphics:mask_graphics_148,x:4.3,y:10.7}).wait(1).to({graphics:mask_graphics_149,x:4.3,y:10.6}).wait(1).to({graphics:mask_graphics_150,x:4.3,y:10.5}).wait(1).to({graphics:mask_graphics_151,x:4.3,y:10.5}).wait(1).to({graphics:mask_graphics_152,x:4.2,y:10.4}).wait(1).to({graphics:mask_graphics_153,x:4.2,y:10.3}).wait(1).to({graphics:mask_graphics_154,x:4.2,y:10.3}).wait(1).to({graphics:mask_graphics_155,x:4.2,y:10.2}).wait(1).to({graphics:mask_graphics_156,x:4.1,y:10.1}).wait(1).to({graphics:mask_graphics_157,x:4.1,y:10}).wait(1).to({graphics:mask_graphics_158,x:4.1,y:10}).wait(1).to({graphics:mask_graphics_159,x:4.1,y:9.9}).wait(1).to({graphics:mask_graphics_160,x:4,y:9.8}).wait(1).to({graphics:mask_graphics_161,x:4,y:9.8}).wait(1).to({graphics:mask_graphics_162,x:4,y:9.7}).wait(1).to({graphics:mask_graphics_163,x:4,y:9.6}).wait(1).to({graphics:mask_graphics_164,x:3.9,y:9.5}).wait(1).to({graphics:mask_graphics_165,x:3.9,y:9.5}).wait(1).to({graphics:mask_graphics_166,x:3.9,y:9.4}).wait(1).to({graphics:mask_graphics_167,x:3.9,y:9.3}).wait(1).to({graphics:mask_graphics_168,x:3.8,y:9.2}).wait(1).to({graphics:mask_graphics_169,x:3.8,y:9.2}).wait(1).to({graphics:mask_graphics_170,x:3.8,y:9.1}).wait(1).to({graphics:mask_graphics_171,x:3.8,y:9}).wait(1).to({graphics:mask_graphics_172,x:3.7,y:9}).wait(1).to({graphics:mask_graphics_173,x:3.7,y:8.9}).wait(1).to({graphics:mask_graphics_174,x:3.7,y:8.8}).wait(1).to({graphics:mask_graphics_175,x:3.7,y:8.7}).wait(1).to({graphics:mask_graphics_176,x:3.6,y:8.7}).wait(1).to({graphics:mask_graphics_177,x:3.6,y:8.6}).wait(1).to({graphics:mask_graphics_178,x:3.6,y:8.5}).wait(1).to({graphics:mask_graphics_179,x:3.6,y:8.5}).wait(1).to({graphics:mask_graphics_180,x:3.5,y:8.4}).wait(1).to({graphics:mask_graphics_181,x:3.5,y:8.3}).wait(1).to({graphics:mask_graphics_182,x:3.5,y:8.2}).wait(1).to({graphics:mask_graphics_183,x:3.5,y:8.2}).wait(1).to({graphics:mask_graphics_184,x:3.4,y:8.1}).wait(1).to({graphics:mask_graphics_185,x:3.4,y:8}).wait(1).to({graphics:mask_graphics_186,x:3.4,y:8}).wait(1).to({graphics:mask_graphics_187,x:3.4,y:7.9}).wait(1).to({graphics:mask_graphics_188,x:3.3,y:7.8}).wait(1).to({graphics:mask_graphics_189,x:3.3,y:7.7}).wait(1).to({graphics:mask_graphics_190,x:3.3,y:7.7}).wait(1).to({graphics:mask_graphics_191,x:3.3,y:7.6}).wait(1).to({graphics:mask_graphics_192,x:3.2,y:7.5}).wait(1).to({graphics:mask_graphics_193,x:3.2,y:7.5}).wait(1).to({graphics:mask_graphics_194,x:3.2,y:7.4}).wait(1).to({graphics:mask_graphics_195,x:3.2,y:7.3}).wait(1).to({graphics:mask_graphics_196,x:3.1,y:7.2}).wait(1).to({graphics:mask_graphics_197,x:3.1,y:7.2}).wait(1).to({graphics:mask_graphics_198,x:3.1,y:7.1}).wait(1).to({graphics:mask_graphics_199,x:3.1,y:7}).wait(1).to({graphics:mask_graphics_200,x:3,y:6.9}).wait(1).to({graphics:mask_graphics_201,x:3,y:6.9}).wait(1).to({graphics:mask_graphics_202,x:3,y:6.8}).wait(1).to({graphics:mask_graphics_203,x:3,y:6.7}).wait(1).to({graphics:mask_graphics_204,x:2.9,y:6.7}).wait(1).to({graphics:mask_graphics_205,x:2.9,y:6.6}).wait(1).to({graphics:mask_graphics_206,x:2.9,y:6.5}).wait(1).to({graphics:mask_graphics_207,x:2.9,y:6.4}).wait(1).to({graphics:mask_graphics_208,x:2.8,y:6.4}).wait(1).to({graphics:mask_graphics_209,x:2.8,y:6.3}).wait(1).to({graphics:mask_graphics_210,x:2.8,y:6.2}).wait(1).to({graphics:mask_graphics_211,x:2.8,y:6.2}).wait(1).to({graphics:mask_graphics_212,x:2.7,y:6.1}).wait(1).to({graphics:mask_graphics_213,x:2.7,y:6}).wait(1).to({graphics:mask_graphics_214,x:2.7,y:5.9}).wait(1).to({graphics:mask_graphics_215,x:2.7,y:5.9}).wait(1).to({graphics:mask_graphics_216,x:2.6,y:5.8}).wait(1).to({graphics:mask_graphics_217,x:2.6,y:5.7}).wait(1).to({graphics:mask_graphics_218,x:2.6,y:5.7}).wait(1).to({graphics:mask_graphics_219,x:2.6,y:5.6}).wait(1).to({graphics:mask_graphics_220,x:2.5,y:5.5}).wait(1).to({graphics:mask_graphics_221,x:2.5,y:5.4}).wait(1).to({graphics:mask_graphics_222,x:2.5,y:5.4}).wait(1).to({graphics:mask_graphics_223,x:2.5,y:5.3}).wait(1).to({graphics:mask_graphics_224,x:2.4,y:5.2}).wait(1).to({graphics:mask_graphics_225,x:2.4,y:5.2}).wait(1).to({graphics:mask_graphics_226,x:2.4,y:5.1}).wait(1).to({graphics:mask_graphics_227,x:2.4,y:5}).wait(1).to({graphics:mask_graphics_228,x:2.3,y:4.9}).wait(1).to({graphics:mask_graphics_229,x:2.3,y:4.9}).wait(1).to({graphics:mask_graphics_230,x:2.3,y:4.8}).wait(1).to({graphics:mask_graphics_231,x:2.3,y:4.7}).wait(1).to({graphics:mask_graphics_232,x:2.2,y:4.6}).wait(1).to({graphics:mask_graphics_233,x:2.2,y:4.6}).wait(1).to({graphics:mask_graphics_234,x:2.2,y:4.5}).wait(1).to({graphics:mask_graphics_235,x:2.2,y:4.4}).wait(1).to({graphics:mask_graphics_236,x:2.1,y:4.4}).wait(1).to({graphics:mask_graphics_237,x:2.1,y:4.3}).wait(1).to({graphics:mask_graphics_238,x:2.1,y:4.2}).wait(1).to({graphics:mask_graphics_239,x:2.1,y:4.1}).wait(1).to({graphics:mask_graphics_240,x:2,y:4.1}).wait(1));

	// Layer 2
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FF0000").s().p("ABaEMIghhdIgIgMIiUmqQAGgIAJACICWGqIACAOIAgBcQABAFgEACIgDAAQgBAAgBAAQAAAAgBAAQAAgBgBAAQAAgBAAAAg");
	this.shape_19.setTransform(1.6,3.6);

	var maskedShapeInstanceList = [this.shape_19];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_19).wait(241));

	// Layer 1
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.rf(["#F1F7FC","#BDCEE9","#E3EEF8"],[0.094,0.541,1],-0.1,-0.5,0,-0.1,-0.5,1.6).s().p("AgDAFQgDgCgBgDQAIABAHgGQABAJgHACIgBAAQgBAAAAAAQAAAAgBAAQAAAAgBgBQAAAAgBAAg");
	this.shape_20.setTransform(11.5,30.9,1,1,0,0,0,0.2,0.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.rf(["#F1F7FC","#BDCEE9","#E3EEF8"],[0.094,0.541,1],-0.2,-0.3,0,-0.2,-0.3,1.5).s().p("AgKAIQgFgBgDgCIAKgDIAEAGIgFAAIgBAAgAAIgEIALgDQgCAGgIAEg");
	this.shape_21.setTransform(7.4,19.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#C0D0EA").ss(1,1,1,3,true).p("Ah0khQAFAJAAAGQAAAAAAABQgBAHACADICeHBQABAFAHACQAHABAEALIAeBVQAGAPAJgEQAEgBABgGQABgFgDgGIgehUQgDgLAEgGQAEgFgCgFIifnAQgBgFgEgEQgBAAAAgBQgEgEgBgL");
	this.shape_22.setTransform(0.4,1.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["#BDCEE9","#F1F7FC","#E3EEF8"],[0,0.506,1],-1.4,1,2.6,-0.4).s().p("ABhEiIgehVQgEgLgHgBQgHgCgBgFIienBQgCgDABgHIAAgBQAAgGgFgJQAAAAAAABQABAAAAAAQABABAAAAQABAAAAAAQAJAEAIgDQAJgDADgIIACgEQABALAEAEIABABQAEAEABAFICfHAQACAFgEAFQgEAGADALIAeBUQADAGgBAFQgBAGgEABIgDABQgHAAgFgMg");
	this.shape_23.setTransform(0.4,1.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#C0D0EA").ss(1,1,1,3,true).p("AgMATQgFgDgCgGQgDgIAEgIQAEgIAIgDQAIgDAHAEQAIAEADAJQADAFgCAG");
	this.shape_24.setTransform(-10,-29.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.rf(["#F1F7FC","#BDCEE9","#E3EEF8"],[0.094,0.541,1],0,-0.8,0,0,-0.8,3.1).s().p("AgIATQgBAAAAAAQgBAAAAgBQgBAAAAAAQgBgBAAAAQgFgDgCgGQgDgIAEgIQAEgIAIgDQAIgDAHAEQAIAEADAIQADAGgCAFIgCAEQgDAIgIADIgIACQgEAAgEgDg");
	this.shape_25.setTransform(-10,-29.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20}]}).wait(241));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32.5,-32.5,45.7,65.1);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AgDAFQAEgFAEgGQgEAGgFAGIAAABIABgCg");
	this.shape.setTransform(75.6,20);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(204,204,204,0.161)").s().p("ABDD3QhJAAhGhNIAGgBQBDBJBGAAIAAAAQA7AJAbgdIAAAAQAfgcgEhCIAAjuIAAgBQgKiKh0AHIjYAAQgHAAgFAGQgFAFAAAJQAAAIAFAGQAFAGAHAAIDZAAIABAAQBSgFAIBjIAADvQACAqgRASIAAABQgUAQgpgGIgCAAQgvgBgsgnIAGgBQApAjAsABIACAAQAoAGASgPQAPgSgCgnIAAgCIAAjtQgHhehOAFIgBAAIjZAAQgJAAgGgHQgGgIAAgKQAAgLAGgHQAGgHAJAAIDYAAQB4gIAKCPIAAACIAADuQAEBFggAdQgWAXgpAAQgMAAgOgCg");
	this.shape_1.setTransform(60.9,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(204,204,204,0.329)").s().p("ABDDyIgBAAQhGAAhDhJIAGAAQBABEBDAAIABAAQA4AIAagbIABAAQAdgbgEg+IAAgBIAAjvQgKiFhvAHIjYAAQgGAAgEAEQgDAEAAAHQAAAGADAFQAEAEAGAAIDZAAQBXgFAHBoIAADvQADAsgSAUIgBABQgVASgrgHIAAAAIgCAAIAAAAQgygBgvgrIAGgBQAsAnAvABIADAAQApAGATgQIABgBQAQgSgCgqIAAjvQgHhjhTAFIgBAAIjYAAQgIAAgFgGQgEgGAAgIQAAgJAEgFQAFgGAIAAIDYAAQB0gHAKCKIAAABIAADuQADBCgeAcIgBAAQgUAWgnAAQgMAAgOgCg");
	this.shape_2.setTransform(60.9,0);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(204,204,204,0.498)").s().p("ABEDtIgBAAQhDAAhBhEIAGgBQA9BABBAAIABAAQA2AIAZgZIABgBQAbgZgEg8IAAgBIAAjuQgJiBhrAHIgBAAIjYAAQgDAAgDADIAAAAQgCADAAAEQAAAEACADIAAAAQADADADAAIDaAAQBagFAIBsIAAABIAADuQADAwgUAUIgBACQgWATgtgHIgBAAIgBAAQg1gBgxgvIAGgBQAuArAyABIABAAIABAAIABAAQArAHAUgSIABgBQASgUgCgsIAAjvQgHhohXAFIjaAAQgFAAgEgEQgEgFAAgGQAAgHAEgEQAEgEAFAAIDYAAQBwgHAKCFIAADvIAAABQADA+gcAbIgBAAQgUAVglAAQgMAAgNgCg");
	this.shape_3.setTransform(60.9,0);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(204,204,204,0.831)").s().p("ABFDjIgCgBQg+AAg6g8IAMgBQA0AzA4AAIABAAQAwAIAWgVIACgCQAVgWgCgxIAAjuIAAgCQgJhxhfAFIjZAAIgDgBIAAAAIgBgEIABgDIAAAAQAAAAABgBQAAAAAAAAQABAAAAAAQABgBAAAAIDYAAIABAAQBngGAJB7IAAABIAADtIAAACQADA4gZAZIgBABQgSASgiAAQgLAAgMgCgACPDNIgBACIABgBQAGgGAEgIQgEAHgGAGg");
	this.shape_4.setTransform(60.9,0.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(204,204,204,0.663)").s().p("ABEDoIgBgBQhBAAg9hAIAGgBQA6A8A+AAIACABQAzAHAYgXIABgBQAZgZgDg4IAAgCIAAjtIAAgBQgJh7hnAGIgBAAIjYAAQAAAAgBABQAAAAgBAAQAAAAAAAAQgBABAAAAIAAAAIgBADIABAEIAAAAIADABIDZAAQBfgFAJBxIAAACIAADuQACAxgVAWIgCACQgWAVgwgIIgBAAQg4AAg0gzIAEgBIACAAQAxAvA1AAIABAAIABAAQAtAIAWgUIABgBQAUgVgDgvIAAjuIAAgBQgIhthaAFIjaAAQgDAAgDgCIAAgBQgCgDAAgEQAAgEACgDIAAAAQADgDADAAIDYAAIABAAQBrgGAJCAIAADuIAAABQAEA8gbAZIgBABQgTAUgkAAQgLAAgNgCg");
	this.shape_5.setTransform(60.9,0.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#CCCCCC").s().p("AAFAGQgFgGgEgGQAEAGAEAFIABACIAAgBg");
	this.shape_6.setTransform(-75.6,20);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(204,204,204,0.831)").s().p("AiODTIgBgBQgZgZADg4IAAgCIAAjtIAAgBQAJh7BnAGIDWAAIADACIABAAIABADIgBAEIgBAAIgDABIjXAAQhegFgIBxIAAACIAADuQgDAxAVAWIACACQAWAVAvgIIABAAQA0AAAwgsIAFAAIAIABQg3A1g5AAIgCABQgNACgKAAQgiAAgSgSgAiNDOIABABIgBgCQgGgGgEgHQAEAIAGAGg");
	this.shape_7.setTransform(-61,0.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(204,204,204,0.498)").s().p("AiTDaIgBAAQgcgbADg+IAAgBIAAjvQAKiFBvAHIDWAAQAFAAAEAEQAEAEAAAHQAAAGgEAFQgEAEgFAAIjYAAQhWgFgHBoIAADvQgDAsASAUIABABQAVASAqgHIABAAIABAAIAAAAQAtgBAsgkIAGABQguAogxABIgBAAQgtAHgVgTIgCgCQgTgUACgwIAAjuIAAgBQAIhsBaAFIDYAAQADAAADgDIAAAAQACgDAAgEQAAgEgCgDIAAAAQgDgDgDAAIjXAAQhqgHgKCBIAADuIAAABQgDA8AbAZIAAABQAZAZA2gIIABAAQA9AAA5g5IAGAAQg8A+hAAAIgBAAQgOACgLAAQglAAgTgVg");
	this.shape_8.setTransform(-61,0);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(204,204,204,0.663)").s().p("AiRDWIAAgBQgbgZADg8IAAgBIAAjuQAKiABqAGIDXAAQADAAADADIAAAAQACADAAAEQAAAEgCADIAAABQgDACgDAAIjYAAQhagFgIBtIAAABIAADuQgCAvATAVIACABQAVAUAtgIIABAAQAxAAAugoIAGABQgxAsg0AAIAAAAQgwAIgWgVIgCgCQgVgWADgxIAAjuIAAgCQAIhxBeAFIDYAAIADgBIAAAAIABgEIgBgDIAAAAIgDgCIjXAAQhmgGgJB7IAAABIAADtIAAACQgDA4AYAZIABABQAYAXAzgHIACgBQA6AAA2g1IAGABQg5A5g9AAIgBABQgNACgLAAQgkAAgTgUg");
	this.shape_9.setTransform(-61,0.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(204,204,204,0.329)").s().p("AiWDeIgBAAQgegcAEhCIAAjuIAAgBQAKiKBzAHIDWAAQAHAAAFAGQAFAFAAAJQAAAIgFAGQgFAGgHAAIjXAAIgBAAQhSgFgHBjIAADvQgCAqAQASIABABQATAQApgGIACAAQAqgBAoggIAHABQgsAkgtABIAAAAIgBAAIgBAAQgqAHgVgSIgBgBQgSgUADgsIAAjvQAHhoBWAFIDYAAQAFAAAEgEQAEgFAAgGQAAgHgEgEQgEgEgFAAIjWAAQhvgHgKCFIAADvIAAABQgDA+AcAbIABAAQAaAbA3gIIABAAQBAAAA8g+IAGABQhABChCAAIgBAAQgOACgMAAQgmAAgUgWg");
	this.shape_10.setTransform(-61,0);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(204,204,204,0.161)").s().p("AiZDiQgggdADhFIAAjuIAAgCQALiPB3AIIDWAAQAJAAAGAHQAGAHAAALQAAAKgGAIQgGAHgJAAIjXAAIgBAAQhOgFgHBeIAADtIAAACQgCAnAPASQATAPAmgGIADAAQAmgBAlgcIAHABQgoAggqABIgCAAQgpAGgTgQIgBgBQgQgSACgqIAAjvQAHhjBSAFIABAAIDXAAQAHAAAFgGQAFgGAAgIQAAgJgFgFQgFgGgHAAIjWAAQhzgHgKCKIAAABIAADuQgEBCAeAcIABAAQAaAdA6gJIABAAQBCAABAhCIAFABQhCBGhFAAQgOACgMAAQgpAAgVgXg");
	this.shape_11.setTransform(-61,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.3,-24.8,158.7,49.8);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("AgDgFIgBgBIAAAAQAFAGAEAHQgEgHgEgFg");
	this.shape.setTransform(75.4,1.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(204,204,204,0.161)").s().p("AB5AkQgGgdgSgPIAAAAQgbgdg6AJIgBAAQhCAAhABAIgGAAQBChFBGAAQA9gJAcAeQAUAQAGAggABPAkQgCgGgEgFQgTgPgoAGIgCAAQgfABgfATIgJAAQAjgYAkgBIACAAQApgGAUAQIAAABQAFAGAEAIg");
	this.shape_1.setTransform(66.3,-0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(204,204,204,0.831)").s().p("ABeAaQgFgPgJgKIgCgBQgWgUgwAHIgBAAQgwABgvAmIgPAAQA2gwA3gBIADAAQAzgIAYAYIABABQAMALAGAVgABTgBQAGAEAEAHQgEgHgGgFIgBgBIABACg");
	this.shape_2.setTransform(66.7,0.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(204,204,204,0.329)").s().p("AB0AhQgGgagQgNIgBgBQgagbg4AJIgBAAQg+AAg9A6IgHAAQBAhABCABIABAAQA6gJAbAcIAAABQASAPAGAcgABTAhQgEgIgFgGIAAAAQgUgRgpAGIgCABQgkAAgjAYIgJAAQAngdApAAIAAAAIABgBIABAAQArgFAUARIABABQAHAHAEAKg");
	this.shape_3.setTransform(66.4,0.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(204,204,204,0.663)").s().p("ABpAcQgGgUgMgMIgCgBQgYgXgzAHIgCABQg4AAg1AwIgHAAQA5g1A7AAIACgBQA1gIAaAaIAAABQAOAMAGAXgABbAcQgFgMgHgJIgCgBQgWgTgtAIIgBAAIAAAAQgsAAgsAhIgIAAQAwgmAwAAIABAAQAvgIAXAUIABACQAJAJAGAPg");
	this.shape_4.setTransform(66.6,0.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(204,204,204,0.498)").s().p("ABuAfQgGgXgOgNIAAgBQgagZg2AIIgBAAQg7AAg5A2IgHAAQA9g7A+AAIABAAQA4gIAaAbIABAAQAQAOAGAagABXAfQgEgLgHgHIgBgBQgUgRgrAGIgBAAIgBAAIAAAAQgpABgnAdIgIAAQAsghAsgBIAAAAIABAAQAtgHAWASIACACQAHAIAFANg");
	this.shape_5.setTransform(66.5,0.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("ABNAlQgDgIgFgGQgSgOgjAGIgEAAQggABggAVIhNAAQBEhHBHAAQBAgJAeAfQATARAHAgg");
	this.shape_6.setTransform(66.3,0);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#CCCCCC").s().p("AAFgGIABAAIgCABQgEAFgEAHQADgHAGgGg");
	this.shape_7.setTransform(-75.8,1.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(204,204,204,0.831)").s().p("ABTAXQgrgggsgBIgBAAQgwgHgVATIgCACQgIAIgEALIgKAAQAGgRAKgJIABgBQAYgYAzAIIADAAQAzABAyAqgAhPAAQgGAGgEAHQAEgHAFgFIACgBIgBAAg");
	this.shape_8.setTransform(-67.3,0.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(204,204,204,0.161)").s().p("ABzAhQg9g6g+AAIgBAAQg6gJgaAdIgBAAQgQAOgHAYIgDAAQAGgbARgPQAcgeA9AJQBCAABAA/gAArAhQgbgNgagBIgCAAQgngGgSAPIgEAFIgFAAIAGgIIAAgBQAUgQApAGIABAAQAgABAfASg");
	this.shape_9.setTransform(-66.9,-0.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(204,204,204,0.329)").s().p("ABuAfQg6g1g7AAIgBAAQg3gJgaAbIgBABQgOAMgGAWIgFAAQAGgZAQgNIABgBQAagcA6AJIABAAQA/gBA8A7gAA3AfQgggTgfAAIgCgBQgpgGgTARIgBAAIgGAJIgFAAQAEgHAEgFIABgBQAVgSAqAGIABAAIABABIAAAAQAkAAAkAYg");
	this.shape_10.setTransform(-67,-0.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(204,204,204,0.663)").s().p("ABhAaQgygrg0AAIgCgBQgzgHgYAXIgBABQgKAKgGARIgFAAQAGgUANgKIAAgBQAZgaA2AIIABABQA3AAA3AwgABKAaQgngcgpAAIgBAAQgtgIgVATIgCABQgGAHgEAJIgEAAQAEgLAHgIIACgCQAWgUAwAIIAAAAQAtAAArAhg");
	this.shape_11.setTransform(-67.2,0.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(204,204,204,0.498)").s().p("ABnAcQg2gwg3AAIgCAAQg1gIgZAZIgBABQgMALgGATIgEAAQAFgWAPgMIAAAAQAbgbA2AIIACAAQA7AAA5A1gABAAcQgkgXgjgBIgBAAIAAAAIgBAAQgqgGgVARIgBABQgEAFgEAHIgFAAQAEgJAGgGIACgCQAUgSAuAHIABAAQApAAAnAcg");
	this.shape_12.setTransform(-67.1,0.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AAiAfQgVgJgUAAIgEgBQgjgFgRAOIAAABIg5AAQAHgXAPgNQAeggBAAKQA9AAA8A2IAEAEg");
	this.shape_13.setTransform(-67.2,-0.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.2,-3.7,158.5,7.4);


(lib.swTween51 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#CCCCCC","rgba(102,102,102,0.451)","rgba(102,102,102,0)"],[0.004,0.4,0.992],0,0,0,0,0,10.2).s().p("AAJBtQgcgFgegRIgLgHQgpgbgSgpIgGgNQgDgOAAgLQgBgXALgTQAHgLAJgIQAIgHAKgFIALgFQALgDAOgCQAYgCAYAFQAJACALAEIAPAHIALAFIAEADQAOAIALAJQAMAJAJAKQANAPAJATIACADQAGANACAOQAFAdgOAZQgUAjgwAFIgCABIgRABQgMAAgLgCg");
	this.shape.setTransform(-14.7,-6.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#CCCCCC","rgba(102,102,102,0.451)","rgba(102,102,102,0)"],[0.004,0.4,0.992],0,-1.6,0,0,-1.6,10.2).s().p("AAJBdQgdgFgdgRQgygdgUgtIgGgOIgDgMIAMAHQAdARAeAFQATACAUgCIADAAQAugFAVgjQAOgZgFgdIAOAKQALAJAJAKQAPARAJAUQAUAtgUAkQgVAjgvAFIgDABIgRABQgLAAgLgCg");
	this.shape_1.setTransform(-7.9,4.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#CCCCCC","rgba(102,102,102,0.451)","rgba(102,102,102,0)"],[0.004,0.4,0.992],-0.6,5,0,-0.6,5,10.2).s().p("AgVAbQgJgKgLgJQgLgIgOgIIgEgDIgLgFIgQgHQgKgEgKgCQAVgaApgEQAxgFAxAdQAxAcAUAsIAGAQQgigNgiAEQgeADgTAOQgIgTgOgPg");
	this.shape_2.setTransform(-2.9,-14.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["#CCCCCC","rgba(102,102,102,0.451)","rgba(102,102,102,0)"],[0.004,0.4,0.992],-1.6,4.1,0,-1.6,4.1,10.2).s().p("ABYA0QgPgJgPgFQgigNgiADIgDABQgNgHgNgFQgOgFgPgDQgJgJgMgKIgOgKQgCgOgGgNIgCgDQAUgPAdgDQAigDAiANQAPAFAPAJQAxAcAVAsQAJAWABATQgMgJgOgIg");
	this.shape_3.setTransform(8.5,-3.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["#CCCCCC","rgba(102,102,102,0.451)","rgba(102,102,102,0)"],[0.004,0.4,0.992],-1.7,-0.1,0,-1.7,-0.1,10.2).s().p("AhCBWQgbgQgTgVQAUADAUgCIACgBQAwgFAUgjQAUgjgTguQgJgUgPgRQAPADANAFQANAFANAHIAEACQAOAIALAKQAeAXAPAhQAUAtgVAkQgUAjgwAFIgCAAIgRACQgoAAgpgYg");
	this.shape_4.setTransform(4.2,8.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["#CCCCCC","rgba(102,102,102,0.451)","rgba(102,102,102,0)"],[0.004,0.4,0.992],-3.9,0,0,-3.9,0,10.2).s().p("AhVBYQAwgFAUgjQAUgkgTgtQgPghgegXQgLgKgOgIIgEgCIADAAQAjgEAiANQAPAFAOAJQAOAIAMAKQAdAXAPAhQAUAtgVAkQgUAkgyAFIgOABQgoAAgpgXg");
	this.shape_5.setTransform(16.2,10.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.6,-20.4,52.9,42.3);


(lib.swTween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AgPAQQgHgGAAgKQAAgJAHgGQAGgHAJAAQAJAAAHAHQAHAGAAAJQAAAKgHAGQgHAHgJAAQgJAAgGgHg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.3,-2.3,4.6,4.6);


(lib.swTween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.094)").s().p("AjqGeQgCgCAAgFIAApKQAAg1ATggQASggAngLIGGhsQACgBACADQADADAAAEQAAAEgDAEQgCAEgCABImGBsQg9ARAABUIAAJLQAAAEgDAEQgCAEgCABIgCAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQgBgBAAAAgADmmbImGBsQglALgSAeQgSAfAAAzIAAJKIABAFQAAAAABAAQAAABABAAQAAAAABAAQAAAAABgBIACgCIACgFIAApLQAAhZBAgSIGGhsQAAAAAAAAQABAAAAgBQABAAAAAAQAAgBAAAAQACgDAAgDQAAAAAAgBQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAAAAAAAQgBgBAAAAQAAAAgBAAIAAAAg");
	this.shape.setTransform(24.9,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.196)").s().p("AjoGbIgBgFIAApKQAAgzASgfQASgeAlgLIGGhsQAAAAAAAAQABAAAAAAQABABAAAAQAAAAAAABQABAAAAAAQAAABABAAQAAABAAAAQAAABAAAAQAAADgCADQAAAAAAABQAAAAgBAAQAAABgBAAQAAAAAAAAImGBsQhAASAABZIAAJLIgCAFIgCACIgCABIgCgBgADmmWImGBsQgjAKgTAdQgQAdAAAxIAAJKIAAACIACAAIAAgBIABAAIAAgBIAApLQAAhdBDgTIGGhsIAAgBIABAAIAAgCIAAgBIgBAAIAAAAIAAAAg");
	this.shape_1.setTransform(24.9,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.294)").s().p("AjmGXIAAgBIAApLQAAgxAQgdQATgdAjgKIGGhsIAAAAIABAAIAAABIAAACIgBAAIAAABImGBsQhDATAABdIAAJLIAAACIgBAAIAAAAIgBAAIgBAAg");
	this.shape_2.setTransform(24.9,0);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.294)").s().p("AD0F9IAAAAIgBgCIAApAQAAhchHgNImfhMIgBAAIgBAAIAAgCIAAgBIABAAIABAAIGfBLQAlAIAUAbQARAaAAAxIAAJAIAAACIgBABIgBgCg");
	this.shape_3.setTransform(-23.4,1.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.196)").s().p("ADxGAQgBgCAAgDIAApAQAAhXhFgNImehMQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBgBAAIgBgFQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABAAIGeBMQAoAHATAdQATAcAAAzIAAJAQAAADgBACIgEABQAAAAgBgBQAAAAAAAAQgBAAAAgBQgBAAAAgBgAj1l9IAAABIAAACIABAAIABABIGeBMQBIANAABcIAAJAIAAACIABAAIAAABIACgBIAAgCIAApAQAAgwgSgbQgTgbgmgHImehMIgBAAg");
	this.shape_4.setTransform(-23.4,1.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.094)").s().p("AD0GHQgDgBgCgDQgDgEAAgEIAApAQAAhUhBgMImehMQgEAAgCgEQgCgEAAgEQAAgEACgDQACgCAEAAIGeBMQApAIAUAeQAUAeAAA0IAAJAQAAAEgCADQgCACgDAAIgBAAgAj3mAQAAAAAAAAQgBABAAAAQAAABAAAAQAAABAAABIABAFQABAAAAAAQAAABABAAQAAAAABABQAAAAABAAIGeBMQBFANAABXIAAJAQAAADABACQAAABABAAQAAAAABABQAAAAAAAAQABAAAAABIAEgBQABgCAAgDIAApAQAAgzgTgcQgTgdgogHImehMIgBAAQAAAAgBAAQAAAAAAAAQgBABAAAAQAAAAgBABg");
	this.shape_5.setTransform(-23.4,1.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-48.6,-41.6,97.2,83.2);


(lib.sasaas = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#19191B","#255488","#9BBAD7","rgba(155,186,215,0)"],[0,0.596,0.941,1],0.4,10.2,0,0.4,1.2,9.1).s().p("AjvBPQhkgJAAgOIABgCQgWg+AqgtIAAgCQAAgOBegKQBegKCEABQCFgBBeAKQBZAKAFAMIAAAEQAgA1gLA2IAAACQAAAOhkAJQhkAKiOAAQiMAAhlgKg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#19191B","#255488","#9BBAD7","rgba(155,186,215,0)"],[0,0.596,0.941,1],0.5,8.9,0,0.5,0.4,9.8).s().p("AjvBPQhkgJAAgOIABgCQgWg+AqgtIAAgCQAAgOBegKQBegKCEABQCFgBBeAKQBZAKAFAMIAAAEQAgA1gLA2IAAACQAAAOhkAJQhkAKiOAAQiMAAhlgKg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#19191B","#255488","#9BBAD7","rgba(155,186,215,0)"],[0,0.596,0.941,1],0.6,7.4,0,0.6,-0.3,10.5).s().p("AjvBPQhkgJAAgOIABgCQgWg+AqgtIAAgCQAAgOBegKQBegKCEABQCFgBBeAKQBZAKAFAMIAAAEQAgA1gLA2IAAACQAAAOhkAJQhkAKiOAAQiMAAhlgKg");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["#19191B","#255488","#9BBAD7","rgba(155,186,215,0)"],[0,0.596,0.941,1],0.4,8.3,0,0.4,-0.2,9.8).s().p("AjvBPQhkgJAAgOIABgCQgWg+AqgtIAAgCQAAgOBegKQBegKCEABQCFgBBeAKQBZAKAFAMIAAAEQAgA1gLA2IAAACQAAAOhkAJQhkAKiOAAQiMAAhlgKg");

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["#19191B","#255488","#9BBAD7","rgba(155,186,215,0)"],[0,0.596,0.941,1],0.3,8.9,0,0.3,-0.1,9.1).s().p("AjvBPQhkgJAAgOIABgCQgWg+AqgtIAAgCQAAgOBegKQBegKCEABQCFgBBeAKQBZAKAFAMIAAAEQAgA1gLA2IAAACQAAAOhkAJQhkAKiOAAQiMAAhlgKg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.6,-8.9,69.4,17.9);


(lib.graphmovcopy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,204,255,0.502)").s().p("AlgA/QACgiAEgeIABgHQAEgcAFgaIKxAAIgdA+QAEAeACAhg");
	this.shape.setTransform(-138.6,113.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000066").ss(1,2,1,3,true).p("AisjEQAvgYAjgBQA7gBAxAZQAZAMAOAMIkOAAgAmiD4IgFgXIAakUQAhj1EjgKQAJAGgJAGQkcAIgdD4IgZDXQAEgcAGgaQAri/CRhiIERAAQBuBLA0CBICmjlIAkAXIilFhQADAfACAgIgSAfIAAAcIqGAAIAAgcIgSgfQACghAEgfIABgHADeAmQgTAwAJAlQAJAlAmAZAmQEXIKGAAAmiD4IKqAA");
	this.shape_1.setTransform(-132.1,94.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("rgba(255,255,255,0.353)").ss(0.4,2,1).p("AicCBQAOh8BQhAQBOhBCOgE");
	this.shape_2.setTransform(-155.4,77.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(102,102,102,0.851)").s().p("AlDAOIAAgbIKGAAIAAAbg");
	this.shape_3.setTransform(-139.8,124.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(153,153,153,0.851)").s().p("AlDAPIgSgdIKqAAIgSAdg");
	this.shape_4.setTransform(-139.8,121.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.851)").s().p("AmlDrQADghAEgfIAAgHQAEgcAGgaQArjACRhhIERAAQBuBLA0CBICnjlIAkAXIimFhQgmgagJgkQgDgNAAgNQAAgbANggQgNAgAAAbQAAANADANQAJAkAmAaQADAfACAggAjYi6IApgXQAwgYAigBQA7gBAyAZQAZAMANAMg");
	this.shape_5.setTransform(-131.8,96.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0000CC").s().p("AiwD+IAakUQAhj1EigJQAJAFgJAGQkbAJgdD3IgZDXIgBAHQgEAfgCAigAgxjJQhPBCgPB7QAPh7BPhCQBOhACOgEQiOAEhOBAg");
	this.shape_6.setTransform(-156.8,92);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.graphmovcopy2, new cjs.Rectangle(-175.7,62.9,87.4,63.7), null);


(lib.flamecopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFFF00","#FF9900","#255488","#9BBAD7","rgba(155,186,215,0)"],[0,0.282,0.635,0.941,1],0.4,10.2,0,0.4,1.2,9.1).s().p("AjvBPQhkgJAAgOIABgCQgWg+AqgtIAAgCQAAgOBegKQBegKCEABQCFgBBeAKQBZAKAFAMIAAAEQAgA1gLA2IAAACQAAAOhkAJQhkAKiOAAQiMAAhlgKg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#FFFF00","#FF9900","#255488","#9BBAD7","rgba(155,186,215,0)"],[0,0.282,0.635,0.941,1],0.6,10.1,0,0.6,0.4,9.8).s().p("AjvBPQhkgJAAgOIABgCQgWg+AqgtIAAgCQAAgOBegKQBegKCEABQCFgBBeAKQBZAKAFAMIAAAEQAgA1gLA2IAAACQAAAOhkAJQhkAKiOAAQiMAAhlgKg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#FFFF00","#FF9900","#255488","#9BBAD7","rgba(155,186,215,0)"],[0,0.282,0.635,0.941,1],0.8,10.1,0,0.8,-0.3,10.5).s().p("AjvBPQhkgJAAgOIABgCQgWg+AqgtIAAgCQAAgOBegKQBegKCEABQCFgBBeAKQBZAKAFAMIAAAEQAgA1gLA2IAAACQAAAOhkAJQhkAKiOAAQiMAAhlgKg");

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["#FFFF00","#FF9900","#255488","#9BBAD7","rgba(155,186,215,0)"],[0,0.282,0.635,0.941,1],0.6,9.5,0,0.6,-0.2,9.8).s().p("AjvBPQhkgJAAgOIABgCQgWg+AqgtIAAgCQAAgOBegKQBegKCEABQCFgBBeAKQBZAKAFAMIAAAEQAgA1gLA2IAAACQAAAOhkAJQhkAKiOAAQiMAAhlgKg");

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["#FFFF00","#FF9900","#255488","#9BBAD7","rgba(155,186,215,0)"],[0,0.282,0.635,0.941,1],0.3,8.9,0,0.3,-0.1,9.1).s().p("AjvBPQhkgJAAgOIABgCQgWg+AqgtIAAgCQAAgOBegKQBegKCEABQCFgBBeAKQBZAKAFAMIAAAEQAgA1gLA2IAAACQAAAOhkAJQhkAKiOAAQiMAAhlgKg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.6,-8.9,69.4,17.9);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,0.9,0.194,0.172);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(255,255,255,0.18)").ss(1,1,1).p("AhcAKIBLgRQANgDAMABIBVAM");
	this.shape.setTransform(0.2,4.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(0,153,255,0.431)").ss(0.5,1,1).p("ABig/IAABxQABAHgJAEIhKAUQgLADgJgDIhZgPQgBAAgBAAQgDAAAAgFIAAhyQAAgHAIgCIBLgSQANgDAMACIBVANQADAAAAAFg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(0,204,255,0.333)").s().p("AgEBRIhZgPIgCAAQgDAAAAgFIAAhyQAAgHAIgCIBLgSQANgDAMACIBVANQADAAAAAFIAABxQABAHgJAEIhKAUQgGABgGAAIgIgBgAgPAmIhLASIBLgSIACAAQAHgCAHAAIAAAAIABAAIAHABIABAAIBVANIhVgNIgBAAIgHgBIgBAAIAAAAQgHAAgHACIgCAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.8,-9.2,21.7,18.5);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,0.9,0.194,0.172);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(255,255,255,0.18)").ss(1,1,1).p("AhcAKIBLgRQANgDAMABIBVAM");
	this.shape.setTransform(0.2,4.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(0,153,255,0.431)").ss(0.5,1,1).p("ABig/IAABxQABAHgJAEIhKAUQgLADgJgDIhZgPQgBAAgBAAQgDAAAAgFIAAhyQAAgHAIgCIBLgSQANgDAMACIBVANQADAAAAAFg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(0,204,255,0.333)").s().p("AgEBRIhZgPIgCAAQgDAAAAgFIAAhyQAAgHAIgCIBLgSQANgDAMACIBVANQADAAAAAFIAABxQABAHgJAEIhKAUQgGABgGAAIgIgBgAgPAmIhLASIBLgSIACAAQAHgCAHAAIAAAAIABAAIAHABIABAAIBVANIhVgNIgBAAIgHgBIgBAAIAAAAQgHAAgHACIgCAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.8,-9.2,21.7,18.5);


(lib.Tswween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.swTween1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,0.9,0.194,0.172);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(255,255,255,0.18)").ss(1,1,1).p("AhcAKIBLgRQANgDAMABIBVAM");
	this.shape.setTransform(0.2,4.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(0,153,255,0.431)").ss(0.5,1,1).p("ABig/IAABxQABAHgJAEIhKAUQgLADgJgDIhZgPQgBAAgBAAQgDAAAAgFIAAhyQAAgHAIgCIBLgSQANgDAMACIBVANQADAAAAAFg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(0,204,255,0.333)").s().p("AgEBRIhZgPIgCAAQgDAAAAgFIAAhyQAAgHAIgCIBLgSQANgDAMACIBVANQADAAAAAFIAABxQABAHgJAEIhKAUQgGABgGAAIgIgBgAgPAmIhLASIBLgSIACAAQAHgCAHAAIAAAAIABAAIAHABIABAAIBVANIhVgNIgBAAIgHgBIgBAAIAAAAQgHAAgHACIgCAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.8,-9.2,21.7,18.5);


(lib.swTween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.swTween1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0,0.9,0.194,0.172);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(255,255,255,0.18)").ss(1,1,1).p("AhcAKIBLgRQANgDAMABIBVAM");
	this.shape.setTransform(0.2,4.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(0,153,255,0.431)").ss(0.5,1,1).p("ABig/IAABxQABAHgJAEIhKAUQgLADgJgDIhZgPQgBAAgBAAQgDAAAAgFIAAhyQAAgHAIgCIBLgSQANgDAMACIBVANQADAAAAAFg");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(0,204,255,0.333)").s().p("AgEBRIhZgPIgCAAQgDAAAAgFIAAhyQAAgHAIgCIBLgSQANgDAMACIBVANQADAAAAAFIAABxQABAHgJAEIhKAUQgGABgGAAIgIgBgAgPAmIhLASIBLgSIACAAQAHgCAHAAIAAAAIABAAIAHABIABAAIBVANIhVgNIgBAAIgHgBIgBAAIAAAAQgHAAgHACIgCAAg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.8,-9.2,21.7,18.5);


(lib.swswsw = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.flamecopy();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.064,0.751);
	this.instance.shadow = new cjs.Shadow("#FFCC00",0,0,23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.2,-31.7,58,66);


(lib.steam = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween51("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(102.4,12.5,0.493,0.493);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1,x:145.8,y:3.5},11).to({scaleX:0.21,scaleY:0.21,x:90.1,y:25.3},1).to({scaleX:1,scaleY:1,x:145.8,y:3.5},22).to({x:160,y:-11.2,alpha:0},8).wait(1));

	// Layer 2
	this.instance_1 = new lib.Tween51("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(90.1,25.3,0.211,0.211);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:0.49,scaleY:0.49,x:102.4,y:12.5},9).to({scaleX:1,scaleY:1,x:124.6,y:-10.6},13).to({x:141.1,y:-28.9,alpha:0},9).to({scaleX:0.21,scaleY:0.21,x:90.1,y:25.3,alpha:1},1).to({scaleX:0.49,scaleY:0.49,x:102.4,y:12.5},10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(83.8,4.4,33.3,24.4);


(lib.outgp = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib.swTween7("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-24.4,20.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1,rotation:78.7,guide:{path:[-24.3,20.7,-21.1,15,-17.9,9.3,-15.1,4.7,-9.8,4.8,3.3,4.8,16.4,4.8], orient:'auto'}},60).to({scaleX:1.43,scaleY:1.43,rotation:42.6,guide:{path:[16.4,4.7,18.7,4.7,21.1,4.7,23.3,4.7,24.1,3.4], orient:'auto'}},9).to({scaleX:2.03,scaleY:2.03,rotation:3.6,guide:{path:[24,3.4,24.5,2.7,24.5,1.5,24.5,-2.1,24.5,-5.8], orient:'auto'}},10).to({scaleX:1,scaleY:1,rotation:-2.8,guide:{path:[24.5,-5.8,24.5,-8.9,24.5,-11.9], orient:'auto'}},10).to({rotation:0,guide:{path:[24.5,-12,24.5,-16.1,24.5,-20.3], orient:'auto'}},10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.7,18.4,4.6,4.6);


(lib.heatoutcopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween7("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(21.9,-5.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:3.8,alpha:0.219},14).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(16.1,-9.2,11.6,6.9);


(lib.heatout = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween7("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-6.3,-5.7,1,1,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:13.3,y:-4.3,alpha:0},14).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12.1,-9.2,11.7,6.9);


(lib.graphmovcopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib.steam();
	this.instance.parent = this;
	this.instance.setTransform(-86.2,71.2,1,1,0,0,0,91.9,22.6);
	this.instance.alpha = 0.07;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(99));

	// Layer 5
	this.instance_1 = new lib.Tween3("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-137.3,107.8,0.34,0.291);
	this.instance_1.alpha = 0.07;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},1).wait(99));

	// Layer 3
	this.instance_2 = new lib.Tween4("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-152.9,107.3,0.345,0.236);
	this.instance_2.alpha = 0.07;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},1).wait(99));

	// Layer 6 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AllBOIAAibILLAAIAACbg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-138.9,y:112.8}).wait(1).to({graphics:null,x:0,y:0}).wait(99));

	// Layer 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,204,255,0.502)").s().p("AlgA/QACgiAEgeIABgHQAEgcAFgaIKxAAIgdA+QAEAeACAhg");
	this.shape.setTransform(-138.6,113.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(99));

	// Layer 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(255,255,255,0.353)").ss(0.4,2,1).p("AicCBQAOh8BQhAQBOhBCOgE");
	this.shape_1.setTransform(-155.4,77.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000066").ss(1,2,1,3,true).p("AmbCxQAEgcAGgaQAri/CRhiIERAAQBuBLA0CBICmjlIAkAXIilFhQADAfACAgIgSAfIAAAcIqGAAIAAgcIgSgfIKqAAAmiD4IgFgXIAakUQAhj1EjgKQAJAGgJAGQkcAIgdD4IgZDXAisjEQAvgYAjgBQA7gBAxAZQAZAMAOAMIkOAAgADeAmQgTAwAJAlQAJAlAmAZAmiD4QACghAEgfIABgHAmQEXIKGAA");
	this.shape_2.setTransform(-132.1,94.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(102,102,102,0.851)").s().p("AlDAOIAAgbIKGAAIAAAbg");
	this.shape_3.setTransform(-139.8,124.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(153,153,153,0.851)").s().p("AlDAPIgSgdIKqAAIgSAdg");
	this.shape_4.setTransform(-139.8,121.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0000CC").s().p("AiwD+IAakUQAhj1EigJQAJAFgJAGQkbAJgdD3IgZDXIgBAHQgEAfgCAigAgxjJQhPBCgPB7QAPh7BPhCQBOhACOgEQiOAEhOBAg");
	this.shape_5.setTransform(-156.8,92);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(255,255,255,0.851)").s().p("AmlDrQADghAEgfIAAgHQAEgcAGgaQArjACRhhIERAAQBuBLA0CBQgNAgAAAbQAAANADANQAJAkAmAaQgmgagJgkQgDgNAAgNQAAgbANggICnjlIAkAXIimFhQADAfACAggAjYi6IApgXQAwgYAigBQA7gBAyAZQAZAMANAMg");
	this.shape_6.setTransform(-131.8,96.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).to({state:[]},1).wait(99));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-175.7,53,114.7,73.6);


(lib.azasasa = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.swTween51("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(102.4,12.5,0.493,0.493);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1,x:145.8,y:3.5},11).to({scaleX:0.21,scaleY:0.21,x:90.1,y:25.3},1).to({scaleX:1,scaleY:1,x:145.8,y:3.5},22).to({x:160,y:-11.2,alpha:0},8).wait(1));

	// Layer 2
	this.instance_1 = new lib.swTween51("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(90.1,25.3,0.211,0.211);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:0.49,scaleY:0.49,x:102.4,y:12.5},9).to({scaleX:1,scaleY:1,x:124.6,y:-10.6},13).to({x:141.1,y:-28.9,alpha:0},9).to({scaleX:0.21,scaleY:0.21,x:90.1,y:25.3,alpha:1},1).to({scaleX:0.46,scaleY:0.46,x:101.2,y:13.8},10).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(84.3,2.4,30.6,27.6);


(lib.Tween8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgOAgIAAg+IAKAAIAAAHQAFgIAKAAIAEABIAAAKIgFgBQgKAAgEAJIAAAsg");
	this.shape.setTransform(26.1,-67);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgSAbQgGgGAAgMIAAgoIALAAIAAAoQAAAOALAAQAMAAAEgJIAAgtIALAAIAAA+IgLAAIAAgGQgGAHgLAAQgLAAgEgFg");
	this.shape_1.setTransform(20.5,-66.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgUAYQgIgJAAgPIAAAAQAAgJAEgHQADgIAHgEQAGgEAIAAQANAAAIAJQAIAJAAAOIAAABQAAAJgEAHQgDAIgHAEQgGAEgJAAQgMAAgIgJgAgMgRQgFAHAAALQAAAKAFAHQAFAGAHAAQAIAAAFgGQAFgHAAgLQAAgKgFgGQgFgHgIAAQgHAAgFAGg");
	this.shape_2.setTransform(13.7,-66.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgaAtIAAhYIAKAAIABAIQAHgJAKAAQALABAHAIQAHAJAAAPIAAABQAAAOgHAIQgHAJgLAAQgLAAgGgHIAAAfgAgPgaIAAAdQAFAJAKAAQAHABAEgHQAFgGAAgLQAAgLgFgGQgEgGgHgBQgKAAgFAJg");
	this.shape_3.setTransform(7.1,-65.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgTAcQgGgGAAgIQAAgKAHgEQAIgGANAAIAKAAIAAgFQAAgFgEgEQgCgDgHAAQgFAAgEADQgEADAAAEIgLAAQAAgFAEgEQADgFAGgCQAFgDAGAAQAMAAAFAGQAHAFAAAKIAAAcQAAAJACAFIAAABIgLAAIgBgHQgIAIgJAAQgKAAgGgFgAgOANQAAAFADADQAEACAFAAQAEAAAEgCQAFgDACgEIAAgNIgIAAQgUAAABAMg");
	this.shape_4.setTransform(0.3,-66.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgEArIgghVIANAAIAXBGIAYhGIANAAIggBVg");
	this.shape_5.setTransform(-6.8,-68);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgTAlQgHgKAAgOIAAgBQAAgNAHgJQAHgJALAAQAKAAAHAHIAAggIALAAIAABZIgKAAIgBgHQgGAHgLABQgLgBgHgIgAgKgEQgFAGAAALQAAAMAFAFQAEAHAHAAQAKAAAFgKIAAgcQgFgJgKAAQgHAAgEAGg");
	this.shape_6.setTransform(-17.1,-68.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAOAgIAAgpQAAgHgDgDQgDgDgGAAQgFAAgDADQgEADgDAEIAAAsIgLAAIAAg+IAKAAIABAIQAHgJALAAQAUAAAAAWIAAApg");
	this.shape_7.setTransform(-23.6,-67);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgTAcQgGgGAAgIQAAgKAHgEQAIgGANAAIAKAAIAAgFQAAgFgEgEQgCgDgHAAQgFAAgEADQgEADAAAEIgLAAQAAgFADgEQAEgFAFgCQAGgDAGAAQAMAAAFAGQAHAFAAAKIAAAcQAAAJACAFIAAABIgLAAIgBgHQgIAIgJAAQgKAAgGgFgAgOANQgBAFAEADQADACAGAAQAEAAAEgCQAFgDACgEIAAgNIgIAAQgUAAABAMg");
	this.shape_8.setTransform(-30.2,-66.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgTAlQgHgKAAgOIAAgBQAAgNAHgJQAHgJALAAQAKAAAHAHIAAggIALAAIAABZIgKAAIgBgHQgGAHgLABQgLgBgHgIgAgKgEQgFAGAAALQAAAMAFAFQAEAHAHAAQAKAAAFgKIAAgcQgFgJgKAAQgHAAgEAGg");
	this.shape_9.setTransform(-40,-68.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgFArIAAg+IAKAAIAAA+gAgEggQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQABAAAAgBQABAAAAAAQABAAAAAAQADAAACACQAAAAAAABQABAAAAABQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAQgCACgDAAQAAAAgBAAQAAAAgBAAQAAgBgBAAQAAAAgBgBg");
	this.shape_10.setTransform(-44.6,-68.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgTAbQgFgGAAgMIAAgoIALAAIAAAoQAAAOALAAQAMAAAEgJIAAgtIALAAIAAA+IgLAAIAAgGQgGAHgLAAQgKAAgGgFg");
	this.shape_11.setTransform(-49.4,-66.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAQAtIAAgfQgHAHgKAAQgLAAgHgJQgHgIAAgOIAAgBQAAgPAHgJQAHgIAMgBQAKABAGAHIABgHIAKAAIAABYgAgKgcQgFAGAAAMQAAAKAFAGQAEAHAHgBQAKABAFgJIAAgeQgFgJgKAAQgHAAgEAHg");
	this.shape_12.setTransform(-56.3,-65.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgFArIAAg+IAKAAIAAA+gAgEggQAAAAAAgBQgBAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQABAAAAgBQABAAAAAAQABAAAAAAQADAAACACQAAAAAAABQABAAAAABQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAQgCACgDAAQAAAAgBAAQAAAAgBAAQAAgBgBAAQAAAAgBgBg");
	this.shape_13.setTransform(-60.9,-68.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgZArIAAhVIALAAIAABMIAoAAIAAAJg");
	this.shape_14.setTransform(-65.3,-68);

	this.instance = new lib.graphmovcopy("synched",0,false);
	this.instance.parent = this;
	this.instance.setTransform(117.8,-101);

	this.instance_1 = new lib.heatoutcopy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(5.6,20.4,1,1,0,-90,90);

	this.instance_2 = new lib.heatoutcopy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-16.7,20.4,1,1,0,-90,90);

	this.instance_3 = new lib.heatoutcopy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-39.1,20.4,1,1,0,-90,90);

	this.instance_4 = new lib.sasaas();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-20.9,27.1,0.398,0.398);
	this.instance_4.shadow = new cjs.Shadow("rgba(0,204,255,1)",0,0,23);

	this.instance_5 = new lib.Symbol2("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(-21.5,35.1,0.398,0.398);
	this.instance_5.alpha = 0.59;

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AAaBiQgdABgcgfIARgCIAIgCQAQAOARAAIABABQAPACAHgGQAFgHAAgQIAAheQgCgTgIgKQgIgIgPABIhWAAQgEAAgDgDQgDgDAAgEQAAgEADgDQADgDAEAAIBVAAQAZgBANAOQAOANACAcIAAABIAABeQABAbgNAMQgJAJgQAAIgMgBg");
	this.shape_15.setTransform(2.5,35.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("Ag+BaQgMgMABgbIAAheIAAgBQACgbANgOQANgOAZABIBUAAQAFAAADADQACADAAAEQAAAEgCADQgDADgFAAIhUAAIgBAAQgPgBgIAIQgIAJgBAUIAABeQgBAQAGAHQAHAGAOgCIABgBQAPAAAOgLIANACIAKABQAAAEgDACQgXAWgZAAIgLABQgRAAgJgJg");
	this.shape_16.setTransform(-46.1,35.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#333333").ss(0.6,1,1).p("AhGACIBAgCQABAAABAAQABAAABAAQAXgBAUABIAeAB");
	this.shape_17.setTransform(-20.7,26);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AhjATQgqgHAAgLIAAgBQADgJAngIIAggFIBAgDIACAAIABAAQAYAAAUABIAeACIAaADQAnAHADAKIAAABQAAAKgqAIQgpAIg7ABIgGAAQg2AAgngHg");
	this.shape_18.setTransform(-21,28.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["#807B82","#FFFFFF","#C7C7C9","#7B7A80","#5D5B63","#0D0B17","#8F8B9A"],[0.02,0.102,0.165,0.463,0.792,0.882,1],0,-5.7,0,5.8).s().p("AjeAfQhbgLAAgSQAAgQBbgNQBdgNCBgBQCCgBBcALQBcAMAAASQAAAQhcANQhcANiCABIgTAAQh1AAhWgLgAhDgRIghAFQgmAHgDAJIgBACQAAAKAqAHQAqAIA6gBQA6gBAqgHQAqgIAAgLIAAgCQgDgIgngHIgbgEIgdgCQgVgBgXABIgBAAIgCAAg");
	this.shape_19.setTransform(-21,28);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["#807B82","#0D0B17","#8F8B9A"],[0.02,0.882,1],-0.9,5,0.9,-5).s().p("Aj0AmQhCgJgXgMQgMgHAAgHQAAgVBlgQQBlgPCPgBQCQgBBlAOQBlAOAAAWQAAAHgSAIQgYALg7AKQhlAPiQABIgZAAQh/AAhcgNgAAEgsQiBABhdANQhbANAAARQAAARBbAMQBdAMCBgBQCCgBBcgOQBcgMAAgRQAAgRhcgMQhVgLh1AAIgUAAg");
	this.shape_20.setTransform(-21.4,28.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["#807B82","#FFFFFF","#C7C7C9","#7B7A80","#5D5B63","#0D0B17","#8F8B9A"],[0.02,0.102,0.165,0.463,0.792,0.882,1],-29.8,0,29.9,0).s().p("AjPA6IgUgDIgagDQhFgMAAgRIgIhXQAXAMBCAJQBlAPCPgCQCPgBBlgPQA7gKAZgLIgKBWQAAARhQAOIgPACIgkAFQhTAKhrAAIgVABQhqAAhQgKg");
	this.shape_21.setTransform(-21.6,36.5);

	this.instance_6 = new lib.Symbol1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-21.4,46.2,0.398,0.398);
	this.instance_6.alpha = 0.379;
	this.instance_6.filters = [new cjs.BlurFilter(5, 5, 1)];
	this.instance_6.cache(-81,-6,163,11);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70.9,-77.1,127.7,136.7);


(lib.Tween6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgTAlQgHgJAAgPIAAAAQAAgPAHgIQAHgJALAAQAKAAAHAHIAAghIALAAIAABZIgKAAIgBgGQgGAHgLABQgLgBgHgIgAgKgEQgFAFAAAMQAAALAFAHQAEAFAHABQAKAAAFgKIAAgcQgFgJgKAAQgHAAgEAGg");
	this.shape.setTransform(7.8,-55.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgFArIAAg+IAKAAIAAA+gAgEggQAAAAAAgBQgBAAAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQABgBAAAAQABAAAAAAQABAAAAAAQADAAACACQAAAAAAABQABAAAAABQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAABQAAAAgBAAQAAABAAAAQgCACgDAAQAAAAgBAAQAAAAgBAAQAAgBgBAAQAAAAgBgBg");
	this.shape_1.setTransform(3.2,-55.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgSAbQgGgGAAgMIAAgoIALAAIAAAoQAAAOALAAQAMAAAEgJIAAgtIALAAIAAA+IgLAAIAAgGQgGAHgLAAQgLAAgEgFg");
	this.shape_2.setTransform(-1.6,-54);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAQAtIAAgfQgHAHgKAAQgLAAgHgJQgHgIAAgPIAAAAQAAgPAHgJQAHgIAMAAQAKAAAGAHIABgGIAKAAIAABXgAgKgdQgFAHAAAMQAAAKAFAGQAEAGAHAAQAKAAAFgIIAAgeQgFgJgKABQgHAAgEAFg");
	this.shape_3.setTransform(-8.5,-52.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgFArIAAg+IAKAAIAAA+gAgEggQAAAAAAgBQgBAAAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQABgBAAAAQABAAAAAAQABAAAAAAQADAAACACQAAAAAAABQABAAAAABQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAABQAAAAgBAAQAAABAAAAQgCACgDAAQAAAAgBAAQAAAAgBAAQAAgBgBAAQAAAAgBgBg");
	this.shape_4.setTransform(-13.1,-55.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgZArIAAhVIALAAIAABMIAoAAIAAAJg");
	this.shape_5.setTransform(-17.5,-55.2);

	this.instance = new lib.graphmovcopy2("single",0);
	this.instance.parent = this;
	this.instance.setTransform(-2,11.6,1,1,0,0,0,-140.8,105);

	this.instance_1 = new lib.heatout();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-25.7,-28.7,0.998,0.998,53.6);

	this.instance_2 = new lib.heatout();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-40.1,-13.4,0.998,0.998,38.6);

	this.instance_3 = new lib.heatout();
	this.instance_3.parent = this;
	this.instance_3.setTransform(23.1,-28.7,0.998,0.998,0,-53.6,126.4);

	this.instance_4 = new lib.heatout();
	this.instance_4.parent = this;
	this.instance_4.setTransform(37.5,-13.4,0.998,0.998,0,-38.6,141.4);

	this.instance_5 = new lib.heatout();
	this.instance_5.parent = this;
	this.instance_5.setTransform(49.1,29.4,1,1,0,0,180);

	this.instance_6 = new lib.heatout();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-51.5,29.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63.7,-64.3,124.9,97.5);


(lib.out2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.outgp("synched",90);
	this.instance.parent = this;

	this.instance_1 = new lib.outgp("synched",80);
	this.instance_1.parent = this;

	this.instance_2 = new lib.outgp("synched",70);
	this.instance_2.parent = this;

	this.instance_3 = new lib.outgp("synched",60);
	this.instance_3.parent = this;

	this.instance_4 = new lib.outgp("synched",50);
	this.instance_4.parent = this;

	this.instance_5 = new lib.outgp("synched",40);
	this.instance_5.parent = this;

	this.instance_6 = new lib.outgp("synched",30);
	this.instance_6.parent = this;

	this.instance_7 = new lib.outgp("synched",20);
	this.instance_7.parent = this;

	this.instance_8 = new lib.outgp("synched",10);
	this.instance_8.parent = this;

	this.instance_9 = new lib.outgp("synched",0);
	this.instance_9.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(10));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.7,-15.2,55.7,38.2);


(lib.out = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlIEHIAAoNIKQAAIAAINg");
	mask.setTransform(5,3.3);

	// Layer 1
	this.instance = new lib.out2();
	this.instance.parent = this;
	this.instance.setTransform(-0.7,1.3);
	this.instance.filters = [new cjs.BlurFilter(15, 15, 2)];
	this.instance.cache(-29,-17,60,42);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.out, new cjs.Rectangle(-27.9,-22.9,65.7,52.6), null);


(lib.vapo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();
		*/
	}
	this.frame_69 = function() {
		/* stop();
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(69).call(this.frame_69).wait(1));

	// Layer 9
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgFAbQgGgCgDgEQgDgEgDgFQgBgFAAgHQAAgGABgFQADgFADgEQADgDAGgCQAEgCAFAAIAJABIAKADIAAAJIgBAAQgEgEgFgBQgEgCgFAAQgEAAgCACIgHADIgDAIQgCAEAAAEQAAAGACAEQABAEACADIAHADQACACAEAAQAFAAAFgCQAEgCAEgEIABAAIAAAJIgEACIgEACIgFABIgGAAQgEAAgFgBg");
	this.shape.setTransform(-187.4,81.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgGARQgDgBgCgCIgDgGQgCgDABgFQgBgDACgDIADgGQACgDADgBQADgBADAAQAEAAADABQADABACADIADAFQACAEAAADQAAAFgCADIgDAGIgFADIgHABIgGgBgAgHgJQgDADgBAGQABAHADAEQADADAEAAQAFAAAEgDQACgEAAgHQAAgGgCgDQgEgEgFAAQgEAAgDAEg");
	this.shape_1.setTransform(-191.9,80.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgNAVQgFgHAAgOQAAgOAFgGQAEgHAJAAQAKAAAEAHQAFAHAAANQAAAPgFAGQgFAHgJAAQgJAAgEgHgAgFgTQgCABgBACQgCADAAAFIAAAIIAAAKIACAHQABACACABQACACADAAQADAAADgCQACgBABgCIACgHIAAgKIAAgIIgCgIQgBgCgCgBQgDgCgDAAQgCAAgDACg");
	this.shape_2.setTransform(-198.8,81.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgNAVQgFgHAAgOQAAgOAFgGQAEgHAJAAQAKAAAEAHQAFAHAAANQAAAPgFAGQgFAHgJAAQgJAAgEgHgAgFgTQgCABgBACQgCADAAAFIAAAIIAAAKIACAHQABACACABQACACADAAQADAAADgCQACgBABgCIACgHIAAgKIAAgIIgCgIQgBgCgCgBQgDgCgDAAQgCAAgDACg");
	this.shape_3.setTransform(-203.5,81.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgOAbIAAgGIAMAAIAAgjIgMAAIAAgEIAFgBIAEgBIADgDIABgDIAFAAIAAAvIALAAIAAAGg");
	this.shape_4.setTransform(-208.2,81.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(70));

	// Layer 1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgvhpQAKgCAJgDAgohVQAKgCAJgEAghhBQAKgCAJgEAgagtQAKgDAJgEAABAhQAKgCAJgEAAdBwQAKgCAJgEAAWBcQAKgCAJgEAAPBIQAKgCAJgDAAIA0QAKgCAJgDAgTgaQAKgCAJgEAgMgGQAKgCAIgEAgFANQAJgCAJgE");
	this.shape_5.setTransform(-181.7,75.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1,3,true).p("AhAgBQBAAGBCgG");
	this.shape_6.setTransform(-170.1,105.6,0.3,0.3,-19.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1,3,true).p("AhAgBQBAAGBCgG");
	this.shape_7.setTransform(-175.5,90.4,0.3,0.3,-19.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1,1,1,3,true).p("AhAgBQBAAGBCgG");
	this.shape_8.setTransform(-176.3,88.2,0.3,0.3,-19.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(1,1,1,3,true).p("AgTAAQATABAUgB");
	this.shape_9.setTransform(-185.2,62.9,0.999,0.999,-19.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.rf(["#F1F7FC","#BDCEE9","#E3EEF8"],[0.094,0.541,1],-0.1,-0.5,0,-0.1,-0.5,1.6).s().p("AgDAFQgDgCgBgDQAIABAHgGQABAJgHACIgBAAQgBAAAAAAQAAAAgBAAQAAAAgBgBQAAAAgBAAg");
	this.shape_10.setTransform(-165.5,117.9,1,1,0,0,0,0.2,0.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.rf(["#F1F7FC","#BDCEE9","#E3EEF8"],[0.094,0.541,1],-0.1,-0.3,0,-0.1,-0.3,1.5).s().p("AgKAIQgFgBgDgCIAKgDIAEAGIgFAAIgBAAgAAIgEIALgDQgCAGgIAEg");
	this.shape_11.setTransform(-169.6,106.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#C0D0EA").ss(1,1,1,3,true).p("Ah0khQAFAJAAAGQAAAAAAABQgBAHACADICeHBQABAFAHACQAHABAEALIAeBVQAGAPAJgEQAEgBABgGQABgFgDgGIgehUQgDgLAEgGQAEgFgCgFIifnAQgBgFgEgEQgBAAAAgBQgEgEgBgL");
	this.shape_12.setTransform(-176.6,88.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FF0000").s().p("ABAC/IghhcIgIgMIhgkRQAFgJALACIBhESIACAOIAgBbQABAGgEABIgDABQgBAAgBAAQAAAAgBgBQAAAAgBAAQAAgBAAgBg");
	this.shape_13.setTransform(-172.8,98.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["#BDCEE9","#F1F7FC","#E3EEF8"],[0,0.506,1],-1.4,1,2.6,-0.4).s().p("ABhEiIgehVQgEgLgHgBQgHgCgBgFIienBQgCgDABgHIAAgBQAAgGgFgJQAAAAAAABQABAAAAAAQABABAAAAQABAAAAAAQAJAEAIgDQAJgDADgIIACgEQABALAEAEIABABQAEAEABAFICfHAQACAFgEAFQgEAGADALIAeBUQADAGgBAFQgBAGgEABIgDABQgHAAgFgMgAgjhXIBgERIAIAMIAhBcQACAEAFgCQAEgBgBgGIgghbIgCgOIhhkSIgEAAQgIAAgEAHg");
	this.shape_14.setTransform(-176.6,88.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#C0D0EA").ss(1,1,1,3,true).p("AgMATQgFgDgCgGQgDgIAEgIQAEgIAIgDQAIgDAHAEQAIAEADAJQADAFgCAG");
	this.shape_15.setTransform(-187,57.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.rf(["#F1F7FC","#BDCEE9","#E3EEF8"],[0.094,0.541,1],0,-0.8,0,0,-0.8,3.1).s().p("AgIATQgBAAAAAAQgBAAAAgBQgBAAAAAAQgBgBAAAAQgFgDgCgGQgDgIAEgIQAEgIAIgDQAIgDAHAEQAIAEADAIQADAGgCAFIgCAEQgDAIgIADIgIACQgEAAgEgDg");
	this.shape_16.setTransform(-187,57.6);

	this.instance = new lib.temp();
	this.instance.parent = this;
	this.instance.setTransform(-78.9,54.8);

	this.instance_1 = new lib.azasasa();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-137.5,105.1,0.298,0.298,-39.6,0,0,92,22.5);
	this.instance_1.alpha = 0.449;
	this.instance_1.filters = [new cjs.BlurFilter(5, 5, 1)];
	this.instance_1.cache(82,0,35,32);

	this.instance_2 = new lib.azasasa();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-151.8,105.1,0.298,0.298,-39.6,0,0,92,22.5);
	this.instance_2.alpha = 0.449;
	this.instance_2.filters = [new cjs.BlurFilter(5, 5, 1)];
	this.instance_2.cache(82,0,35,32);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]}).wait(70));

	// Layer 13
	this.instance_3 = new lib.swswsw("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(-60.5,107.9,1,1,0,0,0,0,6.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(70));

	// Layer 12
	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#CCCCCC").s().p("AgVAUIApgnIABAAIgbAng");
	this.shape_17.setTransform(-63.7,143.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#333333").s().p("AAKATIgeglIAEAAIAlAlg");
	this.shape_18.setTransform(-57.5,143.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["#807B82","#FFFFFF","#C7C7C9","#7B7A80","#5D5B63","#0D0B17","#8F8B9A"],[0.02,0.102,0.384,0.569,0.792,0.882,1],-1.2,0,1.3,0).s().p("AgMCmIAAlLIAZAAIAAFLg");
	this.shape_19.setTransform(-60.6,124.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.rf(["#E1E1E1","#8F8B9A"],[0.055,1],0.1,-2.1,0,0.1,-2,2.8).s().p("Ag6AWIAugrIAYAAIAvArg");
	this.shape_20.setTransform(-60.5,143.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17}]}).wait(70));

	// Layer 2
	this.instance_4 = new lib.azasasa();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-60.8,57.4,0.998,0.998,-38.6,0,0,91.9,22.5);
	this.instance_4.filters = [new cjs.BlurFilter(13, 13, 1)];
	this.instance_4.cache(82,0,35,32);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(70));

	// Layer 3
	this.instance_5 = new lib.swTween3("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(-137.3,107.8,0.34,0.291);
	this.instance_5.alpha = 0.07;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(70));

	// Layer 4
	this.instance_6 = new lib.Tswween4("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(-152.9,107.3,0.345,0.236);
	this.instance_6.alpha = 0.07;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(70));

	// Layer 5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AtpJ2IAAidILNAAIAACdg");
	var mask_graphics_1 = new cjs.Graphics().p("AtpJ2IAAidILNAAIAACdg");
	var mask_graphics_2 = new cjs.Graphics().p("AtpJ2IAAicILNAAIAACcg");
	var mask_graphics_3 = new cjs.Graphics().p("AtpJ3IAAidILNAAIAACdg");
	var mask_graphics_4 = new cjs.Graphics().p("AtpJ3IAAicILNAAIAACcg");
	var mask_graphics_5 = new cjs.Graphics().p("AtpJ4IAAidILNAAIAACdg");
	var mask_graphics_6 = new cjs.Graphics().p("AtpJ4IAAicILNAAIAACcg");
	var mask_graphics_7 = new cjs.Graphics().p("AtpJ5IAAidILNAAIAACdg");
	var mask_graphics_8 = new cjs.Graphics().p("AtpJ5IAAicILNAAIAACcg");
	var mask_graphics_9 = new cjs.Graphics().p("AtpJ5IAAicILNAAIAACcg");
	var mask_graphics_10 = new cjs.Graphics().p("AtpJ6IAAidILNAAIAACdg");
	var mask_graphics_11 = new cjs.Graphics().p("AtpJ6IAAicILNAAIAACcg");
	var mask_graphics_12 = new cjs.Graphics().p("AtpJ7IAAidILNAAIAACdg");
	var mask_graphics_13 = new cjs.Graphics().p("AtpJ7IAAicILNAAIAACcg");
	var mask_graphics_14 = new cjs.Graphics().p("AtpJ8IAAidILNAAIAACdg");
	var mask_graphics_15 = new cjs.Graphics().p("AtpJ8IAAicILNAAIAACcg");
	var mask_graphics_16 = new cjs.Graphics().p("AtpJ9IAAidILNAAIAACdg");
	var mask_graphics_17 = new cjs.Graphics().p("AtpJ9IAAidILNAAIAACdg");
	var mask_graphics_18 = new cjs.Graphics().p("AtpJ9IAAicILNAAIAACcg");
	var mask_graphics_19 = new cjs.Graphics().p("AtpJ+IAAidILNAAIAACdg");
	var mask_graphics_20 = new cjs.Graphics().p("AtpJ+IAAicILNAAIAACcg");
	var mask_graphics_21 = new cjs.Graphics().p("AtpJ/IAAidILNAAIAACdg");
	var mask_graphics_22 = new cjs.Graphics().p("AtpJ/IAAicILNAAIAACcg");
	var mask_graphics_23 = new cjs.Graphics().p("AtpKAIAAidILNAAIAACdg");
	var mask_graphics_24 = new cjs.Graphics().p("AtpKAIAAicILNAAIAACcg");
	var mask_graphics_25 = new cjs.Graphics().p("AtpKAIAAicILNAAIAACcg");
	var mask_graphics_26 = new cjs.Graphics().p("AtpKBIAAidILNAAIAACdg");
	var mask_graphics_27 = new cjs.Graphics().p("AtpKBIAAicILNAAIAACcg");
	var mask_graphics_28 = new cjs.Graphics().p("AtpKCIAAidILNAAIAACdg");
	var mask_graphics_29 = new cjs.Graphics().p("AtpKCIAAicILNAAIAACcg");
	var mask_graphics_30 = new cjs.Graphics().p("AtpKDIAAidILNAAIAACdg");
	var mask_graphics_31 = new cjs.Graphics().p("AtpKDIAAicILNAAIAACcg");
	var mask_graphics_32 = new cjs.Graphics().p("AtpKEIAAidILNAAIAACdg");
	var mask_graphics_33 = new cjs.Graphics().p("AtpKEIAAidILNAAIAACdg");
	var mask_graphics_34 = new cjs.Graphics().p("AtpKEIAAicILNAAIAACcg");
	var mask_graphics_35 = new cjs.Graphics().p("AtpKFIAAidILNAAIAACdg");
	var mask_graphics_36 = new cjs.Graphics().p("AtpKFIAAicILNAAIAACcg");
	var mask_graphics_37 = new cjs.Graphics().p("AtpKGIAAidILNAAIAACdg");
	var mask_graphics_38 = new cjs.Graphics().p("AtpKGIAAicILNAAIAACcg");
	var mask_graphics_39 = new cjs.Graphics().p("AtpKHIAAidILNAAIAACdg");
	var mask_graphics_40 = new cjs.Graphics().p("AtpKHIAAicILNAAIAACcg");
	var mask_graphics_41 = new cjs.Graphics().p("AtpKHIAAicILNAAIAACcg");
	var mask_graphics_42 = new cjs.Graphics().p("AtpKIIAAidILNAAIAACdg");
	var mask_graphics_43 = new cjs.Graphics().p("AtpKIIAAicILNAAIAACcg");
	var mask_graphics_44 = new cjs.Graphics().p("AtpKJIAAidILNAAIAACdg");
	var mask_graphics_45 = new cjs.Graphics().p("AtpKJIAAicILNAAIAACcg");
	var mask_graphics_46 = new cjs.Graphics().p("AtpKKIAAidILNAAIAACdg");
	var mask_graphics_47 = new cjs.Graphics().p("AtpKKIAAicILNAAIAACcg");
	var mask_graphics_48 = new cjs.Graphics().p("AtpKLIAAidILNAAIAACdg");
	var mask_graphics_49 = new cjs.Graphics().p("AtpKLIAAidILNAAIAACdg");
	var mask_graphics_50 = new cjs.Graphics().p("AtpKLIAAicILNAAIAACcg");
	var mask_graphics_51 = new cjs.Graphics().p("AtpKMIAAidILNAAIAACdg");
	var mask_graphics_52 = new cjs.Graphics().p("AtpKMIAAicILNAAIAACcg");
	var mask_graphics_53 = new cjs.Graphics().p("AtpKNIAAidILNAAIAACdg");
	var mask_graphics_54 = new cjs.Graphics().p("AtpKNIAAicILNAAIAACcg");
	var mask_graphics_55 = new cjs.Graphics().p("AtpKOIAAidILNAAIAACdg");
	var mask_graphics_56 = new cjs.Graphics().p("AtpKOIAAicILNAAIAACcg");
	var mask_graphics_57 = new cjs.Graphics().p("AtpKOIAAicILNAAIAACcg");
	var mask_graphics_58 = new cjs.Graphics().p("AtpKPIAAidILNAAIAACdg");
	var mask_graphics_59 = new cjs.Graphics().p("AtpKPIAAicILNAAIAACcg");
	var mask_graphics_60 = new cjs.Graphics().p("AtpKQIAAidILNAAIAACdg");
	var mask_graphics_61 = new cjs.Graphics().p("AtpKQIAAicILNAAIAACcg");
	var mask_graphics_62 = new cjs.Graphics().p("AtpKRIAAidILNAAIAACdg");
	var mask_graphics_63 = new cjs.Graphics().p("AtpKRIAAicILNAAIAACcg");
	var mask_graphics_64 = new cjs.Graphics().p("AtpKSIAAidILNAAIAACdg");
	var mask_graphics_65 = new cjs.Graphics().p("AtpKSIAAicILNAAIAACcg");
	var mask_graphics_66 = new cjs.Graphics().p("AtpKSIAAicILNAAIAACcg");
	var mask_graphics_67 = new cjs.Graphics().p("AtpKTIAAidILNAAIAACdg");
	var mask_graphics_68 = new cjs.Graphics().p("AtpKTIAAicILNAAIAACcg");
	var mask_graphics_69 = new cjs.Graphics().p("AtpKUIAAidILNAAIAACdg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-87.4,y:63}).wait(1).to({graphics:mask_graphics_1,x:-87.4,y:63}).wait(1).to({graphics:mask_graphics_2,x:-87.4,y:63}).wait(1).to({graphics:mask_graphics_3,x:-87.4,y:63.1}).wait(1).to({graphics:mask_graphics_4,x:-87.4,y:63.1}).wait(1).to({graphics:mask_graphics_5,x:-87.4,y:63.2}).wait(1).to({graphics:mask_graphics_6,x:-87.4,y:63.2}).wait(1).to({graphics:mask_graphics_7,x:-87.4,y:63.3}).wait(1).to({graphics:mask_graphics_8,x:-87.4,y:63.3}).wait(1).to({graphics:mask_graphics_9,x:-87.4,y:63.3}).wait(1).to({graphics:mask_graphics_10,x:-87.4,y:63.4}).wait(1).to({graphics:mask_graphics_11,x:-87.4,y:63.4}).wait(1).to({graphics:mask_graphics_12,x:-87.4,y:63.5}).wait(1).to({graphics:mask_graphics_13,x:-87.4,y:63.5}).wait(1).to({graphics:mask_graphics_14,x:-87.4,y:63.6}).wait(1).to({graphics:mask_graphics_15,x:-87.4,y:63.6}).wait(1).to({graphics:mask_graphics_16,x:-87.4,y:63.7}).wait(1).to({graphics:mask_graphics_17,x:-87.4,y:63.7}).wait(1).to({graphics:mask_graphics_18,x:-87.4,y:63.7}).wait(1).to({graphics:mask_graphics_19,x:-87.4,y:63.8}).wait(1).to({graphics:mask_graphics_20,x:-87.4,y:63.8}).wait(1).to({graphics:mask_graphics_21,x:-87.4,y:63.9}).wait(1).to({graphics:mask_graphics_22,x:-87.4,y:63.9}).wait(1).to({graphics:mask_graphics_23,x:-87.4,y:64}).wait(1).to({graphics:mask_graphics_24,x:-87.4,y:64}).wait(1).to({graphics:mask_graphics_25,x:-87.4,y:64}).wait(1).to({graphics:mask_graphics_26,x:-87.4,y:64.1}).wait(1).to({graphics:mask_graphics_27,x:-87.4,y:64.1}).wait(1).to({graphics:mask_graphics_28,x:-87.4,y:64.2}).wait(1).to({graphics:mask_graphics_29,x:-87.4,y:64.2}).wait(1).to({graphics:mask_graphics_30,x:-87.4,y:64.3}).wait(1).to({graphics:mask_graphics_31,x:-87.4,y:64.3}).wait(1).to({graphics:mask_graphics_32,x:-87.4,y:64.4}).wait(1).to({graphics:mask_graphics_33,x:-87.4,y:64.4}).wait(1).to({graphics:mask_graphics_34,x:-87.4,y:64.4}).wait(1).to({graphics:mask_graphics_35,x:-87.4,y:64.5}).wait(1).to({graphics:mask_graphics_36,x:-87.4,y:64.5}).wait(1).to({graphics:mask_graphics_37,x:-87.4,y:64.6}).wait(1).to({graphics:mask_graphics_38,x:-87.4,y:64.6}).wait(1).to({graphics:mask_graphics_39,x:-87.4,y:64.7}).wait(1).to({graphics:mask_graphics_40,x:-87.4,y:64.7}).wait(1).to({graphics:mask_graphics_41,x:-87.4,y:64.7}).wait(1).to({graphics:mask_graphics_42,x:-87.4,y:64.8}).wait(1).to({graphics:mask_graphics_43,x:-87.4,y:64.8}).wait(1).to({graphics:mask_graphics_44,x:-87.4,y:64.9}).wait(1).to({graphics:mask_graphics_45,x:-87.4,y:64.9}).wait(1).to({graphics:mask_graphics_46,x:-87.4,y:65}).wait(1).to({graphics:mask_graphics_47,x:-87.4,y:65}).wait(1).to({graphics:mask_graphics_48,x:-87.4,y:65.1}).wait(1).to({graphics:mask_graphics_49,x:-87.4,y:65.1}).wait(1).to({graphics:mask_graphics_50,x:-87.4,y:65.1}).wait(1).to({graphics:mask_graphics_51,x:-87.4,y:65.2}).wait(1).to({graphics:mask_graphics_52,x:-87.4,y:65.2}).wait(1).to({graphics:mask_graphics_53,x:-87.4,y:65.3}).wait(1).to({graphics:mask_graphics_54,x:-87.4,y:65.3}).wait(1).to({graphics:mask_graphics_55,x:-87.4,y:65.4}).wait(1).to({graphics:mask_graphics_56,x:-87.4,y:65.4}).wait(1).to({graphics:mask_graphics_57,x:-87.4,y:65.4}).wait(1).to({graphics:mask_graphics_58,x:-87.4,y:65.5}).wait(1).to({graphics:mask_graphics_59,x:-87.4,y:65.5}).wait(1).to({graphics:mask_graphics_60,x:-87.4,y:65.6}).wait(1).to({graphics:mask_graphics_61,x:-87.4,y:65.6}).wait(1).to({graphics:mask_graphics_62,x:-87.4,y:65.7}).wait(1).to({graphics:mask_graphics_63,x:-87.4,y:65.7}).wait(1).to({graphics:mask_graphics_64,x:-87.4,y:65.8}).wait(1).to({graphics:mask_graphics_65,x:-87.4,y:65.8}).wait(1).to({graphics:mask_graphics_66,x:-87.4,y:65.8}).wait(1).to({graphics:mask_graphics_67,x:-87.4,y:65.9}).wait(1).to({graphics:mask_graphics_68,x:-87.4,y:65.9}).wait(1).to({graphics:mask_graphics_69,x:-87.4,y:66}).wait(1));

	// Layer 6
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(0,204,255,0.502)").s().p("AlgA/QACgiAEgeIABgHQAEgcAFgaIKxAAIgdA+QAEAeACAhg");
	this.shape_21.setTransform(-138.6,113.5);

	var maskedShapeInstanceList = [this.shape_21];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_21).wait(70));

	// Layer 10 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AkgBcIA/hVQAIgLAUgBIEwAAIAAiFQAAgKANgBIBFAAIAAhZIAhAAIAABZIBEAAQANABAAAKIAACwQgBALgLACImuAAQgWABgJAOIhRCtQhMg1Anheg");
	mask_1.setTransform(-81,89.5);

	// Layer 11
	this.instance_7 = new lib.out();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-84.3,85.9);

	var maskedShapeInstanceList = [this.instance_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(70));

	// Layer 7
	this.instance_8 = new lib.Tswween5("synched",0);
	this.instance_8.parent = this;
	this.instance_8.setTransform(-139.8,99);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(70));

	// Layer 8
	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("rgba(255,255,255,0.353)").ss(0.4,2,1).p("AicCBQAOh8BQhAQBOhBCOgE");
	this.shape_22.setTransform(-155.4,77.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000066").ss(1,2,1,3,true).p("AAbAmIA/hVQAIgLAUgBIExAAIAAiFQAAgKANgBIBFAAIAAhZIAhAAIAABZIBEAAQANABAAAKIAACxQgBALgLACImvAAQgaACgHAQIhPCpQAEAfACAgIgSAfIAAAcIqGAAIAAgcIgSgfIgGgXIAbkUQAgj1EjgKQAKAGgKAGQkbAIgdD4IgZDXQAEgcAFgaQAri/CRhiIESAAQBvBLAyCBQgTAwAKAlQAJAlAlAZAlvjEQAwgYAigBQA7gBAzAZQAZAMANAMIkPAAgApkD4QACghAEgfIABgHApSEXIKGAAApkD4IKqAA");
	this.shape_23.setTransform(-112.6,94.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(102,102,102,0.851)").s().p("AlDAOIAAgbIKGAAIAAAbg");
	this.shape_24.setTransform(-139.8,124.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(153,153,153,0.851)").s().p("AlDAPIgSgdIKqAAIgSAdg");
	this.shape_25.setTransform(-139.8,121.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#0000CC").s().p("AiwD+IAakUQAhj1EigJQAJAFgJAGQkbAJgdD3IgZDXIgBAHQgEAfgCAigAgxjJQhPBCgPB7QAPh7BPhCQBOhACOgEQiOAEhOBAg");
	this.shape_26.setTransform(-156.8,92);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(255,255,255,0.851)").s().p("ApnEPQACgiAEgfIABgHQAEgcAGgaQAri/CQhhIETAAQBuBKAzCCQgNAgAAAbQAAANADAMQAJAlAlAaQAEAeACAhgAA9DQQglgagJglQgDgMAAgNQAAgbANggIA+hVQAIgLAUgBIEyAAIAAiFQAAgLAMgBIBFAAIAAhZIAiAAIAABZIBDAAQANABAAALIAACvQgBAMgLABImvAAQgaACgHASIhPCpIAAAAgAAZA9IAAAAgAmbiWIApgYQAwgYAiAAQA7gBAzAYQAZAMAOANg");
	this.shape_27.setTransform(-112.3,92.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22}]}).wait(70));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-211.9,20.4,182.3,125);


(lib.Tween9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgOAgIAAg+IAKAAIAAAHQAFgIAKAAIAEABIAAAKIgFgBQgKAAgEAJIAAAsg");
	this.shape.setTransform(86.1,-81.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgSAbQgGgGAAgMIAAgoIALAAIAAAoQAAAOAMAAQALAAAEgJIAAgtIALAAIAAA+IgLAAIAAgGQgGAHgLAAQgLAAgEgFg");
	this.shape_1.setTransform(80.4,-81.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgUAYQgIgJAAgPIAAAAQAAgJAEgHQADgIAHgEQAGgEAIAAQANAAAIAJQAIAJAAAOIAAABQAAAJgEAHQgDAIgHAEQgGAEgJAAQgMAAgIgJgAgMgRQgFAHAAALQAAAKAFAHQAFAGAHAAQAIAAAFgGQAFgHAAgLQAAgKgFgGQgFgHgIAAQgHAAgFAGg");
	this.shape_2.setTransform(73.7,-81.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgaAtIAAhXIAKAAIAAAHQAIgIAKAAQAMgBAGAJQAHAJAAAPIAAABQAAANgHAJQgGAJgMAAQgLAAgGgHIAAAfgAgPgZIAAAcQAFAKAKgBQAHAAAEgGQAFgGAAgLQAAgLgFgGQgEgHgHABQgKAAgFAJg");
	this.shape_3.setTransform(67,-80);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgTAcQgGgGAAgIQAAgKAHgEQAIgGANAAIAKAAIAAgFQAAgFgEgEQgCgDgHAAQgFAAgEADQgEADAAAEIgLAAQAAgFADgEQAEgFAGgCQAFgDAGAAQAMAAAFAGQAHAFAAAKIAAAcQAAAJACAFIAAABIgLAAIgBgHQgIAIgJAAQgKAAgGgFgAgOANQgBAFAEADQADACAGAAQAEAAAEgCQAFgDACgEIAAgNIgIAAQgUAAABAMg");
	this.shape_4.setTransform(60.2,-81.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgEArIgghVIANAAIAXBGIAYhGIANAAIggBVg");
	this.shape_5.setTransform(53.1,-82.3);

	this.instance = new lib.heatoutcopy();
	this.instance.parent = this;
	this.instance.setTransform(14.4,32,1,1,0,-90,90);

	this.instance_1 = new lib.heatoutcopy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-8,32,1,1,0,-90,90);

	this.instance_2 = new lib.heatoutcopy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-30.3,32,1,1,0,-90,90);

	this.instance_3 = new lib.heatoutcopy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(62.7,1.7,1,1,0,-90,90);

	this.instance_4 = new lib.vapo();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-14.9,17.5,0.969,0.969,0,0,0,-140.6,103.8);

	this.instance_5 = new lib.sasaas();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-13,40.1,0.398,0.398);
	this.instance_5.shadow = new cjs.Shadow("rgba(0,204,255,1)",0,0,23);

	this.instance_6 = new lib.Symbol2("synched",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(-13.5,48,0.398,0.398);
	this.instance_6.alpha = 0.59;

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAaBiQgdABgcgfIARgCIAIgCQAQAOARAAIABABQAPACAHgGQAFgHAAgQIAAheQgCgTgIgKQgIgIgPABIhWAAQgEAAgDgDQgDgDAAgEQAAgEADgDQADgDAEAAIBVAAQAZgBANAOQAOANACAcIAAABIAABeQABAbgNAMQgJAJgQAAIgMgBg");
	this.shape_6.setTransform(10.4,48.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("Ag+BaQgMgMABgbIAAheIAAgBQACgbANgOQANgOAZABIBUAAQAFAAADADQACADAAAEQAAAEgCADQgDADgFAAIhUAAIgBAAQgPgBgIAIQgIAJgBAUIAABeQgBAQAGAHQAHAGAOgCIABgBQAPAAAOgLIANACIAKABQAAAEgDACQgXAWgZAAIgLABQgRAAgJgJg");
	this.shape_7.setTransform(-38.1,48.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#333333").ss(0.6,1,1).p("AhGACIBAgCQABAAABAAQABAAABAAQAXgBAUABIAeAB");
	this.shape_8.setTransform(-12.8,39);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#807B82","#0D0B17","#8F8B9A"],[0.02,0.882,1],-0.9,5,0.9,-5).s().p("Aj0AmQhCgJgXgMQgMgHAAgHQAAgVBlgQQBlgPCPgBQCQgBBlAOQBlAOAAAWQAAAHgSAIQgYALg7AKQhlAPiQABIgZAAQh/AAhcgNgAAEgsQiBABhdANQhbANAAARQAAARBbAMQBdAMCBgBQCCgBBcgOQBcgMAAgRQAAgRhcgMQhVgLh1AAIgUAAg");
	this.shape_9.setTransform(-13.4,41.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#807B82","#FFFFFF","#C7C7C9","#7B7A80","#5D5B63","#0D0B17","#8F8B9A"],[0.02,0.102,0.165,0.463,0.792,0.882,1],-29.8,0,29.9,0).s().p("AjPA6IgUgDIgagDQhFgMAAgRIgIhXQAXAMBCAJQBlAPCPgCQCPgBBmgPQA6gKAZgLIgKBWQgBARhPAOIgPACIgkAFQhSAKhsAAIgVABQhqAAhQgKg");
	this.shape_10.setTransform(-13.7,49.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#333333").s().p("AhjATQgqgHAAgLIAAgBQADgJAngIIAggFIBAgDIACAAIABAAQAYAAAUABIAeACIAaADQAnAHADAKIAAABQAAAKgqAIQgpAIg7ABIgGAAQg2AAgngHg");
	this.shape_11.setTransform(-13.1,41.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["#807B82","#FFFFFF","#C7C7C9","#7B7A80","#5D5B63","#0D0B17","#8F8B9A"],[0.02,0.102,0.165,0.463,0.792,0.882,1],0,-5.7,0,5.8).s().p("AjdAfQhcgLAAgSQAAgQBcgNQBcgNCBgBQCCgBBcALQBcAMAAASQAAAQhcANQhcANiCABIgTAAQh1AAhVgLgAhDgRIghAFQgmAHgDAJIAAACQAAAKApAHQAqAIA6gBQA7gBApgHQAqgIAAgLIgBgCQgCgIgngHIgagEIgegCQgVgBgXABIgBAAIgCAAg");
	this.shape_12.setTransform(-13,41);

	this.instance_7 = new lib.Symbol1();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-13.5,59.2,0.398,0.398);
	this.instance_7.alpha = 0.379;
	this.instance_7.filters = [new cjs.BlurFilter(5, 5, 1)];
	this.instance_7.cache(-81,-6,163,11);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-84.1,-91.4,177.6,163.9);


// stage content:
(lib.Th_c = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_154 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(154).call(this.frame_154).wait(1));

	// Layer 12
	this.instance = new lib.Tween6("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(106.4,217);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},14).wait(141));

	// Layer 10
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#E2000F").ss(3,2,1).p("AgaAXIA1gt");
	this.shape.setTransform(77.7,369.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#E3000F").ss(3,2,1).p("AgnAiIBPhC");
	this.shape_1.setTransform(79,368.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#E3000E").ss(3,2,1).p("Ag0AsIBphX");
	this.shape_2.setTransform(80.3,367.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#E4000E").ss(3,2,1).p("AhCA3ICEht");
	this.shape_3.setTransform(81.7,366);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#E4000E").ss(3,2,1).p("AhPBCICfiD");
	this.shape_4.setTransform(83,364.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#E5000D").ss(3,2,1).p("AhcBNIC5iZ");
	this.shape_5.setTransform(84.3,363.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#E6000D").ss(3,2,1).p("AhpBYIDTiv");
	this.shape_6.setTransform(85.6,362.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#E6000D").ss(3,2,1).p("Ah2BjIDtjF");
	this.shape_7.setTransform(86.9,361.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#E7000D").ss(3,2,1).p("AiDBuIEHjb");
	this.shape_8.setTransform(88.2,360.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#E7000C").ss(3,2,1).p("AiQB5IEhjx");
	this.shape_9.setTransform(89.5,359.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#E8000C").ss(3,2,1).p("AidCEIE7kH");
	this.shape_10.setTransform(90.8,358.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#E9000C").ss(3,2,1).p("AirCPIFWkd");
	this.shape_11.setTransform(92.2,357.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#E9000B").ss(3,2,1).p("Ai4CaIFxkz");
	this.shape_12.setTransform(93.5,356.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#EA000B").ss(3,2,1).p("AjFClIGLlJ");
	this.shape_13.setTransform(94.8,355);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#EA000B").ss(3,2,1).p("AjSCwIGllf");
	this.shape_14.setTransform(96.1,353.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#EB000A").ss(3,2,1).p("AjfC6IG/l0");
	this.shape_15.setTransform(97.4,352.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#EB000A").ss(3,2,1).p("AjsDGIHZmL");
	this.shape_16.setTransform(98.7,351.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#EC000A").ss(3,2,1).p("Aj5DRIHzmg");
	this.shape_17.setTransform(100,350.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#ED0009").ss(3,2,1).p("AkGDbIINm1");
	this.shape_18.setTransform(101.3,349.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#ED0009").ss(3,2,1).p("AkUDmIIpnL");
	this.shape_19.setTransform(102.7,348.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#EE0009").ss(3,2,1).p("AkhDxIJDnh");
	this.shape_20.setTransform(104,347.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#EE0009").ss(3,2,1).p("AkuD8IJdn3");
	this.shape_21.setTransform(105.3,346.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#EF0008").ss(3,2,1).p("Ak7EHIJ3oN");
	this.shape_22.setTransform(106.6,345.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#F00008").ss(3,2,1).p("AlIESIKRoj");
	this.shape_23.setTransform(107.9,344.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#F00008").ss(3,2,1).p("AlVEdIKro5");
	this.shape_24.setTransform(109.2,343);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#F10007").ss(3,2,1).p("AliEoILFpP");
	this.shape_25.setTransform(110.5,341.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#F10007").ss(3,2,1).p("AlvEzILfpl");
	this.shape_26.setTransform(111.8,340.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#F20007").ss(3,2,1).p("Al9E+IL7p7");
	this.shape_27.setTransform(113.2,339.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#F30006").ss(3,2,1).p("AmKFJIMVqR");
	this.shape_28.setTransform(114.5,338.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#F30006").ss(3,2,1).p("AmXFUIMvqn");
	this.shape_29.setTransform(115.8,337.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#F40006").ss(3,2,1).p("AmkFfINJq9");
	this.shape_30.setTransform(117.1,336.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#F40006").ss(3,2,1).p("AmxFpINjrS");
	this.shape_31.setTransform(118.4,335.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#F50005").ss(3,2,1).p("Am+F1IN9rp");
	this.shape_32.setTransform(119.7,334.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#F60005").ss(3,2,1).p("AnLGAIOXr+");
	this.shape_33.setTransform(121,333.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#F60005").ss(3,2,1).p("AnYGKIOxsT");
	this.shape_34.setTransform(122.3,332.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#F70004").ss(3,2,1).p("AnmGVIPNsp");
	this.shape_35.setTransform(123.7,331);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#F70004").ss(3,2,1).p("AnzGgIPns/");
	this.shape_36.setTransform(125,329.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#F80004").ss(3,2,1).p("AoAGrIQBtV");
	this.shape_37.setTransform(126.3,328.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#F80003").ss(3,2,1).p("AoNG2IQbtr");
	this.shape_38.setTransform(127.6,327.7);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#F90003").ss(3,2,1).p("AoaHBIQ1uB");
	this.shape_39.setTransform(128.9,326.6);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#FA0003").ss(3,2,1).p("AonHMIRPuX");
	this.shape_40.setTransform(130.2,325.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#FA0002").ss(3,2,1).p("Ao0HXIRput");
	this.shape_41.setTransform(131.5,324.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#FB0002").ss(3,2,1).p("ApBHiISDvD");
	this.shape_42.setTransform(132.8,323.3);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#FB0002").ss(3,2,1).p("ApPHtISfvZ");
	this.shape_43.setTransform(134.2,322.2);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#FC0002").ss(3,2,1).p("ApbH4IS4vv");
	this.shape_44.setTransform(135.5,321.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#FD0001").ss(3,2,1).p("AppIDITTwF");
	this.shape_45.setTransform(136.8,320);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#FD0001").ss(3,2,1).p("Ap2IOITtwb");
	this.shape_46.setTransform(138.1,318.9);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#FE0001").ss(3,2,1).p("AqDIYIUHww");
	this.shape_47.setTransform(139.4,317.9);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#FE0000").ss(3,2,1).p("AqQIkIUhxH");
	this.shape_48.setTransform(140.7,316.8);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#FF0000").ss(3,2,1).p("AqdIvIU7xc");
	this.shape_49.setTransform(142,315.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).wait(106));

	// Layer 9
	this.instance_1 = new lib.Tween8("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(303.7,201.2);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(50).to({_off:false},0).to({alpha:1},17).wait(88));

	// Layer 6
	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#417FB8").ss(3,2,1).p("AgqAAIBVAA");
	this.shape_50.setTransform(215.3,259.8);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#417FB8").ss(3,2,1).p("Ag3AAIBvAA");
	this.shape_51.setTransform(216.6,259.8);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#417FB8").ss(3,2,1).p("AhEAAICJAA");
	this.shape_52.setTransform(217.9,259.8);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#417FB8").ss(3,2,1).p("AhSAAIClAA");
	this.shape_53.setTransform(219.3,259.8);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#417FB8").ss(3,2,1).p("AhfAAIC/AA");
	this.shape_54.setTransform(220.6,259.8);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#417FB8").ss(3,2,1).p("AhsAAIDZAA");
	this.shape_55.setTransform(221.9,259.8);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#417FB8").ss(3,2,1).p("Ah5AAIDzAA");
	this.shape_56.setTransform(223.2,259.8);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#417FB8").ss(3,2,1).p("AiGAAIENAA");
	this.shape_57.setTransform(224.5,259.8);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#417FB8").ss(3,2,1).p("AiTAAIEnAA");
	this.shape_58.setTransform(225.9,259.8);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#417FB8").ss(3,2,1).p("AihAAIFDAA");
	this.shape_59.setTransform(227.2,259.8);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#417FB8").ss(3,2,1).p("AiuAAIFdAA");
	this.shape_60.setTransform(228.5,259.8);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#417FB8").ss(3,2,1).p("Ai7AAIF3AA");
	this.shape_61.setTransform(229.8,259.8);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#417FB8").ss(3,2,1).p("AjJAAIGTAA");
	this.shape_62.setTransform(231.2,259.8);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#417FB8").ss(3,2,1).p("AjWAAIGtAA");
	this.shape_63.setTransform(232.5,259.8);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#417FB8").ss(3,2,1).p("AjjAAIHHAA");
	this.shape_64.setTransform(233.8,259.8);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#417FB8").ss(3,2,1).p("AjwAAIHhAA");
	this.shape_65.setTransform(235.1,259.8);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#417FB8").ss(3,2,1).p("Aj9AAIH7AA");
	this.shape_66.setTransform(236.5,259.8);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#417FB8").ss(3,2,1).p("AkLAAIIXAA");
	this.shape_67.setTransform(237.8,259.8);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#417FB8").ss(3,2,1).p("AkYAAIIxAA");
	this.shape_68.setTransform(239.1,259.8);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#417FB8").ss(3,2,1).p("AklAAIJLAA");
	this.shape_69.setTransform(240.4,259.8);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#417FB8").ss(3,2,1).p("AkzAAIJnAA");
	this.shape_70.setTransform(241.8,259.8);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#417FB8").ss(3,2,1).p("AlAAAIKBAA");
	this.shape_71.setTransform(243.1,259.8);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#417FB8").ss(3,2,1).p("AlNAAIKbAA");
	this.shape_72.setTransform(244.4,259.8);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#417FB8").ss(3,2,1).p("AlaAAIK1AA");
	this.shape_73.setTransform(245.7,259.8);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#417FB8").ss(3,2,1).p("AlnAAILPAA");
	this.shape_74.setTransform(247,259.8);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#417FB8").ss(3,2,1).p("Al0AAILpAA");
	this.shape_75.setTransform(248.4,259.8);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#417FB8").ss(3,2,1).p("AmCAAIMFAA");
	this.shape_76.setTransform(249.7,259.8);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("#417FB8").ss(3,2,1).p("AmPAAIMfAA");
	this.shape_77.setTransform(251,259.8);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#417FB8").ss(3,2,1).p("AmcAAIM5AA");
	this.shape_78.setTransform(252.3,259.8);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#417FB8").ss(3,2,1).p("AmqAAINVAA");
	this.shape_79.setTransform(253.7,259.8);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#417FB8").ss(3,2,1).p("Am3AAINvAA");
	this.shape_80.setTransform(255,259.8);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f().s("#417FB8").ss(3,2,1).p("AnEAAIOJAA");
	this.shape_81.setTransform(256.3,259.8);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("#417FB8").ss(3,2,1).p("AnRAAIOjAA");
	this.shape_82.setTransform(257.6,259.8);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f().s("#417FB8").ss(3,2,1).p("AneAAIO9AA");
	this.shape_83.setTransform(258.9,259.8);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("#417FB8").ss(3,2,1).p("AnsAAIPZAA");
	this.shape_84.setTransform(260.3,259.8);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f().s("#417FB8").ss(3,2,1).p("An5AAIPzAA");
	this.shape_85.setTransform(261.6,259.8);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#417FB8").ss(3,2,1).p("AoGAAIQNAA");
	this.shape_86.setTransform(262.9,259.8);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f().s("#417FB8").ss(3,2,1).p("AoTAAIQnAA");
	this.shape_87.setTransform(264.2,259.8);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("#417FB8").ss(3,2,1).p("AohAAIRDAA");
	this.shape_88.setTransform(265.6,259.8);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f().s("#417FB8").ss(3,2,1).p("AouAAIRdAA");
	this.shape_89.setTransform(266.9,259.8);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("#417FB8").ss(3,2,1).p("Ao7AAIR3AA");
	this.shape_90.setTransform(268.2,259.8);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f().s("#417FB8").ss(3,2,1).p("ApIAAISRAA");
	this.shape_91.setTransform(269.5,259.8);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f().s("#417FB8").ss(3,2,1).p("ApWAAISsAA");
	this.shape_92.setTransform(270.9,259.8);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f().s("#417FB8").ss(3,2,1).p("ApjAAITHAA");
	this.shape_93.setTransform(272.2,259.8);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f().s("#417FB8").ss(3,2,1).p("ApwAAIThAA");
	this.shape_94.setTransform(273.5,259.8);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f().s("#417FB8").ss(3,2,1).p("Ap9AAIT7AA");
	this.shape_95.setTransform(274.8,259.8);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f().s("#417FB8").ss(3,2,1).p("AqKAAIUWAA");
	this.shape_96.setTransform(276.2,259.8);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f().s("#417FB8").ss(3,2,1).p("AqXAAIUvAA");
	this.shape_97.setTransform(277.5,259.8);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f().s("#417FB8").ss(3,2,1).p("AqlAAIVLAA");
	this.shape_98.setTransform(278.8,259.8);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f().s("#417FB8").ss(3,2,1).p("AqyAAIVlAA");
	this.shape_99.setTransform(280.1,259.8);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f().s("#417FB8").ss(3,2,1).p("Aq/AAIV/AA");
	this.shape_100.setTransform(281.4,259.8);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f().s("#417FB8").ss(3,2,1).p("ArNAAIWbAA");
	this.shape_101.setTransform(282.8,259.8);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f().s("#417FB8").ss(3,2,1).p("AraAAIW1AA");
	this.shape_102.setTransform(284.1,259.8);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f().s("#417FB8").ss(3,2,1).p("ArnAAIXPAA");
	this.shape_103.setTransform(285.4,259.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_50}]},50).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).wait(52));

	// Layer 11
	this.instance_2 = new lib.Tween9("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(479.8,264);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(104).to({_off:false},0).to({alpha:1},17).wait(34));

	// Layer 7
	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f().s("#E2000F").ss(3,2,1).p("AgoAiIBRhD");
	this.shape_104.setTransform(363.9,256.4);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f().s("#E3000F").ss(3,2,1).p("Ag0AsIBqhY");
	this.shape_105.setTransform(365.2,255.4);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f().s("#E3000E").ss(3,2,1).p("AhBA3ICDht");
	this.shape_106.setTransform(366.4,254.3);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f().s("#E4000E").ss(3,2,1).p("AhOBCICdiD");
	this.shape_107.setTransform(367.7,253.3);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f().s("#E4000E").ss(3,2,1).p("AhaBMIC1iX");
	this.shape_108.setTransform(368.9,252.2);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f().s("#E5000D").ss(3,2,1).p("AhnBXIDPis");
	this.shape_109.setTransform(370.2,251.2);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f().s("#E5000D").ss(3,2,1).p("Ah0BhIDojB");
	this.shape_110.setTransform(371.5,250.1);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f().s("#E6000D").ss(3,2,1).p("AiABsIEBjX");
	this.shape_111.setTransform(372.7,249.1);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f().s("#E7000D").ss(3,2,1).p("AiNB2IEbjr");
	this.shape_112.setTransform(374,248);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f().s("#E7000C").ss(3,2,1).p("AiZCBIEzkA");
	this.shape_113.setTransform(375.2,247);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f().s("#E8000C").ss(3,2,1).p("AimCLIFNkV");
	this.shape_114.setTransform(376.5,245.9);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f().s("#E8000C").ss(3,2,1).p("AiyCVIFlkq");
	this.shape_115.setTransform(377.8,244.9);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f().s("#E9000B").ss(3,2,1).p("Ai/CgIF/k/");
	this.shape_116.setTransform(379,243.8);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f().s("#EA000B").ss(3,2,1).p("AjLCqIGXlT");
	this.shape_117.setTransform(380.3,242.8);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f().s("#EA000B").ss(3,2,1).p("AjYC1IGxlp");
	this.shape_118.setTransform(381.5,241.7);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f().s("#EB000A").ss(3,2,1).p("AjlC/IHLl9");
	this.shape_119.setTransform(382.8,240.7);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f().s("#EB000A").ss(3,2,1).p("AjxDKIHjmT");
	this.shape_120.setTransform(384,239.6);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f().s("#EC000A").ss(3,2,1).p("Aj+DUIH9mn");
	this.shape_121.setTransform(385.3,238.6);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f().s("#EC000A").ss(3,2,1).p("AkLDfIIXm9");
	this.shape_122.setTransform(386.6,237.5);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f().s("#ED0009").ss(3,2,1).p("AkXDpIIvnR");
	this.shape_123.setTransform(387.8,236.5);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f().s("#EE0009").ss(3,2,1).p("AkkD0IJJnn");
	this.shape_124.setTransform(389.1,235.4);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f().s("#EE0009").ss(3,2,1).p("AkwD+IJhn7");
	this.shape_125.setTransform(390.3,234.4);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f().s("#EF0008").ss(3,2,1).p("Ak9EJIJ7oR");
	this.shape_126.setTransform(391.6,233.3);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f().s("#EF0008").ss(3,2,1).p("AlKETIKUol");
	this.shape_127.setTransform(392.9,232.3);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f().s("#F00008").ss(3,2,1).p("AlWEeIKto7");
	this.shape_128.setTransform(394.1,231.2);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f().s("#F10008").ss(3,2,1).p("AljEoILHpP");
	this.shape_129.setTransform(395.4,230.2);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f().s("#F10007").ss(3,2,1).p("AlvEzILfpl");
	this.shape_130.setTransform(396.6,229.1);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f().s("#F20007").ss(3,2,1).p("Al8E9IL5p5");
	this.shape_131.setTransform(397.9,228.1);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f().s("#F20007").ss(3,2,1).p("AmIFIIMSqP");
	this.shape_132.setTransform(399.2,227);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f().s("#F30006").ss(3,2,1).p("AmVFSIMrqj");
	this.shape_133.setTransform(400.4,226);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f().s("#F30006").ss(3,2,1).p("AmhFdINEq5");
	this.shape_134.setTransform(401.7,224.9);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f().s("#F40006").ss(3,2,1).p("AmuFnINdrN");
	this.shape_135.setTransform(402.9,223.9);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f().s("#F50005").ss(3,2,1).p("Am7FyIN3rj");
	this.shape_136.setTransform(404.2,222.8);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f().s("#F50005").ss(3,2,1).p("AnHF8IOPr3");
	this.shape_137.setTransform(405.4,221.8);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f().s("#F60005").ss(3,2,1).p("AnUGHIOpsN");
	this.shape_138.setTransform(406.7,220.7);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f().s("#F60005").ss(3,2,1).p("AnhGRIPCsh");
	this.shape_139.setTransform(408,219.7);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f().s("#F70004").ss(3,2,1).p("AntGcIPbs3");
	this.shape_140.setTransform(409.2,218.6);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f().s("#F70004").ss(3,2,1).p("An6GmIP1tL");
	this.shape_141.setTransform(410.5,217.6);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f().s("#F80004").ss(3,2,1).p("AoGGxIQNth");
	this.shape_142.setTransform(411.7,216.6);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f().s("#F90003").ss(3,2,1).p("AoTG7IQnt1");
	this.shape_143.setTransform(413,215.5);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f().s("#F90003").ss(3,2,1).p("AofHFIQ/uK");
	this.shape_144.setTransform(414.3,214.5);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f().s("#FA0003").ss(3,2,1).p("AosHQIRZuf");
	this.shape_145.setTransform(415.5,213.4);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f().s("#FA0002").ss(3,2,1).p("Ao4HaIRxu0");
	this.shape_146.setTransform(416.8,212.4);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f().s("#FB0002").ss(3,2,1).p("ApFHlISLvJ");
	this.shape_147.setTransform(418,211.3);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f().s("#FC0002").ss(3,2,1).p("ApSHwISlvf");
	this.shape_148.setTransform(419.3,210.3);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f().s("#FC0002").ss(3,2,1).p("ApeH6IS9vz");
	this.shape_149.setTransform(420.5,209.2);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f().s("#FD0001").ss(3,2,1).p("AprIFITXwI");
	this.shape_150.setTransform(421.8,208.2);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f().s("#FD0001").ss(3,2,1).p("Ap4IPITxwd");
	this.shape_151.setTransform(423.1,207.1);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f().s("#FE0001").ss(3,2,1).p("AqEIaIUJwz");
	this.shape_152.setTransform(424.3,206.1);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f().s("#FE0000").ss(3,2,1).p("AqRIkIUjxH");
	this.shape_153.setTransform(425.6,205);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f().s("#FF0000").ss(3,2,1).p("AqdIvIU7xd");
	this.shape_154.setTransform(426.8,204);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_104}]},104).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).to({state:[{t:this.shape_135}]},1).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_138}]},1).to({state:[{t:this.shape_139}]},1).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[{t:this.shape_150}]},1).to({state:[{t:this.shape_151}]},1).to({state:[{t:this.shape_152}]},1).to({state:[{t:this.shape_153}]},1).to({state:[{t:this.shape_154}]},1).wait(1));

	// Layer 8
	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#333333").s().p("AAAXAIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAVIIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAATQIAAgBIgBgBIAAg8IABgCIAAAAIABAAIABACIAAA8IgBABIgBABIAAAAgAAARYIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAPgIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAANoIAAgBIgBgBIAAg8IABgCIAAAAIABAAIABACIAAA8IgBABIgBABIAAAAgAAALwIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAJ4IAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAIAIAAgBIgBgBIAAg8IABgCIAAAAIABAAIABACIAAA8IgBABIgBABIAAAAgAAAGIIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAEQIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAACYIAAgBIgBgBIAAg8IABgCIAAAAIABAAIABACIAAA8IgBABIgBABIAAAAgAAAAgIAAAAIgBgCIAAg7IABgBIAAgBIABABIABABIAAA7IgBACIgBAAIAAAAgAAAhXIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAjPIAAgBIgBgBIAAg8IABgCIAAAAIABAAIABACIAAA8IgBABIgBABIAAAAgAAAlHIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAm/IAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAo3IAAgBIgBgBIAAg8IABgCIAAAAIABAAIABACIAAA8IgBABIgBABIAAAAgAAAqvIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAsnIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAufIAAgBIgBgBIAAg8IABgCIAAAAIABAAIABACIAAA8IgBABIgBABIAAAAgAAAwXIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAyPIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAA0HIAAgBIgBgBIAAg8IABgCIAAAAIABAAIABACIAAA8IgBABIgBABIAAAAgAAA1/IAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAg");
	this.shape_155.setTransform(209.1,200.2);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#333333").s().p("AAAXAIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAVIIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAATQIAAgBIgBgBIAAg8IABgCIAAAAIABAAIABACIAAA8IgBABIgBABIAAAAgAAARYIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAPgIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAANoIAAgBIgBgBIAAg8IABgCIAAAAIABAAIABACIAAA8IgBABIgBABIAAAAgAAALwIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAJ4IAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAIAIAAgBIgBgBIAAg8IABgCIAAAAIABAAIABACIAAA8IgBABIgBABIAAAAgAAAGIIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAEQIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAACYIAAgBIgBgBIAAg8IABgCIAAAAIABAAIABACIAAA8IgBABIgBABIAAAAgAAAAgIAAAAIgBgCIAAg7IABgBIAAgBIABABIABABIAAA7IgBACIgBAAIAAAAgAAAhXIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAjPIAAgBIgBgBIAAg8IABgCIAAAAIABAAIABACIAAA8IgBABIgBABIAAAAgAAAlHIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAm/IAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAo3IAAgBIgBgBIAAg8IABgCIAAAAIABAAIABACIAAA8IgBABIgBABIAAAAgAAAqvIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAsnIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAufIAAgBIgBgBIAAg8IABgCIAAAAIABAAIABACIAAA8IgBABIgBABIAAAAgAAAwXIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAAyPIAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAgAAA0HIAAgBIgBgBIAAg8IABgCIAAAAIABAAIABACIAAA8IgBABIgBABIAAAAgAAA1/IAAAAIgBgCIAAg8IABgBIAAgBIABABIABABIAAA8IgBACIgBAAIAAAAg");
	this.shape_156.setTransform(359.5,200.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_156},{t:this.shape_155}]}).to({state:[{t:this.shape_156},{t:this.shape_155}]},154).wait(1));

	// Layer 1
	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#000000").s().p("AgPA4QAKgIAFgOQAEgPABgRIAAgCQAAgMgDgKQgCgLgEgIQgFgJgGgEIADgHQAHAFAHAJQAHAKADANQADAMAAANQAAANgDAMQgDALgHAKQgHALgHAEg");
	this.shape_157.setTransform(601,107.3);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#000000").s().p("AgMAeQgGgCgDgFQgDgFAAgGIALAAQAAAGAEADQAEADAGAAQAGAAAEgCQADgDAAgEQAAgEgDgDQgDgCgIgCQgIgCgFgCQgEgCgDgDQgCgEAAgEQAAgIAHgFQAGgGAJAAQALAAAHAGQAHAFAAAJIgLAAQAAgEgEgEQgEgDgGAAQgEAAgEADQgDACAAAEQAAAEADACIAKAEQAIACAFACQAFACADAEQACADAAAFQAAAJgHAFQgGAFgLAAQgHAAgGgDg");
	this.shape_158.setTransform(596.1,107.6);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#000000").s().p("AAiAgIAAgpQAAgGgEgEQgDgDgHAAQgGAAgEAEQgEADAAAGIAAApIgLAAIAAgoQAAgOgNAAQgKAAgFAJIAAAtIgLAAIAAg+IALAAIAAAHQAHgIAMAAQAOAAADAKQADgFAFgDQAGgCAHAAQAUAAABAWIAAApg");
	this.shape_159.setTransform(587.8,107.5);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#000000").s().p("AgBAkQgEgFAAgIIAAgmIgLAAIAAgJIALAAIAAgPIAKAAIAAAPIAMAAIAAAJIgMAAIAAAmQAAAEACACQABACAEAAIAFgBIAAAJIgIABQgHAAgDgEg");
	this.shape_160.setTransform(580.4,106.9);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#000000").s().p("AgTAcQgGgGAAgIQAAgKAIgEQAHgGAMAAIALAAIAAgFQAAgFgDgEQgDgDgHAAQgFAAgEADQgEADAAAEIgLAAQAAgFADgEQAEgFAFgCQAGgDAHAAQAKAAAHAGQAGAFAAAKIAAAcQAAAJACAFIAAABIgLAAIgCgHQgHAIgKAAQgJAAgGgFgAgOANQAAAFADADQADACAGAAQAEAAAEgCQAFgDACgEIAAgNIgJAAQgSAAAAAMg");
	this.shape_161.setTransform(575.3,107.6);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#000000").s().p("AgBAvQgNgTAAgcQAAgMADgMQAEgNAHgKQAGgJAHgFIACAIQgIAGgGAOQgEANgBAQIAAAFQAAAWAIARQAFAKAGAGIgCAGQgIgEgGgLg");
	this.shape_162.setTransform(570.3,107.3);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#000000").s().p("AgPAgIAAg+IAMAAIAAAHQAEgIAJAAIAGABIAAAKIgGgBQgKAAgDAJIAAAsg");
	this.shape_163.setTransform(566.3,107.5);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#000000").s().p("AgTAcQgGgGAAgIQAAgKAHgEQAIgGANAAIAKAAIAAgFQAAgFgEgEQgCgDgHAAQgFAAgEADQgEADAAAEIgLAAQAAgFAEgEQADgFAFgCQAGgDAGAAQAMAAAFAGQAHAFAAAKIAAAcQAAAJACAFIAAABIgLAAIgBgHQgIAIgJAAQgKAAgGgFgAgOANQgBAFAEADQADACAGAAQAEAAAEgCQAFgDACgEIAAgNIgIAAQgUAAABAMg");
	this.shape_164.setTransform(560.6,107.6);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#000000").s().p("AgQAlIAAAIIgKAAIAAhZIALAAIAAAhQAGgIALAAQAMAAAGAIQAHAKAAANIAAABQAAAPgHAJQgHAJgLAAQgKAAgIgJgAgPAAIAAAbQAFAJAKABQAIgBADgGQAFgFAAgNQAAgLgEgFQgEgGgIAAQgLAAgEAKg");
	this.shape_165.setTransform(554.1,106.3);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#000000").s().p("AAGArIAAhHIgVAIIAAgKIAegMIABAAIAABVg");
	this.shape_166.setTransform(543.5,106.5);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#000000").s().p("AgNAEIAAgHIAcAAIAAAHg");
	this.shape_167.setTransform(536.3,107.1);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#000000").s().p("AgSAYQgIgIAAgOIAAgCQAAgJAEgHQADgHAHgFQAGgEAHAAQAMAAAHAIQAHAIAAAQIAAADIgqAAQAAAKAGAFQAFAGAHAAQAGAAAEgCIAHgGIAGAFQgIAMgQAAQgMAAgIgJgAgJgSQgFAFgBAIIAfAAIAAgBQAAgIgEgEQgEgFgHAAQgGAAgEAFg");
	this.shape_168.setTransform(528.6,107.6);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#000000").s().p("AgOAgIAAg+IALAAIAAAHQAEgIAKAAIAEABIAAAKIgFgBQgKAAgDAJIAAAsg");
	this.shape_169.setTransform(523.7,107.5);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#000000").s().p("AgTAbQgFgGAAgMIAAgoIALAAIAAAoQAAAOALAAQAMAAAEgJIAAgtIALAAIAAA+IgLAAIAAgGQgGAHgLAAQgKAAgGgFg");
	this.shape_170.setTransform(518.1,107.6);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#000000").s().p("AgMAeQgGgCgDgFQgDgFAAgGIALAAQAAAGAEADQAEADAGAAQAGAAAEgCQADgDAAgEQAAgEgDgDQgDgCgIgCQgIgCgFgCQgEgCgDgDQgCgEAAgEQAAgIAHgFQAGgGAJAAQALAAAHAGQAHAFAAAJIgLAAQAAgEgEgEQgEgDgGAAQgEAAgEADQgDACAAAEQAAAEADACIAKAEQAIACAFACQAFACADAEQACADAAAFQAAAJgHAFQgGAFgLAAQgHAAgGgDg");
	this.shape_171.setTransform(511.6,107.6);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#000000").s().p("AgMAeQgGgCgDgFQgDgFAAgGIALAAQAAAGAEADQAEADAGAAQAGAAAEgCQADgDAAgEQAAgEgDgDQgDgCgIgCQgIgCgFgCQgEgCgDgDQgCgEAAgEQAAgIAHgFQAGgGAJAAQALAAAHAGQAHAFAAAJIgLAAQAAgEgEgEQgEgDgGAAQgEAAgEADQgDACAAAEQAAAEADACIAKAEQAIACAFACQAFACADAEQACADAAAFQAAAJgHAFQgGAFgLAAQgHAAgGgDg");
	this.shape_172.setTransform(505.4,107.6);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#000000").s().p("AgSAYQgIgIAAgOIAAgCQAAgJAEgHQADgHAHgFQAGgEAHAAQAMAAAHAIQAHAIAAAQIAAADIgqAAQAAAKAGAFQAFAGAHAAQAGAAAEgCIAHgGIAGAFQgIAMgQAAQgMAAgIgJgAgJgSQgFAFgBAIIAfAAIAAgBQAAgIgEgEQgEgFgHAAQgGAAgEAFg");
	this.shape_173.setTransform(499.3,107.6);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#000000").s().p("AgOAgIAAg+IALAAIAAAHQAEgIAJAAIAFABIAAAKIgFgBQgKAAgDAJIAAAsg");
	this.shape_174.setTransform(494.4,107.5);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#000000").s().p("AgeArIAAhVIAfAAQAOAAAIAIQAIAHAAAMQAAAMgIAGQgIAGgOAAIgUAAIAAAigAgTAAIAUAAQAJAAAEgDQAFgEAAgIQAAgIgFgFQgEgEgJAAIgUAAg");
	this.shape_175.setTransform(488.5,106.5);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#000000").s().p("AgBAkQgEgFAAgIIAAgmIgLAAIAAgJIALAAIAAgPIAKAAIAAAPIAMAAIAAAJIgMAAIAAAmQAAAEACACQABACAEAAIAFgBIAAAJIgIABQgHAAgDgEg");
	this.shape_176.setTransform(479.4,106.9);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#000000").s().p("AAOAgIAAgpQAAgHgDgDQgDgDgGAAQgFAAgDADQgEADgDAEIAAAsIgLAAIAAg+IALAAIAAAIQAHgJALAAQAUAAAAAWIAAApg");
	this.shape_177.setTransform(474.3,107.5);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#000000").s().p("AgTAcQgGgGAAgIQAAgKAHgEQAIgGAMAAIALAAIAAgFQAAgFgEgEQgCgDgHAAQgFAAgEADQgEADAAAEIgLAAQAAgFAEgEQADgFAGgCQAGgDAFAAQAMAAAFAGQAHAFAAAKIAAAcQAAAJACAFIAAABIgLAAIgBgHQgIAIgJAAQgKAAgGgFgAgPANQAAAFAEADQAEACAFAAQAEAAAFgCQAEgDACgEIAAgNIgIAAQgUAAAAAMg");
	this.shape_178.setTransform(467.7,107.6);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#000000").s().p("AgBAkQgEgFAAgIIAAgmIgLAAIAAgJIALAAIAAgPIAKAAIAAAPIAMAAIAAAJIgMAAIAAAmQAAAEACACQABACAEAAIAFgBIAAAJIgIABQgHAAgDgEg");
	this.shape_179.setTransform(462.3,106.9);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#000000").s().p("AgMAeQgGgCgDgFQgDgFAAgGIALAAQAAAGAEADQAEADAGAAQAGAAAEgCQADgDAAgEQAAgEgDgDQgDgCgIgCQgIgCgFgCQgEgCgDgDQgCgEAAgEQAAgIAHgFQAGgGAJAAQALAAAHAGQAHAFAAAJIgLAAQAAgEgEgEQgEgDgGAAQgEAAgEADQgDACAAAEQAAAEADACIAKAEQAIACAFACQAFACADAEQACADAAAFQAAAJgHAFQgGAFgLAAQgHAAgGgDg");
	this.shape_180.setTransform(457.4,107.6);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#000000").s().p("AAOAgIAAgpQAAgHgDgDQgDgDgHAAQgEAAgEADQgEADgCAEIAAAsIgLAAIAAg+IALAAIAAAIQAHgJALAAQAUAAAAAWIAAApg");
	this.shape_181.setTransform(451.1,107.5);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#000000").s().p("AgUAYQgIgJAAgPIAAAAQAAgJAEgHQADgIAHgEQAGgEAIAAQANAAAIAJQAIAJAAAOIAAABQAAAJgEAHQgDAIgHAEQgGAEgJAAQgMAAgIgJgAgMgRQgFAHAAALQAAAKAFAHQAFAGAHAAQAIAAAFgGQAFgHAAgLQAAgKgFgGQgFgHgIAAQgHAAgFAGg");
	this.shape_182.setTransform(444.3,107.6);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#000000").s().p("AgXAhQgJgLAAgSIAAgHQAAgMAFgJQAEgJAIgFQAHgFAKAAQANAAAIAIQAJAHABAOIgLAAQgCgKgFgFQgFgFgIAAQgKAAgGAIQgGAIAAAPIAAAHQAAAOAFAJQAGAIAKAAQAJAAAFgEQAFgFACgKIALAAQgCANgIAIQgIAHgOAAQgPAAgJgLg");
	this.shape_183.setTransform(437.1,106.5);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#000000").s().p("AgOA3QAJgGAFgPQAFgPAAgSIAAgBQAAgLgDgLQgCgLgEgIQgFgJgFgEIACgHQAIAEAGALQAHAKAEALQACAMAAANQAAANgCAMQgEANgHAKQgGAKgIAEg");
	this.shape_184.setTransform(355.9,404.4);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#000000").s().p("AAOAtIAAgqQAAgGgDgDQgDgEgHAAQgEABgEADQgEADgCADIAAAtIgLAAIAAhZIALAAIAAAiQAHgIALgBQAUABAAAVIAAAqg");
	this.shape_185.setTransform(350.8,403.3);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#000000").s().p("AgBAwQgNgVAAgbQAAgNADgMQAEgLAHgKQAGgLAHgEIACAHQgIAHgGANQgEAOgBARIAAADQAAAXAIARQAFAKAGAFIgCAHQgIgFgGgJg");
	this.shape_186.setTransform(345.7,404.4);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#000000").s().p("AgTAsIgEgBIAAgIIADAAQAGAAADgCQADgDACgGIACgFIgWg+IAMAAIAPAuIAOguIAMAAIgZBIQgGAPgMAAg");
	this.shape_187.setTransform(337.6,405.9);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#000000").s().p("AgaAsIAAhWIAKAAIABAGQAHgHAKgBQALAAAHAJQAHAIAAAQIAAABQAAANgHAKQgHAIgLAAQgLAAgGgHIAAAegAgPgaIAAAeQAFAIAKABQAHgBAEgGQAFgGAAgLQAAgLgFgGQgEgHgHAAQgKABgFAIg");
	this.shape_188.setTransform(331.5,405.8);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#000000").s().p("AgFAtIAAhZIAKAAIAABZg");
	this.shape_189.setTransform(326.6,403.3);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#000000").s().p("AgTAcQgGgGAAgIQAAgKAHgEQAIgGAMAAIALAAIAAgFQAAgFgEgEQgCgDgHAAQgFAAgEADQgEADAAAEIgLAAQAAgFAEgEQADgFAGgCQAGgDAFAAQAMAAAFAGQAHAFAAAKIAAAcQAAAJACAFIAAABIgLAAIgBgHQgIAIgJAAQgKAAgGgFgAgPANQAAAFAEADQADACAGAAQAEAAAFgCQAEgDACgEIAAgNIgIAAQgUAAAAAMg");
	this.shape_190.setTransform(321.8,404.6);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#000000").s().p("AAOAtIAAgqQAAgGgDgDQgDgEgHAAQgEABgEADQgEADgCADIAAAtIgLAAIAAhZIALAAIAAAiQAHgIALgBQAUABAAAVIAAAqg");
	this.shape_191.setTransform(315.3,403.3);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#000000").s().p("AgBAkQgEgFAAgIIAAgmIgLAAIAAgJIALAAIAAgPIAKAAIAAAPIAMAAIAAAJIgMAAIAAAmQAAAEACACQABACAEAAIAFgBIAAAJIgIABQgHAAgDgEg");
	this.shape_192.setTransform(309.8,403.9);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#000000").s().p("AAOAgIAAgpQAAgHgDgDQgDgDgGAAQgFAAgDADQgFADgCAEIAAAsIgLAAIAAg+IAKAAIABAIQAHgJALAAQAUAAAAAWIAAApg");
	this.shape_193.setTransform(304.8,404.6);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#000000").s().p("AgaArIAAhVIA0AAIAAAKIgpAAIAAAbIAkAAIAAAIIgkAAIAAAfIAqAAIAAAJg");
	this.shape_194.setTransform(298.4,403.5);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#000000").s().p("AA5ASIgKgJQgGgFgHgDQgIgDgHgCQgJgCgKAAQgJAAgIACIgQAFQgIADgFAFQgGAEgEAFIgBAAIAAgOQAMgJAOgGQAPgGAQAAQARAAAOAGQAOAGAMAJIAAAOg");
	this.shape_195.setTransform(15,20.6);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#000000").s().p("AgSAhQgJgDgFgGQgGgFgDgIQgDgIAAgJQAAgHACgHQABgHAFgIIANAAIAAABQgGAHgCAHQgDAHAAAIQAAAGACAFQACAFAFAEQAEAEAHADQAGACAIAAQAJAAAHgDQAHgCAEgEQAEgEACgGQACgFAAgFQAAgIgDgIQgCgHgGgHIAAAAIANAAIADAFIADAHIACAIIAAAJQAAAJgCAIQgDAHgGAGQgFAGgJADQgIADgMAAQgKAAgIgDg");
	this.shape_196.setTransform(13.9,27.4);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#000000").s().p("AgMAZQgFgCgEgEQgDgDgDgFQgCgFAAgGQAAgFACgFQADgFADgDQAEgEAFgBQAGgCAGAAQAHAAAGACQAFABAEAEQAEADACAFQACAFAAAFQAAAGgCAFQgDAFgDADQgEAEgFACQgGABgHAAQgGAAgGgBgAgQgNQgGAFAAAIQAAAJAGAFQAGAFAKAAQAMAAAFgGQAGgFAAgIQAAgHgGgFQgFgFgMAAQgKAAgGAEg");
	this.shape_197.setTransform(11.3,34.7);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#000000").s().p("AgfAMQgOgGgMgJIAAgOIABAAQAEAFAGAEQAFAFAIADIAQAFQAIACAJAAQAKAAAJgCQAHgCAIgDQAHgDAGgFIAKgJIAAAAIAAAOQgMAJgOAGQgOAGgRAAQgQAAgPgGg");
	this.shape_198.setTransform(15,40.4);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#000000").s().p("AgYAVQgKgJAAgNQABgOAHgHQAIgHAPAAIAEAAIAAAvQAHAAAEgBQAEgCADgDQADgDACgFQABgEAAgEQAAgHgCgGQgEgHgCgDIAAgBIAMAAIAEAMIABAMQABAPgKAJQgIAKgRAAQgOAAgKgJgAgTgOQgFAFAAAIQAAAIAFAFQAFAGAIAAIAAgkQgJAAgEAEg");
	this.shape_199.setTransform(15,51);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#000000").s().p("AggAUIAAgLIAKAAQgFgGgCgEQgDgFAAgFIAAgFIABgDIALAAIAAAAIgBAFIAAAFQAAAGACADIAGAJIAuAAIAAALg");
	this.shape_200.setTransform(15,56.5);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#000000").s().p("AghAbIAAgLIAlAAIAIAAIAGgCQADgCABgCQABgDAAgFQAAgDgCgFQgCgFgEgEIgwAAIAAgLIBBAAIAAALIgIAAIAHAKQADAFAAAGQAAAKgHAGQgGAFgMAAg");
	this.shape_201.setTransform(15.1,63.5);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#000000").s().p("AgXAVIAAgIIgTAAIAAgLIATAAIAAgWIAJAAIAAAWIAdAAIAIAAQADAAADgCIADgCIABgHIgBgGIgBgEIAAgBIAKAAIABAHIABAHQAAAJgFAFQgGAFgMAAIgiAAIAAAIg");
	this.shape_202.setTransform(14.2,69.6);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#000000").s().p("AACAYQgEgDgDgGQgDgGAAgIIgBgRIgDAAIgFABIgFAEIgCAGIAAAGIABAJIADALIAAABIgLAAIgCgJIAAgMIAAgMQACgFACgDQADgEAEgCQAFgCAGAAIArAAIAAALIgGAAIADAEIACAFIACAGIACAIQgBAIgFAHQgHAGgJAAQgHAAgEgEgAAAgEIABAKQABAEADADQADADAFAAQAFAAADgDQADgEAAgGQAAgFgCgFIgFgJIgSAAIABAMg");
	this.shape_203.setTransform(15.1,75.8);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#000000").s().p("AggAUIAAgLIAKAAQgFgGgCgEQgDgFAAgFIAAgFIABgDIALAAIAAAAIgBAFIAAAFQAAAGACADIAGAJIAuAAIAAALg");
	this.shape_204.setTransform(15,81.2);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#000000").s().p("AgYAVQgKgJAAgNQABgOAHgHQAIgHAPAAIAEAAIAAAvQAHAAAEgBQAEgCADgDQADgDACgFQABgEAAgEQAAgHgCgGQgEgHgCgDIAAgBIAMAAIAEAMIABAMQABAPgKAJQgIAKgRAAQgOAAgKgJgAgTgOQgFAFAAAIQAAAIAFAFQAFAGAIAAIAAgkQgJAAgEAEg");
	this.shape_205.setTransform(15,87.9);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#000000").s().p("AgrAdIAAgLIAHAAQgEgEgCgGQgDgFAAgGQAAgMAJgGQAJgHAQAAQAIAAAGADQAGACAFAEQAEAEADAFQACAFAAAFQAAAFgBAEQgBAFgDAEIAcAAIAAALgAgcgMQgGAEAAAIQAAAEACAFIAFAJIAlAAIACgIIABgIQAAgIgGgFQgGgFgLAAQgMAAgGAEg");
	this.shape_206.setTransform(16.1,95);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#000000").s().p("AgfAwIAAgLIAIAAQgFgFgCgFQgDgGAAgFQAAgHADgFQADgEAFgCQgGgGgCgGQgDgFAAgHQAAgKAHgFQAHgGALAAIAqAAIAAALIglAAIgIABIgGABIgEAEQgBADAAAFQAAAEACAFIAGAJIADAAIAEAAIApAAIAAAKIglAAIgIAAQgEAAgCACQgDABgBADQgBACAAAFQAAAEACAFIAGAJIAwAAIAAALg");
	this.shape_207.setTransform(14.9,104.7);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#000000").s().p("AgYAVQgKgJAAgNQABgOAHgHQAIgHAPAAIAEAAIAAAvQAHAAAEgBQAEgCADgDQADgDACgFQABgEAAgEQAAgHgCgGQgEgHgCgDIAAgBIAMAAIAEAMIABAMQABAPgKAJQgIAKgRAAQgOAAgKgJgAgTgOQgFAFAAAIQAAAIAFAFQAFAGAIAAIAAgkQgJAAgEAEg");
	this.shape_208.setTransform(15,114.2);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#000000").s().p("AgqAlIAAhJIAKAAIAAAfIBLAAIAAALIhLAAIAAAfg");
	this.shape_209.setTransform(14,121.5);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#000000").s().p("AgWAiQgHgLAAgXQAAgXAHgKQAHgLAPAAQAQAAAHALQAHALAAAWQAAAYgHALQgIAKgPABQgPAAgHgMgAgIghQgEACgCAGQgCADgBAIIAAAOIAAAPQABAGACAGQACAEAEACQADADAFAAQAFAAAEgDQAEgCACgEIADgMIAAgPIAAgOIgDgMQgCgEgEgDQgDgCgGAAQgFAAgDACg");
	this.shape_210.setTransform(21.7,151.9);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#000000").s().p("AgcAtIAAgNIAMgLIAMgKQAJgKAEgGQAFgHAAgHQAAgGgFgFQgEgDgHAAQgFAAgGABQgHADgGADIgBAAIAAgMIALgEIAOgBQAMgBAIAHQAIAHAAAKQAAAGgBAEIgEAIIgFAGIgIAIIgMAMIgNAKIAuAAIAAALg");
	this.shape_211.setTransform(14.1,151.8);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#000000").s().p("AgWAsIAAgJIASAAIAAg6IgSAAIAAgIIAHAAQAEgBACgBQADgBACgDQABgCABgEIAIAAIAABOIASAAIAAAJg");
	this.shape_212.setTransform(6.6,151.8);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#000000").s().p("AgQArQgHgCgEgCIAAgMIABAAQAEADAHACQAGACAGAAIAHgBQAEgBADgDQADgDABgDQACgDAAgFQAAgFgCgDQgBgDgDgCIgIgCIgJgBIgJABIgJAAIAAgsIA0AAIAAAKIgpAAIAAAYIAGAAIAEgBQAGAAAGACQAFABAFACQAEAEADAEQADAFAAAIQgBAGgCAGQgCAFgEAEQgEAEgGACQgGACgHABIgNgCg");
	this.shape_213.setTransform(21.8,179.1);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#000000").s().p("AgWAsIAAgJIASAAIAAg6IgSAAIAAgIIAHAAQAEgBACgBQADgBACgDQABgCABgEIAIAAIAABOIASAAIAAAJg");
	this.shape_214.setTransform(14.2,178.9);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#000000").s().p("AgWAsIAAgJIASAAIAAg6IgSAAIAAgIIAHAAQAEgBACgBQADgBACgDQABgCABgEIAIAAIAABOIASAAIAAAJg");
	this.shape_215.setTransform(6.6,178.9);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#000000").s().p("AgWAiQgHgLAAgXQAAgXAHgKQAHgMAPAAQAQAAAHAMQAHALAAAWQAAAYgHAKQgIALgPAAQgPABgHgMgAgIggQgEACgCAEQgCAFgBAHIAAAOIAAAPQABAHACAEQACAFAEACQADACAFAAQAFAAAEgCQAEgCACgFIADgLIAAgPIAAgOIgDgMQgCgEgEgCQgDgDgGAAQgFAAgDADg");
	this.shape_216.setTransform(21.7,205.6);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#000000").s().p("AgWAsIAAgJIASAAIAAg6IgSAAIAAgIIAHAAQAEgBACgBQADgBACgDQABgCABgEIAIAAIAABOIASAAIAAAJg");
	this.shape_217.setTransform(14.2,205.5);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#000000").s().p("AgWAsIAAgJIASAAIAAg6IgSAAIAAgIIAHAAQAEgBACgBQADgBACgDQABgCABgEIAIAAIAABOIASAAIAAAJg");
	this.shape_218.setTransform(6.6,205.5);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#000000").s().p("AgQArQgHgCgEgCIAAgMIABAAQAEADAHACQAGACAGAAIAHgBQAEgBADgDQADgCABgEQACgEAAgEQAAgFgCgDQgBgDgDgCIgIgCIgJgBIgJABIgJAAIAAgsIA0AAIAAAKIgpAAIAAAXIAGAAIAEAAQAGAAAGABQAFABAFAEQAEADADAEQADAFAAAIQgBAGgCAFQgCAGgEAEQgEAEgGACQgGADgHgBIgNgBg");
	this.shape_219.setTransform(21.8,233.4);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#000000").s().p("AgWAiQgHgLAAgXQAAgXAHgLQAHgKAPgBQAQAAAHAMQAHALAAAWQAAAXgHALQgIAMgPgBQgPAAgHgLgAgIghQgEADgCAEQgCAFgBAGIAAAPIAAAQQABAFACAFQACAFAEACQADADAFgBQAFAAAEgBQAEgDACgFIADgKIAAgQIAAgPIgDgLQgCgEgEgDQgDgCgGAAQgFAAgDACg");
	this.shape_220.setTransform(14,233.3);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#000000").s().p("AgWAsIAAgJIASAAIAAg6IgSAAIAAgIIAHAAQAEgBACgBQADgBACgDQABgCABgEIAIAAIAABOIASAAIAAAJg");
	this.shape_221.setTransform(6.6,233.2);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#000000").s().p("AgQArQgHgCgEgCIAAgMIABAAQAEADAHACQAGACAGAAIAHgBQAEgBADgDQADgDABgDQACgEAAgEQAAgFgCgDQgBgDgDgCIgIgCIgJgBIgJABIgJAAIAAgsIA0AAIAAAKIgpAAIAAAYIAGAAIAEgBQAGAAAGABQAFABAFADQAEAEADAEQADAFAAAIQgBAGgCAFQgCAGgEAEQgEAEgGACQgGADgHgBQgHABgGgCg");
	this.shape_222.setTransform(21.8,287.3);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#000000").s().p("AgQAtIgGgBIAAgLIABAAIAFACIAHAAQAMAAAIgHQAGgIACgOIgLAFQgFABgEAAIgKgBQgEgBgFgDQgEgDgDgFQgDgFAAgIQAAgNAJgJQAIgIANAAQAGAAAFACQAFACAFAEQAEAEADAIQADAIAAAMQAAAKgCAKQgEAJgEAHQgGAGgIAEQgHADgLAAIgFAAgAgNgdQgFAFAAAJQAAAGACADQABAEAEACIAGACIAGABIAJgCIAJgCIAAgDIAAgDQAAgJgCgFQgBgGgEgDIgGgEIgGgBQgIAAgFAGg");
	this.shape_223.setTransform(14,287.1);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#000000").s().p("AgWAiQgHgLAAgXQAAgWAHgMQAHgLAPABQAQAAAHALQAHALAAAWQAAAYgHALQgIAKgPABQgPAAgHgMgAgIghQgEADgCAFQgCAEgBAGIAAAPIAAAQQABAFACAGQACAEAEACQADACAFABQAFAAAEgCQAEgDACgEIADgLIAAgQIAAgPIgDgLQgCgFgEgCQgDgCgGAAQgFAAgDACg");
	this.shape_224.setTransform(21.7,260.9);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f("#000000").s().p("AgWAiQgHgLAAgXQAAgWAHgMQAHgLAPABQAQAAAHALQAHALAAAWQAAAYgHALQgIAKgPABQgPAAgHgMgAgIghQgEADgCAFQgCAEgBAGIAAAPIAAAQQABAFACAGQACAEAEACQADACAFABQAFAAAEgCQAEgDACgEIADgLIAAgQIAAgPIgDgLQgCgFgEgCQgDgCgGAAQgFAAgDACg");
	this.shape_225.setTransform(14,260.9);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#000000").s().p("AgWAsIAAgJIASAAIAAg6IgSAAIAAgIIAHAAQAEgBACgBQADgBACgDQABgCABgEIAIAAIAABOIASAAIAAAJg");
	this.shape_226.setTransform(6.6,260.8);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#000000").s().p("AgWAiQgHgLAAgXQAAgWAHgMQAHgLAPABQAQAAAHALQAHALAAAWQAAAXgHAMQgIALgPAAQgPAAgHgMgAgIghQgEADgCAEQgCAFgBAGIAAAPIAAAQQABAGACAFQACAEAEACQADACAFABQAFAAAEgCQAEgDACgEIADgLIAAgQIAAgPIgDgLQgCgFgEgCQgDgCgGAAQgFAAgDACg");
	this.shape_227.setTransform(21.7,315);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#000000").s().p("AgQAtIgGgBIAAgLIABAAIAFACIAHAAQAMAAAIgHQAGgIACgOIgLAFQgFABgEAAIgKgBQgEgBgFgDQgEgDgDgFQgDgFAAgIQAAgNAJgJQAIgIANAAQAGAAAFACQAFACAFAEQAEAEADAIQADAIAAAMQAAAKgCAKQgEAJgEAHQgGAGgIAEQgHADgLAAIgFAAgAgNgdQgFAFAAAJQAAAGACADQABAEAEACIAGACIAGABIAJgCIAJgCIAAgDIAAgDQAAgJgCgFQgBgGgEgDIgGgEIgGgBQgIAAgFAGg");
	this.shape_228.setTransform(14,314.9);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f().s("rgba(0,0,0,0.851)").ss(1,2,1).p("AAW3PIgrAAAAWuyIgrAAAAWzAIgrAAAAWqjIgrAAAAWiGIgrAAAAWmVIgrAAAAWGWIgrAAAAWCHIgrAAAAWOzIgrAAAAWKkIgrAAAAWXQIgrAAAAWTBIgrAA");
	this.shape_229.setTransform(30.2,192.2);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#000000").s().p("AgcgBIgZgkIBrAlIhqAmg");
	this.shape_230.setTransform(625.5,381.7);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#000000").s().p("AAAg0IAnBpIgogYIglAZg");
	this.shape_231.setTransform(32.7,16);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f().s("rgba(0,0,0,0.851)").ss(3,2,1).p("EgvHAbcIB2AAIAACAEgtRAbcMAAAg43EAvIAbcMhcZAAA");
	this.shape_232.setTransform(322.4,206);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f().s("rgba(0,0,0,0.851)").ss(1,2,1).p("AAAgdIAAA7AEPgdIAAA7AIdgdIAAA7AQ6gdIAAA7AMrgdIAAA7AVJgdIAAA7AdmgdIAAA7AZXgdIAAA7EAh0gAdIAAA7EAqRgAdIAAA7EAmDgAdIAAA7EgqQgAdIAAA7EghzgAdIAAA7EgmCgAdIAAA7A9lgdIAAA7A1IgdIAAA7A5WgdIAAA7Aw5gdIAAA7AocgdIAAA7AsrgdIAAA7AkOgdIAAA7");
	this.shape_233.setTransform(327,384.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227},{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205},{t:this.shape_204},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_177},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157}]}).wait(155));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(330.5,220.6,630.4,402.2);
// library properties:
lib.properties = {
	id: '6C61CA40FE83A847B6C16BB3D71D96F5',
	width: 660,
	height: 420,
	fps: 12,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['6C61CA40FE83A847B6C16BB3D71D96F5'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;