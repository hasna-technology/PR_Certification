(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgJAnQgHgCgFgGQgFgEgDgIQgDgJAAgKQAAgJADgIQADgIAFgEQAFgGAHgCQAHgEAIAAIANACQAGACAIADIAAANIgBAAQgGgFgHgDQgGgDgIAAQgFAAgEADQgFACgEADQgEAFgCAGQgCAGAAAHQAAAIACAHQADAFADAFQAEADAFACQAEACAGABQAHgBAHgDQAHgCAGgGIAAAAIAAANIgFACIgGADIgHACIgJABQgIAAgHgDg");
	this.shape.setTransform(48.4,0.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgJAaQgFgDgDgDQgDgEgCgFQgBgEAAgHQAAgFABgGQACgFADgDQADgDAFgCIAJgCQAFAAAFACQAEACADADQAEADABAFQACAGAAAFQAAAHgCAEQgBAFgEAEQgDADgEADQgEABgGAAQgFAAgEgBgAgMgPQgEAGAAAJQAAALAFAEQAEAGAHAAQAIAAAEgGQAFgEAAgLQAAgJgFgGQgEgFgIAAQgHAAgFAFg");
	this.shape_1.setTransform(41.7,-2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgUAfQgGgJgBgWQABgUAGgLQAHgJANgBQAPAAAGALQAHAKgBAUQABAWgHAJQgHALgOAAQgNAAgHgLgAgIgdQgCACgCADQgCAFgBAGIgBANIABAOQABAGACAEQABAEADACQAEADAEAAQAFAAADgDQADgCADgDQACgFAAgGIABgOIgBgNQAAgGgCgFQgDgDgDgCQgDgDgFAAQgEAAgEADg");
	this.shape_2.setTransform(35.4,0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgaApIAAgLIALgKIALgKQAJgKAEgFQAEgGAAgGQAAgHgEgDQgFgEgGAAQgFAAgFACQgGACgGADIAAAAIAAgLIAKgDIAMgCQAMAAAHAGQAHAGAAAKIgBAJIgEAHIgFAGIgHAHIgLALIgLAKIAqAAIAAAJg");
	this.shape_3.setTransform(28.4,0.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgUAoIAAgIIAQAAIAAg1IgQAAIAAgHIAHAAQADgBACgCIAFgDQABgCAAgDIAHAAIAABHIARAAIAAAIg");
	this.shape_4.setTransform(21.5,0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(15.8,-8.6,38.5,17.3);


(lib.Tween21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgJAnQgHgCgFgGQgFgEgDgIQgDgJAAgKQAAgJADgIQADgIAFgEQAFgGAHgCQAHgEAIAAIANACQAGACAIADIAAANIgBAAQgGgFgHgDQgGgDgIAAQgFAAgEADQgFACgEADQgEAFgCAGQgCAGAAAHQAAAIACAHQADAFADAFQAEADAFACQAEACAGABQAHgBAHgDQAHgCAGgGIAAAAIAAANIgFACIgGADIgHACIgJABQgIAAgHgDg");
	this.shape.setTransform(38.1,0.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgJAaQgFgDgDgDQgDgEgCgFQgBgEAAgHQAAgFABgGQACgFADgDQADgDAFgCIAJgCQAFAAAFACQAEACADADQAEADABAFQACAGAAAFQAAAHgCAEQgBAFgEAEQgDADgEADQgEABgGAAQgFAAgEgBgAgMgPQgEAGAAAJQAAALAFAEQAEAGAHAAQAIAAAEgGQAFgEAAgLQAAgJgFgGQgEgFgIAAQgHAAgFAFg");
	this.shape_1.setTransform(31.4,-2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgUAfQgGgJAAgWQAAgUAGgLQAHgJANgBQAOAAAHALQAGAKABAUQgBAWgGAJQgHALgOAAQgOAAgGgLgAgHgdQgEACgCADQgBAFgBAGIgBANIABAOQABAGABAEQACAEAEACQADADAEAAQAFAAAEgDQACgCACgDQACgFABgGIABgOIgBgNQgBgGgCgFQgCgDgCgCQgEgDgFAAQgEAAgDADg");
	this.shape_2.setTransform(25.1,0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgUAfQgGgJAAgWQAAgUAGgLQAHgJANgBQAOAAAHALQAGAKAAAUQAAAWgGAJQgHALgOAAQgOAAgGgLgAgIgdQgCACgCADQgDAFAAAGIgBANIABAOQAAAGADAEQABAEADACQADADAFAAQAFAAADgDQADgCADgDQABgFABgGIABgOIgBgNQgBgGgBgFQgDgDgDgCQgDgDgFAAQgEAAgEADg");
	this.shape_3.setTransform(18.1,0.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgUAoIAAgIIAQAAIAAg1IgQAAIAAgHIAGAAQAFgBABgCIAEgDQACgCAAgDIAIAAIAABHIAPAAIAAAIg");
	this.shape_4.setTransform(11.2,0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(5.5,-8.6,38.5,17.3);


(lib.Tween20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgJAnQgHgCgFgGQgFgEgDgIQgDgJAAgKQAAgJADgIQADgIAFgEQAFgGAHgCQAHgEAIAAIANACQAGACAIADIAAANIgBAAQgGgFgHgDQgGgDgIAAQgFAAgEADQgFACgEADQgEAFgCAGQgCAGAAAHQAAAIACAHQADAFADAFQAEADAFACQAEACAGABQAHgBAHgDQAHgCAGgGIAAAAIAAANIgFACIgGADIgHACIgJABQgIAAgHgDg");
	this.shape.setTransform(29.6,0.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgJAaQgFgDgDgDQgDgEgCgFQgBgEAAgHQAAgFABgGQACgFADgDQADgDAFgCIAJgCQAFAAAFACQAEACADADQAEADABAFQACAGAAAFQAAAHgCAEQgBAFgEAEQgDADgEADQgEABgGAAQgFAAgEgBgAgMgPQgEAGAAAJQAAALAFAEQAEAGAHAAQAIAAAEgGQAFgEAAgLQAAgJgFgGQgEgFgIAAQgHAAgFAFg");
	this.shape_1.setTransform(22.9,-2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgUAfQgHgJAAgWQAAgUAHgLQAHgJANgBQAPAAAGALQAHAKgBAUQABAWgHAJQgHALgOAAQgOAAgGgLgAgIgdQgDACgBADQgCAFgBAGIAAANIAAAOQABAGACAEQABAEADACQADADAFAAQAFAAADgDQAEgCACgDQACgFAAgGIABgOIgBgNQAAgGgCgFQgCgDgEgCQgDgDgFAAQgEAAgEADg");
	this.shape_2.setTransform(16.6,0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgUAjQgHgGgBgLQABgGAEgGQAEgFAGgCIAAgBQgGgDgDgEQgEgFABgFQgBgKAIgGQAIgGAKAAQAMAAAHAGQAHAGAAAJQAAAFgDAFQgEAFgGAEQAHACAEAFQAFAEAAAIQgBAKgHAHQgJAHgMAAQgMAAgIgHgAgOAHQgCAFAAAFQAAAHAEAFQAGAFAGAAQAIAAAFgEQAEgEABgHQAAgFgDgDQgCgDgHgDIgFgDIgHgCQgFADgDAEgAgKgdQgEADAAAFQAAAEABACQADADAFADIAFACIAGADQAGgDABgEQACgFAAgEQABgGgFgDQgEgEgHAAQgGAAgEAEg");
	this.shape_3.setTransform(9.6,0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(4,-8.6,31.5,17.3);


(lib.Tween19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgNAdIAAg5IAKAAIAAAHQAEgHAIAAIAFAAIAAAJIgFAAQgJAAgDAJIAAAng");
	this.shape.setTransform(25.9,1.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgRAYQgFgFAAgLIAAglIAKAAIAAAlQAAANALAAQAKAAAEgIIAAgqIAKAAIAAA5IgKAAIAAgFQgGAHgKAAQgJAAgFgGg");
	this.shape_1.setTransform(20.7,1.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgSAWQgIgJABgNIAAAAQgBgIAEgHQADgHAGgDQAGgEAHAAQAMAAAHAIQAIAIAAANIAAABQAAAIgEAHQgDAGgGAFQgHADgHAAQgLAAgHgIgAgLgPQgEAGAAAKQAAAKAEAFQAFAGAGAAQAHAAAFgGQAFgGAAgKQAAgJgFgGQgFgGgHAAQgGAAgFAGg");
	this.shape_2.setTransform(14.6,1.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgYApIAAhQIAJAAIABAHQAGgIAKAAQAKAAAGAIQAGAIABAOIAAABQgBAMgGAIQgGAIgKAAQgJAAgHgGIAAAcgAgOgYIAAAbQAFAIAJAAQAGAAAEgFQAEgGABgKQgBgKgEgGQgDgGgHAAQgJAAgFAIg");
	this.shape_3.setTransform(8.5,2.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgSAZQgFgFAAgHQAAgJAHgEQAGgFAMAAIAKAAIAAgFQAAgFgEgDQgDgDgFAAQgFAAgDADQgEACAAAEIgKAAQAAgFADgEQADgEAGgCQAFgCAFAAQAKAAAGAFQAGAFAAAIIAAAaQAAAJACAEIAAABIgKAAIgCgGQgHAHgIAAQgJAAgGgFgAgNAMQAAAEADADQADADAFgBQAEABAEgDQAEgDACgEIAAgLIgIAAQgRAAAAALg");
	this.shape_4.setTransform(2.3,1.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgEAnIgdhNIALAAIAWA/IAWg/IAMAAIgeBNg");
	this.shape_5.setTransform(-4.2,0.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.7,-8,39.3,17.2);


(lib.Tween18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgNAdIAAg4IAKAAIAAAGQAEgHAIAAIAFAAIAAAKIgFgBQgJAAgDAJIAAAng");
	this.shape.setTransform(45.8,16.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgQAWQgIgHAAgNIAAgCQAAgIAEgGQADgIAGgDQAGgEAGAAQALAAAGAHQAHAIAAANIAAAEIgnAAQAAAJAFAEQAFAGAGAAQAGAAADgCIAHgGIAGAFQgIALgOAAQgLAAgHgIgAgIgQQgFADAAAIIAcAAIAAAAQgBgIgDgEQgEgEgGAAQgFAAgEAFg");
	this.shape_1.setTransform(40.8,16.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgBAhQgDgEAAgIIAAgjIgLAAIAAgHIALAAIAAgPIAJAAIAAAPIALAAIAAAHIgLAAIAAAjQAAADABACQACACADAAIAFgBIAAAIIgIABQgGAAgDgDg");
	this.shape_2.setTransform(35.8,16.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgSAZQgFgEAAgIQAAgJAHgEQAGgFAMAAIAKAAIAAgFQAAgFgEgDQgCgDgGAAQgFAAgEACQgDADAAAEIgKAAQAAgEADgFQADgEAGgCQAFgCAFAAQAKAAAGAFQAGAFAAAIIAAAaQAAAJACAEIAAABIgKAAIgCgGQgHAHgIAAQgJAAgGgFgAgNAMQAAAEADADQADACAFAAQAEAAAEgCQAEgDACgDIAAgMIgIAAQgRAAAAALg");
	this.shape_3.setTransform(31.2,16.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAOAdIgOgrIgNArIgIAAIgRg5IAKAAIALAqIAOgqIAHAAIAOArIALgrIAKAAIgRA5g");
	this.shape_4.setTransform(24.1,16.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgLAmQgGgDgEgEIAGgGQAGAIAJAAQAGAAAFgFQAEgDAAgIIAAgFQgGAHgKAAQgJAAgHgIQgGgIAAgNQAAgOAGgIQAGgIAKAAQAKAAAGAHIAAgGIAJAAIAAA4QABALgHAHQgGAGgMAAQgFAAgGgDgAgKgaQgEAGAAALQAAAJAEAFQAFAFAGAAQAJAAAFgIIAAgaQgFgIgJAAQgGAAgFAGg");
	this.shape_5.setTransform(14.1,17.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AANAdIAAglQAAgGgDgDQgDgEgGABQgDAAgEACQgEADgCAEIAAAoIgKAAIAAg4IAKAAIAAAHQAHgJAJABQATgBAAAVIAAAlg");
	this.shape_6.setTransform(8.1,16.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgEAoIAAg5IAJAAIAAA5gAgDgdQgBAAAAgBQAAAAgBAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAAAgBQABAAAAAAQABgBABAAQAAAAAAAAQABAAAAAAQABAAABABQAAAAABAAQAAABABAAQAAABAAAAQAAAAABABQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAABQgBAAAAAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABgBAAQAAAAgBAAQAAAAAAAAQgBAAgBgBQAAAAgBAAQAAAAAAgBg");
	this.shape_7.setTransform(3.8,15.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgEApIAAhRIAJAAIAABRg");
	this.shape_8.setTransform(1.1,15.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgEAoIAAg5IAJAAIAAA5gAgDgdQgBAAAAgBQAAAAgBAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAAAgBQABAAAAAAQABgBABAAQAAAAAAAAQABAAAAAAQABAAABABQAAAAABAAQAAABABAAQAAABAAAAQAAAAABABQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAABQgBAAAAAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABgBAAQAAAAgBAAQAAAAAAAAQgBAAgBgBQAAAAgBAAQAAAAAAgBg");
	this.shape_9.setTransform(-1.5,15.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgSAWQgIgJABgNIAAAAQAAgIADgHQADgHAGgDQAGgEAHAAQAMAAAHAIQAIAIAAANIAAABQgBAIgDAHQgDAGgGAFQgHADgHAAQgLAAgHgIgAgLgPQgEAGgBAKQABAJAEAGQAEAGAHAAQAHAAAFgGQAFgGAAgKQAAgJgFgGQgFgGgHAAQgHAAgEAGg");
	this.shape_10.setTransform(-6,16.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgaAnIAAhNIAaAAQAMAAAGAFQAGAGAAAJQAAAGgDAFQgDAEgFACQAGABAEAEQAEAFAAAHQAAALgHAGQgHAGgNAAgAgPAfIAQAAQAHgBAEgDQAEgEAAgHQAAgOgPABIgQAAgAgPgFIAPAAQAGAAAEgDQAEgDAAgHQAAgGgEgDQgDgDgHAAIgPAAg");
	this.shape_11.setTransform(-12.4,15.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgNAdIAAg5IAKAAIAAAHQADgHAJAAIAFAAIAAAJIgFAAQgJAAgDAJIAAAng");
	this.shape_12.setTransform(52.7,1.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgRAYQgFgFAAgLIAAglIAKAAIAAAlQAAANALAAQAKAAAEgIIAAgqIAKAAIAAA5IgKAAIAAgFQgGAHgKAAQgJAAgFgGg");
	this.shape_13.setTransform(47.5,1.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgTAWQgGgJAAgNIAAAAQAAgIADgHQADgHAGgDQAGgEAHAAQAMAAAHAIQAIAIgBANIAAABQAAAIgDAHQgDAGgGAFQgGADgIAAQgLAAgIgIgAgLgPQgFAGABAKQgBAKAFAFQAEAGAHAAQAIAAAEgGQAFgGgBgKQABgJgFgGQgEgGgIAAQgHAAgEAGg");
	this.shape_14.setTransform(41.4,1.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgYApIAAhQIAKAAIAAAHQAGgIAKAAQAKAAAHAIQAFAIAAAOIAAABQAAAMgFAIQgHAIgKAAQgJAAgHgGIAAAcgAgOgYIAAAbQAFAIAJAAQAGAAAFgFQADgGAAgKQAAgKgDgGQgEgGgHAAQgJAAgFAIg");
	this.shape_15.setTransform(35.3,2.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgRAZQgGgFAAgHQAAgJAHgEQAHgFALAAIAKAAIAAgFQAAgFgDgDQgDgDgGAAQgFAAgDADQgEACAAAEIgKAAQAAgFADgEQADgEAGgCQAFgCAFAAQAKAAAGAFQAGAFAAAIIAAAaQAAAJACAEIAAABIgLAAIgBgGQgHAHgJAAQgIAAgFgFgAgNAMQAAAEADADQADADAFgBQADABAFgDQAEgDACgEIAAgLIgIAAQgRAAAAALg");
	this.shape_16.setTransform(29.1,1.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgEAnIgchNIAKAAIAWA/IAWg/IALAAIgdBNg");
	this.shape_17.setTransform(22.6,0.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgXAiQgHgGAAgKQAAgFADgFQADgFAJgFIgHgKIgCgIQAAgJAFgFQAGgFAJAAQAHAAAFAFQAFAEAAAIQAAAEgCAEQgDAEgGAFIgEAEIAQAUQAEgHAAgJIAJAAQAAAOgHAJIALANIgMAAIgFgGQgEAEgFABQgFACgFAAQgLAAgHgGgAgLAFQgJAGAAAHQAAAHAEADQAEAEAHAAQAHAAAGgGIgSgXgAgLgcQgDADAAAFQAAAFAGAIIAHgFIAEgFQABgCAAgDQAAgEgDgCQgBgDgEAAQgFAAgCADg");
	this.shape_18.setTransform(13.2,0.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgRAiQgGgJAAgNIAAgBQAAgMAGgIQAHgIAJAAQAKAAAFAHIAAgfIAKAAIAABSIgJAAIAAgGQgGAHgKAAQgJAAgHgIgAgKgDQgDAEAAALQAAAKADAGQAFAFAGAAQAKAAADgIIAAgaQgEgIgJAAQgGAAgFAGg");
	this.shape_19.setTransform(3.6,0.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgEAoIAAg5IAJAAIAAA5gAgDgdQgBAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQABgBAAAAQAAAAABgBQAAAAAAgBQABAAAAAAQABgBABAAQAAAAAAAAQABAAAAAAQABAAABABQAAAAABAAQAAABABAAQAAABAAAAQAAAAABABQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABgBAAQAAAAgBAAQAAAAAAAAQgBAAgBgBQAAAAgBAAQAAAAAAgBg");
	this.shape_20.setTransform(-0.6,0.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgRAYQgFgFAAgLIAAglIAKAAIAAAlQAAANALAAQAKAAAEgIIAAgqIAKAAIAAA5IgKAAIAAgFQgGAHgKAAQgJAAgFgGg");
	this.shape_21.setTransform(-5,1.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AAOApIAAgcQgFAGgKAAQgKAAgGgIQgHgIABgNIAAAAQgBgOAHgIQAGgIALAAQAJAAAGAHIAAgGIAJAAIAABQgAgJgaQgFAGABALQgBAJAFAGQAEAFAGAAQAJAAAEgIIAAgbQgEgIgJAAQgGAAgEAGg");
	this.shape_22.setTransform(-11.3,2.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgEAoIAAg5IAJAAIAAA5gAgDgdQgBAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQABgBAAAAQAAAAABgBQAAAAAAgBQABAAAAAAQABgBABAAQAAAAAAAAQABAAAAAAQABAAABABQAAAAABAAQAAABABAAQAAABAAAAQAAAAABABQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABgBAAQAAAAgBAAQAAAAAAAAQgBAAgBgBQAAAAgBAAQAAAAAAgBg");
	this.shape_23.setTransform(-15.6,0.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgXAnIAAhNIALAAIAABEIAkAAIAAAJg");
	this.shape_24.setTransform(-19.6,0.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-24.9,-8,81.3,32.4);


(lib.Tween17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgRAiQgHgJAAgNIAAgBQAAgMAHgIQAGgIALAAQAIAAAHAHIAAgfIAKAAIAABSIgJAAIgBgGQgGAHgJAAQgLAAgGgIgAgKgDQgDAEAAALQAAAKADAGQAEAFAHAAQAJAAAFgIIAAgaQgFgIgJAAQgHAAgEAGg");
	this.shape.setTransform(11.4,8.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgEAoIAAg5IAJAAIAAA5gAgEgdQAAAAAAgBQAAAAgBAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQABgBAAAAQAAAAAAgBQABAAAAgBQABAAAAAAQABgBABAAQAAAAAAAAQABAAAAAAQABAAABABQAAAAABAAQAAABAAAAQABABAAAAQAAAAABABQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAABQgBAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQgBABgBAAQAAAAgBAAQAAAAAAAAQgBAAgBgBQAAAAgBAAQAAAAgBgBg");
	this.shape_1.setTransform(7.2,8.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgRAYQgFgFAAgLIAAgkIAKAAIAAAkQAAANALAAQAKAAAEgIIAAgpIAKAAIAAA4IgKAAIAAgFQgGAHgKgBQgJABgFgGg");
	this.shape_2.setTransform(2.8,9.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAPApIAAgcQgHAGgIAAQgLAAgGgIQgHgIAAgNIAAAAQAAgOAHgIQAGgIALAAQAJAAAGAHIABgGIAJAAIAABQgAgJgaQgFAGAAALQAAAJAFAGQAEAFAGAAQAJAAAFgIIAAgbQgFgIgJAAQgGAAgEAGg");
	this.shape_3.setTransform(-3.5,10.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgEAoIAAg5IAJAAIAAA5gAgEgdQAAAAAAgBQAAAAgBAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQABgBAAAAQAAAAAAgBQABAAAAgBQABAAAAAAQABgBABAAQAAAAAAAAQABAAAAAAQABAAABABQAAAAABAAQAAABAAAAQABABAAAAQAAAAABABQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAABQgBAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQgBABgBAAQAAAAgBAAQAAAAAAAAQgBAAgBgBQAAAAgBAAQAAAAgBgBg");
	this.shape_4.setTransform(-7.8,8.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgXAnIAAhNIALAAIAABFIAkAAIAAAIg");
	this.shape_5.setTransform(-11.8,8.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17,0,33.9,17.2);


(lib.Tween16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgNAdIAAg5IAJAAIABAHQADgHAKAAIAEAAIAAAJIgFAAQgJAAgDAJIAAAng");
	this.shape.setTransform(20.3,1.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgSAZQgFgFAAgHQAAgJAHgEQAGgFAMAAIAKAAIAAgFQAAgFgEgDQgCgDgGAAQgFAAgEADQgDACAAAEIgKAAQAAgFADgEQADgEAFgCQAGgCAFAAQAKAAAGAFQAFAFABAIIAAAaQAAAJACAEIAAABIgKAAIgCgGQgHAHgIAAQgJAAgGgFgAgNAMQAAAEADADQADADAFgBQAEABAEgDQAEgDACgEIAAgLIgIAAQgRAAAAALg");
	this.shape_1.setTransform(15.1,1.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgOAiIgBAHIgJAAIAAhSIALAAIAAAfQAFgHAKAAQALAAAFAIQAHAIAAAMIAAABQAAAOgHAIQgFAIgLAAQgKAAgGgIgAgNAAIAAAYQAEAJAJAAQAHAAAEgFQAEgGAAgLQAAgKgEgEQgEgGgHAAQgJAAgEAJg");
	this.shape_2.setTransform(9.2,0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgYAoIAAgHIAageIAJgLQACgEAAgEQAAgHgEgDQgEgEgFAAQgHAAgEAEQgEAEAAAIIgKAAQAAgLAHgHQAHgHALAAQAKAAAHAGQAGAGAAAJQAAAMgPAPIgUAXIAmAAIAAAIg");
	this.shape_3.setTransform(0.2,0.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgMAEIAAgHIAZAAIAAAHg");
	this.shape_4.setTransform(-7.2,1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgQAWQgIgHAAgNIAAgCQAAgIAEgGQADgIAGgDQAGgEAGAAQALAAAGAHQAHAIAAAOIAAADIgnAAQAAAIAFAGQAFAFAGAAQAGAAADgCIAHgGIAGAFQgIALgOAAQgLAAgHgIgAgIgQQgFAEAAAHIAcAAIAAAAQgBgHgDgFQgEgEgGAAQgFAAgEAFg");
	this.shape_5.setTransform(-14.3,1.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgNAdIAAg5IAJAAIABAHQADgHAKAAIAEAAIAAAJIgFAAQgJAAgDAJIAAAng");
	this.shape_6.setTransform(-18.8,1.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgRAYQgFgFAAgLIAAglIAKAAIAAAlQAAANALAAQAKAAAEgIIAAgqIAKAAIAAA5IgKAAIAAgFQgGAHgKAAQgJAAgFgGg");
	this.shape_7.setTransform(-24,1.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgLAcQgFgDgDgFQgDgDAAgGIAKAAQAAAFAEADQAEADAFAAQAFAAAEgCQADgCAAgFQAAgDgDgCQgDgDgHgCQgHgBgEgCQgFgBgCgEQgCgDAAgEQAAgHAGgFQAGgFAIAAQAKAAAGAFQAHAFAAAIIgKAAQAAgEgEgDQgDgDgGAAQgEAAgDADQgDACAAADQAAAEADACQACACAHABQAHACAFACQAFACACADQACADAAAFQAAAHgGAGQgGAEgKAAQgGAAgGgCg");
	this.shape_8.setTransform(-29.8,1.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgLAcQgFgDgDgFQgDgDAAgGIAKAAQAAAFAEADQAEADAFAAQAFAAAEgCQADgCAAgFQAAgDgDgCQgDgDgHgCQgHgBgEgCQgFgBgCgEQgCgDAAgEQAAgHAGgFQAGgFAIAAQAKAAAGAFQAHAFAAAIIgKAAQAAgEgEgDQgDgDgGAAQgEAAgDADQgDACAAADQAAAEADACQACACAHABQAHACAFACQAFACACADQACADAAAFQAAAHgGAGQgGAEgKAAQgGAAgGgCg");
	this.shape_9.setTransform(-35.5,1.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgQAWQgIgHAAgNIAAgCQAAgIAEgGQADgIAGgDQAGgEAGAAQALAAAGAHQAHAIAAAOIAAADIgnAAQAAAIAFAGQAFAFAGAAQAGAAADgCIAHgGIAGAFQgIALgOAAQgLAAgHgIgAgIgQQgFAEAAAHIAcAAIAAAAQgBgHgDgFQgEgEgGAAQgFAAgEAFg");
	this.shape_10.setTransform(-41.2,1.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgNAdIAAg5IAJAAIABAHQADgHAKAAIAEAAIAAAJIgFAAQgJAAgDAJIAAAng");
	this.shape_11.setTransform(-45.7,1.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgbAnIAAhNIAcAAQANAAAHAGQAHAHAAALQAAALgHAGQgHAFgNABIgSAAIAAAegAgRAAIASAAQAIAAAEgDQAFgEAAgHQAAgHgFgEQgEgFgIAAIgSAAg");
	this.shape_12.setTransform(-51.1,0.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56.8,-8,80.8,17.2);


(lib.Tween15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgNAdIAAg5IAKAAIAAAHQADgHAJAAIAFAAIAAAJIgFAAQgJAAgDAJIAAAng");
	this.shape.setTransform(28.4,1.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgRAZQgGgFAAgHQAAgJAHgEQAHgFALAAIAKAAIAAgFQAAgFgDgDQgDgDgGAAQgFAAgDADQgEACAAAEIgKAAQAAgFADgEQADgEAGgCQAFgCAFAAQAKAAAGAFQAGAFAAAIIAAAaQAAAJACAEIAAABIgLAAIgBgGQgHAHgJAAQgIAAgFgFgAgNAMQAAAEADADQADADAFgBQADABAFgDQAEgDACgEIAAgLIgIAAQgRAAAAALg");
	this.shape_1.setTransform(23.3,1.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgOAiIgBAHIgJAAIAAhSIAKAAIAAAfQAHgHAJAAQAKAAAHAIQAFAIAAAMIAAABQAAAOgFAIQgHAIgKAAQgKAAgGgIgAgOAAIAAAYQAFAJAJAAQAHAAAEgFQAEgGAAgLQAAgKgEgEQgEgGgHAAQgJAAgFAJg");
	this.shape_2.setTransform(17.3,0.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAFAnIAAhBIgTAHIAAgJIAbgKIACAAIAABNg");
	this.shape_3.setTransform(7.6,0.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgMAEIAAgHIAZAAIAAAHg");
	this.shape_4.setTransform(1,1.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgQAWQgIgHAAgNIAAgCQAAgIAEgGQADgIAGgDQAGgEAGAAQALAAAGAHQAHAIAAAOIAAADIgnAAQAAAIAFAGQAFAFAGAAQAGAAADgCIAHgGIAGAFQgIALgOAAQgLAAgHgIgAgIgQQgFAEAAAHIAcAAIAAAAQgBgHgDgFQgEgEgGAAQgFAAgEAFg");
	this.shape_5.setTransform(-6.1,1.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgNAdIAAg5IAKAAIAAAHQAEgHAIAAIAFAAIAAAJIgFAAQgJAAgDAJIAAAng");
	this.shape_6.setTransform(-10.6,1.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgRAYQgFgFAAgLIAAglIAKAAIAAAlQAAANALAAQAKAAAEgIIAAgqIAKAAIAAA5IgKAAIAAgFQgGAHgKAAQgJAAgFgGg");
	this.shape_7.setTransform(-15.8,1.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgLAcQgFgDgDgFQgDgDAAgGIAKAAQAAAFAEADQAEADAFAAQAFAAAEgCQADgCAAgFQAAgDgDgCQgDgDgHgCQgHgBgEgCQgFgBgCgEQgCgDAAgEQAAgHAGgFQAGgFAIAAQAKAAAGAFQAHAFAAAIIgKAAQAAgEgEgDQgDgDgGAAQgEAAgDADQgDACAAADQAAAEADACQACACAHABQAHACAFACQAFACACADQACADAAAFQAAAHgGAGQgGAEgKAAQgGAAgGgCg");
	this.shape_8.setTransform(-21.7,1.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgLAcQgFgDgDgFQgDgDAAgGIAKAAQAAAFAEADQAEADAFAAQAFAAAEgCQADgCAAgFQAAgDgDgCQgDgDgHgCQgHgBgEgCQgFgBgCgEQgCgDAAgEQAAgHAGgFQAGgFAIAAQAKAAAGAFQAHAFAAAIIgKAAQAAgEgEgDQgDgDgGAAQgEAAgDADQgDACAAADQAAAEADACQACACAHABQAHACAFACQAFACACADQACADAAAFQAAAHgGAGQgGAEgKAAQgGAAgGgCg");
	this.shape_9.setTransform(-27.3,1.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgQAWQgIgHAAgNIAAgCQAAgIAEgGQADgIAGgDQAGgEAGAAQALAAAGAHQAHAIAAAOIAAADIgnAAQAAAIAFAGQAFAFAGAAQAGAAADgCIAHgGIAGAFQgIALgOAAQgLAAgHgIgAgIgQQgFAEAAAHIAcAAIAAAAQgBgHgDgFQgEgEgGAAQgFAAgEAFg");
	this.shape_10.setTransform(-33,1.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgNAdIAAg5IAKAAIAAAHQAEgHAIAAIAFAAIAAAJIgFAAQgJAAgDAJIAAAng");
	this.shape_11.setTransform(-37.5,1.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgbAnIAAhNIAcAAQANAAAHAGQAHAHAAALQAAALgHAGQgHAFgNABIgSAAIAAAegAgRAAIASAAQAIAAAEgDQAFgEAAgHQAAgHgFgEQgEgFgIAAIgSAAg");
	this.shape_12.setTransform(-42.9,0.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-48.6,-8,80.8,17.2);


(lib.Tween14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgNAeIAAg6IAJAAIABAHQADgIAKAAIAEABIAAAJIgFAAQgJAAgDAIIAAApg");
	this.shape.setTransform(38.4,-27.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgSAZQgFgEAAgIQAAgJAHgEQAGgFAMAAIAKAAIAAgFQAAgFgEgDQgCgDgGAAQgFAAgEACQgDADAAAEIgKAAQAAgEADgEQADgFAFgCQAGgCAFAAQAKAAAGAFQAFAFABAJIAAAaQAAAHACAFIAAABIgKAAIgCgGQgHAHgIAAQgJAAgGgFgAgNALQAAAFADADQADADAFAAQADAAAFgDQAEgCACgEIAAgMIgIAAQgRAAAAAKg");
	this.shape_1.setTransform(33.2,-27.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgOAiIAAAHIgJAAIAAhSIAKAAIAAAfQAFgHAKAAQALAAAFAIQAHAIgBAMIAAABQABAOgHAIQgFAIgLAAQgKAAgGgIgAgNAAIAAAYQAEAJAJAAQAHAAAEgFQAEgGAAgLQAAgKgEgEQgEgGgHAAQgJAAgEAJg");
	this.shape_2.setTransform(27.3,-28.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgPAnIAfhFIgpAAIAAgIIA0AAIAAAFIggBIg");
	this.shape_3.setTransform(18.2,-28.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AAHAnIAAgSIgiAAIAAgGIAig1IAKAAIAAAyIALAAIAAAJIgLAAIAAASgAAGgXIgWAjIAXAAIAAglg");
	this.shape_4.setTransform(12.1,-28.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgDAEQgBAAAAgBQgBAAAAAAQAAgBAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBABAAQAAgBABAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAABQAAAAgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAgBAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQgBAAAAgBg");
	this.shape_5.setTransform(7.5,-24.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgRAgQgGgIgBgRIAAgMQAAgRAGgJQAGgIAMAAQANAAAGAIQAGAIAAARIAAAMQAAARgGAJQgGAIgNAAQgLAAgGgIgAgKgZQgEAGAAAMIAAAOQAAANAEAGQAEAGAGAAQAIAAADgFQAEgGAAgMIAAgQQAAgMgEgGQgDgGgIAAQgHAAgDAGg");
	this.shape_6.setTransform(3,-28.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgMAEIAAgHIAZAAIAAAHg");
	this.shape_7.setTransform(-4.3,-27.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgQAXQgIgJAAgNIAAgBQAAgIAEgHQADgGAGgFQAGgDAGAAQALAAAGAIQAHAGAAAOIAAAEIgnAAQAAAJAFAEQAFAGAGAAQAGAAADgCIAHgGIAGAFQgIALgOAAQgLAAgHgHgAgIgRQgFAFAAAIIAcAAIAAgBQgBgIgDgEQgEgEgGAAQgFAAgEAEg");
	this.shape_8.setTransform(-11.4,-27.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgNAeIAAg6IAKAAIAAAHQAEgIAIAAIAFABIAAAJIgFAAQgJAAgDAIIAAApg");
	this.shape_9.setTransform(-15.9,-27.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgRAYQgFgFAAgLIAAglIAKAAIAAAlQAAANALAAQAKAAAEgJIAAgpIAKAAIAAA6IgKAAIAAgGQgGAGgKAAQgJAAgFgFg");
	this.shape_10.setTransform(-21.1,-27.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgLAbQgFgCgDgFQgDgEAAgFIAKAAQAAAFAEADQAEADAFAAQAFAAAEgDQADgCAAgDQAAgFgDgCQgDgCgHgBQgHgCgEgCQgFgCgCgDQgCgDAAgEQAAgHAGgFQAGgFAIAAQAKAAAGAFQAHAFAAAIIgKAAQAAgEgEgDQgDgDgGAAQgEAAgDACQgDACAAAFQAAADADACQACACAHACQAHABAFACQAFABACAEQACADAAAFQAAAIgGAEQgGAFgKAAQgGAAgGgDg");
	this.shape_11.setTransform(-27,-27.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgLAbQgFgCgDgFQgDgEAAgFIAKAAQAAAFAEADQAEADAFAAQAFAAAEgDQADgCAAgDQAAgFgDgCQgDgCgHgBQgHgCgEgCQgFgCgCgDQgCgDAAgEQAAgHAGgFQAGgFAIAAQAKAAAGAFQAHAFAAAIIgKAAQAAgEgEgDQgDgDgGAAQgEAAgDACQgDACAAAFQAAADADACQACACAHACQAHABAFACQAFABACAEQACADAAAFQAAAIgGAEQgGAFgKAAQgGAAgGgDg");
	this.shape_12.setTransform(-32.6,-27.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgQAXQgIgJAAgNIAAgBQAAgIAEgHQADgGAGgFQAGgDAGAAQALAAAGAIQAHAGAAAOIAAAEIgnAAQAAAJAFAEQAFAGAGAAQAGAAADgCIAHgGIAGAFQgIALgOAAQgLAAgHgHgAgIgRQgFAFAAAIIAcAAIAAgBQgBgIgDgEQgEgEgGAAQgFAAgEAEg");
	this.shape_13.setTransform(-38.3,-27.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgNAeIAAg6IAKAAIAAAHQAEgIAIAAIAFABIAAAJIgFAAQgJAAgDAIIAAApg");
	this.shape_14.setTransform(-42.8,-27.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgbAnIAAhNIAcAAQANAAAHAGQAHAHAAAKQAAAMgHAFQgHAHgNgBIgSAAIAAAfgAgRAAIASAAQAIAAAEgDQAFgEAAgHQAAgHgFgFQgEgDgIgBIgSAAg");
	this.shape_15.setTransform(-48.2,-28.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54,-36.8,96,17.2);


(lib.red = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#E2000F").ss(1,1,1).p("ABUAAQAAAjgYAZQgZAYgjAAQgiAAgYgYQgZgZAAgjQAAgiAZgYQAYgZAiAAQAjAAAZAZQAYAYAAAig");
	this.shape.setTransform(0.1,-4.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E2000F").s().p("AghAiQgOgOAAgUQAAgUAOgOQAOgNATAAQAUAAAOANQAOAOAAAUQAAAUgOAOQgOAPgUAAQgTAAgOgPg");
	this.shape_1.setTransform(0.2,-4.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.red, new cjs.Rectangle(-9.3,-13.6,18.8,18.8), null);


(lib.green_dot = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#006633").ss(1,1,1).p("ABUAAQAAAjgYAZQgZAYgjAAQgiAAgYgYQgZgZAAgjQAAgiAZgYQAYgZAiAAQAjAAAZAZQAYAYAAAig");
	this.shape.setTransform(0.1,-4.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#009933").s().p("AghAiQgOgOAAgUQAAgUAOgOQAOgNATAAQAUAAAOANQAOAOAAAUQAAAUgOAOQgOAPgUAAQgTAAgOgPg");
	this.shape_1.setTransform(0.2,-4.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.green_dot, new cjs.Rectangle(-9.3,-13.6,18.8,18.8), null);


(lib.blue = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000099").ss(1,1,1).p("ABUAAQAAAjgYAZQgZAYgjAAQgiAAgYgYQgZgZAAgjQAAgiAZgYQAYgZAiAAQAjAAAZAZQAYAYAAAig");
	this.shape.setTransform(0.1,-4.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000099").s().p("AghAiQgOgOAAgUQAAgUAOgOQAOgNATAAQAUAAAOANQAOAOAAAUQAAAUgOAOQgOAPgUAAQgTAAgOgPg");
	this.shape_1.setTransform(0.2,-4.2);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.blue, new cjs.Rectangle(-9.3,-13.6,18.8,18.8), null);


// stage content:
(lib.Th2_c = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_398 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(398).call(this.frame_398).wait(1));

	// Layer 37
	this.instance = new lib.Tween22("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(214.1,183.1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(389).to({_off:false},0).to({startPosition:0},9).wait(1));

	// Layer 31
	this.instance_1 = new lib.Tween16("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(433.9,141.6);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(373).to({_off:false},0).to({alpha:1},12).wait(14));

	// Layer 28
	this.instance_2 = new lib.green_dot();
	this.instance_2.parent = this;
	this.instance_2.setTransform(199.5,190.7,1,1,0,0,0,0,-4.3);

	this.instance_3 = new lib.green_dot();
	this.instance_3.parent = this;
	this.instance_3.setTransform(199.5,190.7,1,1,0,0,0,0,-4.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_2,p:{x:199.5}}]},321).to({state:[{t:this.instance_3},{t:this.instance_2,p:{x:295.6}}]},28).wait(50));

	// Layer 27
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#00CC00").ss(2,1,1).p("AgSAdIAlg5");
	this.shape.setTransform(80.3,371.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#00CC00").ss(2,1,1).p("AgjA2IBHhr");
	this.shape_1.setTransform(81.9,368.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#00CC00").ss(2,1,1).p("Ag0BPIBpie");
	this.shape_2.setTransform(83.6,366.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#00CC00").ss(2,1,1).p("AhEBpICJjR");
	this.shape_3.setTransform(85.3,363.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#00CC00").ss(2,1,1).p("AhVCCICrkD");
	this.shape_4.setTransform(87,361);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#00CC00").ss(2,1,1).p("AhmCcIDNk3");
	this.shape_5.setTransform(88.6,358.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#00CC00").ss(2,1,1).p("Ah3C1IDvlp");
	this.shape_6.setTransform(90.3,356);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#00CC00").ss(2,1,1).p("AiHDOIEPmb");
	this.shape_7.setTransform(92,353.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#00CC00").ss(2,1,1).p("AiYDoIExnO");
	this.shape_8.setTransform(93.7,350.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#00CC00").ss(2,1,1).p("AipEBIFToB");
	this.shape_9.setTransform(95.3,348.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#00CC00").ss(2,1,1).p("Ai6EaIF1oz");
	this.shape_10.setTransform(97,345.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#00CC00").ss(2,1,1).p("AjKE0IGVpn");
	this.shape_11.setTransform(98.7,343.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#00CC00").ss(2,1,1).p("AjbFNIG3qZ");
	this.shape_12.setTransform(100.4,340.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#00CC00").ss(2,1,1).p("AjsFmIHZrM");
	this.shape_13.setTransform(102,338.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#00CC00").ss(2,1,1).p("Aj9GAIH7r/");
	this.shape_14.setTransform(103.7,335.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#00CC00").ss(2,1,1).p("AkNGZIIbsx");
	this.shape_15.setTransform(105.4,333.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#00CC00").ss(2,1,1).p("AkeGyII9tk");
	this.shape_16.setTransform(107.1,330.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#00CC00").ss(2,1,1).p("AkvHMIJfuX");
	this.shape_17.setTransform(108.7,328.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#00CC00").ss(2,1,1).p("AlAHlIKBvJ");
	this.shape_18.setTransform(110.4,325.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#00CC00").ss(2,1,1).p("AlRH/IKjv9");
	this.shape_19.setTransform(112.1,323);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#00CC00").ss(2,1,1).p("AlhIYILDwv");
	this.shape_20.setTransform(113.8,320.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#00CC00").ss(2,1,1).p("AlyIxILlxh");
	this.shape_21.setTransform(115.5,317.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#00CC00").ss(2,1,1).p("AmDJLIMHyU");
	this.shape_22.setTransform(117.1,315.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#00CC00").ss(2,1,1).p("AmUJkIMpzH");
	this.shape_23.setTransform(118.8,312.9);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#00CC00").ss(2,1,1).p("AmkJ9INJz5");
	this.shape_24.setTransform(120.5,310.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#00CC00").ss(2,1,1).p("Am1KXINr0t");
	this.shape_25.setTransform(122.2,307.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#00CC00").ss(2,1,1).p("AnGKwION1f");
	this.shape_26.setTransform(123.8,305.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#00CC00").ss(2,1,1).p("AnXLKIOv2T");
	this.shape_27.setTransform(125.5,302.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#00CC00").ss(2,1,1).p("AnnLjIPP3F");
	this.shape_28.setTransform(127.2,300.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#00CC00").ss(2,1,1).p("An4L8IPx33");
	this.shape_29.setTransform(128.9,297.7);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#00CC00").ss(2,1,1).p("AoJMVIQT4q");
	this.shape_30.setTransform(130.5,295.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#00CC00").ss(2,1,1).p("AoaMvIQ15d");
	this.shape_31.setTransform(132.2,292.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#00CC00").ss(2,1,1).p("AoqNIIRV6P");
	this.shape_32.setTransform(133.9,290);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#00CC00").ss(2,1,1).p("Ao7NiIR37D");
	this.shape_33.setTransform(135.6,287.5);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#00CC00").ss(2,1,1).p("ApMN7ISZ71");
	this.shape_34.setTransform(137.2,285);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#00CC00").ss(2,1,1).p("ApcOUIS68n");
	this.shape_35.setTransform(138.9,282.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#00CC00").ss(2,1,1).p("AptOUIS68nIAhAA");
	this.shape_36.setTransform(140.6,282.4);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#00CC00").ss(2,1,1).p("Ap/OUIS68nIBEAA");
	this.shape_37.setTransform(142.3,282.4);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#00CC00").ss(2,1,1).p("AqQOUIS68nIBnAA");
	this.shape_38.setTransform(144,282.4);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#00CC00").ss(2,1,1).p("AqhOUIS68nICJAA");
	this.shape_39.setTransform(145.7,282.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#00CC00").ss(2,1,1).p("AqyOUIS68nICrAA");
	this.shape_40.setTransform(147.5,282.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#00CC00").ss(2,1,1).p("ArDOUIS68nIDNAA");
	this.shape_41.setTransform(149.2,282.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#00CC00").ss(2,1,1).p("ArUOUIS68nIDvAA");
	this.shape_42.setTransform(150.9,282.4);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#00CC00").ss(2,1,1).p("ArmOUIS68nIETAA");
	this.shape_43.setTransform(152.6,282.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#00CC00").ss(2,1,1).p("Ar3OUIS68nIE1AA");
	this.shape_44.setTransform(154.3,282.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#00CC00").ss(2,1,1).p("AsIOUIS68nIFXAA");
	this.shape_45.setTransform(156,282.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#00CC00").ss(2,1,1).p("AsZOUIS68nIF5AA");
	this.shape_46.setTransform(157.8,282.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#00CC00").ss(2,1,1).p("AsqOUIS68nIGbAA");
	this.shape_47.setTransform(159.5,282.4);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#00CC00").ss(2,1,1).p("As7OUIS68nIG9AA");
	this.shape_48.setTransform(161.2,282.4);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#00CC00").ss(2,1,1).p("AtMOUIS68nIHgAA");
	this.shape_49.setTransform(162.9,282.4);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#00CC00").ss(2,1,1).p("AteOUIS68nIIDAA");
	this.shape_50.setTransform(164.6,282.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#00CC00").ss(2,1,1).p("AtvOUIS68nIIlAA");
	this.shape_51.setTransform(166.4,282.4);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#00CC00").ss(2,1,1).p("AuAOUIS68nIJHAA");
	this.shape_52.setTransform(168.1,282.4);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#00CC00").ss(2,1,1).p("AuROUIS68nIJpAA");
	this.shape_53.setTransform(169.8,282.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#00CC00").ss(2,1,1).p("AujOUIS68nIKMAA");
	this.shape_54.setTransform(171.5,282.4);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#00CC00").ss(2,1,1).p("Au0OUIS78nIKuAA");
	this.shape_55.setTransform(173.2,282.4);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#00CC00").ss(2,1,1).p("AvFOUIS68nILRAA");
	this.shape_56.setTransform(174.9,282.4);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#00CC00").ss(2,1,1).p("AvWOUIS68nILzAA");
	this.shape_57.setTransform(176.7,282.4);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#00CC00").ss(2,1,1).p("AvnOUIS68nIMVAA");
	this.shape_58.setTransform(178.4,282.4);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#00CC00").ss(2,1,1).p("Av4OUIS68nIM3AA");
	this.shape_59.setTransform(180.1,282.4);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#00CC00").ss(2,1,1).p("AwKOUIS68nINbAA");
	this.shape_60.setTransform(181.8,282.4);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#00CC00").ss(2,1,1).p("AwbOUIS68nIN9AA");
	this.shape_61.setTransform(183.5,282.4);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#00CC00").ss(2,1,1).p("AwsOUIS68nIOfAA");
	this.shape_62.setTransform(185.2,282.4);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#00CC00").ss(2,1,1).p("Aw9OUIS68nIPBAA");
	this.shape_63.setTransform(187,282.4);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#00CC00").ss(2,1,1).p("AxVOjIS68oIPBAAIAwgd");
	this.shape_64.setTransform(189.4,281);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#00CC00").ss(2,1,1).p("AxlOtIS68oIPBAAIBQgx");
	this.shape_65.setTransform(191,280);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#00CC00").ss(2,1,1).p("Ax1O2IS68nIPBAAIBwhE");
	this.shape_66.setTransform(192.6,279);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#00CC00").ss(2,1,1).p("AyFPAIS68oIPBAAICQhX");
	this.shape_67.setTransform(194.2,278.1);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#00CC00").ss(2,1,1).p("AyVPKIS68oIPBAAICwhr");
	this.shape_68.setTransform(195.8,277.1);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#00CC00").ss(2,1,1).p("AylPTIS68nIPBAAIDQh/");
	this.shape_69.setTransform(197.4,276.1);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#00CC00").ss(2,1,1).p("Ay1PdIS68nIPBAAIDwiS");
	this.shape_70.setTransform(199,275.1);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#00CC00").ss(2,1,1).p("AzFPnIS78nIPAAAIEQim");
	this.shape_71.setTransform(200.6,274.2);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#00CC00").ss(2,1,1).p("AzVPxIS78oIPAAAIEwi5");
	this.shape_72.setTransform(202.2,273.2);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#00CC00").ss(2,1,1).p("AzmP7IS78oIPBAAIFRjN");
	this.shape_73.setTransform(203.8,272.2);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#00CC00").ss(2,1,1).p("Az1QEIS78nIPAAAIFxjg");
	this.shape_74.setTransform(205.4,271.2);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#00CC00").ss(2,1,1).p("A0GQOIS78nIPBAAIGQj0");
	this.shape_75.setTransform(207,270.3);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#00CC00").ss(2,1,1).p("A0WQYIS78nIPAAAIGykI");
	this.shape_76.setTransform(208.6,269.3);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("#00CC00").ss(2,1,1).p("A0mQiIS78oIPBAAIHRkb");
	this.shape_77.setTransform(210.2,268.3);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#00CC00").ss(2,1,1).p("A02QsIS78oIPBAAIHxkv");
	this.shape_78.setTransform(211.8,267.3);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#00CC00").ss(2,1,1).p("A1GQ1IS78nIPAAAIISlC");
	this.shape_79.setTransform(213.4,266.3);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#00CC00").ss(2,1,1).p("A1WQ/IS78oIPAAAIIylV");
	this.shape_80.setTransform(215,265.4);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f().s("#00CC00").ss(2,1,1).p("A1mRJIS78oIPAAAIJSlp");
	this.shape_81.setTransform(216.6,264.4);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("#00CC00").ss(2,1,1).p("A12RTIS78oIPAAAIJyl8");
	this.shape_82.setTransform(218.2,263.4);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f().s("#00CC00").ss(2,1,1).p("A2GRcIS78nIPAAAIKSmQ");
	this.shape_83.setTransform(219.8,262.4);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("#00CC00").ss(2,1,1).p("A2WRmIS78nIPAAAIKymk");
	this.shape_84.setTransform(221.4,261.5);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f().s("#00CC00").ss(2,1,1).p("A2mRwIS78oIPAAAILSm3");
	this.shape_85.setTransform(223.1,260.5);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#00CC00").ss(2,1,1).p("A22R6IS78oIPAAAILynL");
	this.shape_86.setTransform(224.7,259.5);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f().s("rgba(0,204,0,0.502)").ss(2,1,1).p("ApcOUIS68n");
	this.shape_87.setTransform(138.9,282.4);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("#00CC00").ss(2,1,1).p("AtoDvIPAAAIMSnd");
	this.shape_88.setTransform(286.8,166.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},286).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_88},{t:this.shape_87}]},1).wait(26));

	// Layer 36
	this.instance_4 = new lib.Tween21("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(214.1,215);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(261).to({_off:false},0).to({alpha:1},14).wait(124));

	// Layer 30
	this.instance_5 = new lib.Tween15("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(425.7,174);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(243).to({_off:false},0).to({alpha:1},13).wait(143));

	// Layer 26
	this.instance_6 = new lib.red();
	this.instance_6.parent = this;
	this.instance_6.setTransform(178.4,222.5,1,1,0,0,0,0,-4.3);

	this.instance_7 = new lib.blue();
	this.instance_7.parent = this;
	this.instance_7.setTransform(294,257.1,1,1,0,0,0,0,-4.3);

	this.instance_8 = new lib.red();
	this.instance_8.parent = this;
	this.instance_8.setTransform(295.6,222.5,1,1,0,0,0,0,-4.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_6}]},187).to({state:[{t:this.instance_8},{t:this.instance_7},{t:this.instance_6}]},31).wait(181));

	// Layer 25
	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f().s("#FF0000").ss(2,1,1).p("AgRAbIAjg1");
	this.shape_89.setTransform(79.4,371.3);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("#FF0000").ss(2,1,1).p("AgiA0IBFhn");
	this.shape_90.setTransform(81.1,368.8);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f().s("#FF0000").ss(2,1,1).p("AgzBNIBniZ");
	this.shape_91.setTransform(82.8,366.3);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f().s("#FF0000").ss(2,1,1).p("AhDBmICHjL");
	this.shape_92.setTransform(84.4,363.8);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f().s("#FF0000").ss(2,1,1).p("AhUB/ICpj9");
	this.shape_93.setTransform(86.1,361.3);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f().s("#FF0000").ss(2,1,1).p("AhlCYIDLkv");
	this.shape_94.setTransform(87.8,358.8);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f().s("#FF0000").ss(2,1,1).p("Ah1CxIDrlh");
	this.shape_95.setTransform(89.4,356.3);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f().s("#FF0000").ss(2,1,1).p("AiGDKIENmT");
	this.shape_96.setTransform(91.1,353.8);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f().s("#FF0000").ss(2,1,1).p("AiXDjIEvnF");
	this.shape_97.setTransform(92.8,351.3);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f().s("#FF0000").ss(2,1,1).p("AinD8IFPn3");
	this.shape_98.setTransform(94.4,348.8);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f().s("#FF0000").ss(2,1,1).p("Ai4EVIFxop");
	this.shape_99.setTransform(96.1,346.3);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f().s("#FF0000").ss(2,1,1).p("AjJEuIGTpb");
	this.shape_100.setTransform(97.8,343.8);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f().s("#FF0000").ss(2,1,1).p("AjZFHIG0qN");
	this.shape_101.setTransform(99.5,341.3);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f().s("#FF0000").ss(2,1,1).p("AjqFgIHVq/");
	this.shape_102.setTransform(101.1,338.8);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f().s("#FF0000").ss(2,1,1).p("Aj7F5IH3rx");
	this.shape_103.setTransform(102.8,336.3);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f().s("#FF0000").ss(2,1,1).p("AkMGSIIZsj");
	this.shape_104.setTransform(104.5,333.8);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f().s("#FF0000").ss(2,1,1).p("AkcGrII5tV");
	this.shape_105.setTransform(106.1,331.3);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f().s("#FF0000").ss(2,1,1).p("AktHEIJbuH");
	this.shape_106.setTransform(107.8,328.8);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f().s("#FF0000").ss(2,1,1).p("Ak+HdIJ9u5");
	this.shape_107.setTransform(109.5,326.3);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f().s("#FF0000").ss(2,1,1).p("AlPH2IKfvr");
	this.shape_108.setTransform(111.2,323.8);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f().s("#FF0000").ss(2,1,1).p("AlfIPIK/wd");
	this.shape_109.setTransform(112.8,321.3);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f().s("#FF0000").ss(2,1,1).p("AlwIoILhxP");
	this.shape_110.setTransform(114.5,318.8);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f().s("#FF0000").ss(2,1,1).p("AmBJBIMDyB");
	this.shape_111.setTransform(116.2,316.3);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f().s("#FF0000").ss(2,1,1).p("AmRJaIMjyz");
	this.shape_112.setTransform(117.8,313.8);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f().s("#FF0000").ss(2,1,1).p("AmiJzINFzl");
	this.shape_113.setTransform(119.5,311.3);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f().s("#FF0000").ss(2,1,1).p("AmzKMINn0X");
	this.shape_114.setTransform(121.2,308.8);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f().s("#FF0000").ss(2,1,1).p("AnEKlIOJ1J");
	this.shape_115.setTransform(122.9,306.3);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f().s("#FF0000").ss(2,1,1).p("AnUK+IOp17");
	this.shape_116.setTransform(124.5,303.8);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f().s("#FF0000").ss(2,1,1).p("AnlLXIPL2t");
	this.shape_117.setTransform(126.2,301.3);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f().s("#FF0000").ss(2,1,1).p("An2LwIPt3f");
	this.shape_118.setTransform(127.9,298.8);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f().s("#FF0000").ss(2,1,1).p("AoLLwIPt3fIAqAA");
	this.shape_119.setTransform(130,298.8);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f().s("#FF0000").ss(2,1,1).p("AodLwIPs3fIBPAA");
	this.shape_120.setTransform(131.8,298.8);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f().s("#FF0000").ss(2,1,1).p("AovLwIPs3fIBzAA");
	this.shape_121.setTransform(133.6,298.8);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f().s("#FF0000").ss(2,1,1).p("ApCLwIPs3fICZAA");
	this.shape_122.setTransform(135.5,298.8);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f().s("#FF0000").ss(2,1,1).p("ApULwIPs3fIC9AA");
	this.shape_123.setTransform(137.3,298.8);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f().s("#FF0000").ss(2,1,1).p("ApmLwIPs3fIDiAA");
	this.shape_124.setTransform(139.2,298.8);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f().s("#FF0000").ss(2,1,1).p("Ap5LwIPs3fIEHAA");
	this.shape_125.setTransform(141,298.8);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f().s("#FF0000").ss(2,1,1).p("AqLLwIPs3fIErAA");
	this.shape_126.setTransform(142.8,298.8);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f().s("#FF0000").ss(2,1,1).p("AqdLwIPs3fIFQAA");
	this.shape_127.setTransform(144.7,298.8);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f().s("#FF0000").ss(2,1,1).p("AqwLwIPs3fIF1AA");
	this.shape_128.setTransform(146.5,298.8);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f().s("#FF0000").ss(2,1,1).p("ArCLwIPs3fIGZAA");
	this.shape_129.setTransform(148.3,298.8);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f().s("#FF0000").ss(2,1,1).p("ArVLwIPs3fIG/AA");
	this.shape_130.setTransform(150.2,298.8);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f().s("#FF0000").ss(2,1,1).p("ArnLwIPs3fIHjAA");
	this.shape_131.setTransform(152,298.8);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f().s("#FF0000").ss(2,1,1).p("Ar6LwIPt3fIIIAA");
	this.shape_132.setTransform(153.9,298.8);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f().s("#FF0000").ss(2,1,1).p("AsMLwIPs3fIItAA");
	this.shape_133.setTransform(155.7,298.8);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f().s("#FF0000").ss(2,1,1).p("AseLwIPs3fIJRAA");
	this.shape_134.setTransform(157.5,298.8);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f().s("#FF0000").ss(2,1,1).p("AsxLwIPs3fIJ3AA");
	this.shape_135.setTransform(159.4,298.8);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f().s("#FF0000").ss(2,1,1).p("AtDLwIPs3fIKbAA");
	this.shape_136.setTransform(161.2,298.8);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f().s("#FF0000").ss(2,1,1).p("AtWLwIPs3fILAAA");
	this.shape_137.setTransform(163.1,298.8);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f().s("#FF0000").ss(2,1,1).p("AtoLwIPs3fILlAA");
	this.shape_138.setTransform(164.9,298.8);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f().s("#FF0000").ss(2,1,1).p("At6LwIPs3fIMJAA");
	this.shape_139.setTransform(166.7,298.8);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f().s("#FF0000").ss(2,1,1).p("AuNLwIPs3fIMuAA");
	this.shape_140.setTransform(168.6,298.8);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f().s("#FF0000").ss(2,1,1).p("AufLwIPs3fINTAA");
	this.shape_141.setTransform(170.4,298.8);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f().s("#FF0000").ss(2,1,1).p("AuxLwIPs3fIN3AA");
	this.shape_142.setTransform(172.2,298.8);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f().s("#FF0000").ss(2,1,1).p("AvELwIPs3fIOdAA");
	this.shape_143.setTransform(174.1,298.8);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f().s("#FF0000").ss(2,1,1).p("AvWLwIPs3fIPBAA");
	this.shape_144.setTransform(175.9,298.8);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f().s("#FF0000").ss(2,1,1).p("AvpLwIPs3fIPmAA");
	this.shape_145.setTransform(177.8,298.8);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f().s("#FF0000").ss(2,1,1).p("Av7LwIPt3fIQKAA");
	this.shape_146.setTransform(179.6,298.8);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f().s("#FF0000").ss(2,1,1).p("AwNLwIPt3fIQuAA");
	this.shape_147.setTransform(181.4,298.8);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f().s("#FF0000").ss(2,1,1).p("AwgLwIPt3fIRTAA");
	this.shape_148.setTransform(183.3,298.8);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f().s("#FF0000").ss(2,1,1).p("AwyLwIPt3fIR4AA");
	this.shape_149.setTransform(185.1,298.8);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f().s("#FF0000").ss(2,1,1).p("AxJL9IPt3eIR5AAIAtgb");
	this.shape_150.setTransform(187.4,297.5);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f().s("#FF0000").ss(2,1,1).p("AxZMGIPu3eIR4AAIBNgu");
	this.shape_151.setTransform(189,296.6);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f().s("#FF0000").ss(2,1,1).p("AxpMQIPt3eIR4AAIBuhB");
	this.shape_152.setTransform(190.6,295.6);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f().s("#FF0000").ss(2,1,1).p("Ax5MaIPt3fIR4AAICOhU");
	this.shape_153.setTransform(192.2,294.6);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f().s("#FF0000").ss(2,1,1).p("AyJMkIPt3fIR4AAICuhn");
	this.shape_154.setTransform(193.8,293.7);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f().s("#FF0000").ss(2,1,1).p("AyZMtIPt3eIR4AAIDOh7");
	this.shape_155.setTransform(195.4,292.7);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f().s("#FF0000").ss(2,1,1).p("AypM3IPt3fIR4AAIDuiO");
	this.shape_156.setTransform(197,291.8);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f().s("#FF0000").ss(2,1,1).p("Ay5NAIPt3eIR4AAIEOih");
	this.shape_157.setTransform(198.6,290.8);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f().s("#FF0000").ss(2,1,1).p("AzJNKIPt3fIR4AAIEui0");
	this.shape_158.setTransform(200.2,289.8);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f().s("#FF0000").ss(2,1,1).p("AzaNTIPt3eIR5AAIFPjI");
	this.shape_159.setTransform(201.9,288.9);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f().s("#FF0000").ss(2,1,1).p("AzqNdIPu3eIR4AAIFvjb");
	this.shape_160.setTransform(203.5,287.9);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f().s("#FF0000").ss(2,1,1).p("Az6NnIPt3fIR4AAIGQju");
	this.shape_161.setTransform(205.1,286.9);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f().s("#FF0000").ss(2,1,1).p("A0KNwIPt3eIR4AAIGwkB");
	this.shape_162.setTransform(206.7,286);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f().s("#FF0000").ss(2,1,1).p("A0aN6IPt3fIR4AAIHQkU");
	this.shape_163.setTransform(208.3,285);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f().s("#FF0000").ss(2,1,1).p("A0qODIPt3eIR4AAIHwko");
	this.shape_164.setTransform(209.9,284.1);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f().s("#FF0000").ss(2,1,1).p("A06ONIPt3fIR4AAIIQk6");
	this.shape_165.setTransform(211.5,283.1);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f().s("#FF0000").ss(2,1,1).p("A1KOXIPt3fIR4AAIIwlO");
	this.shape_166.setTransform(213.1,282.1);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f().s("#FF0000").ss(2,1,1).p("A1aOgIPt3eIR4AAIJQlh");
	this.shape_167.setTransform(214.7,281.2);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f().s("#FF0000").ss(2,1,1).p("A1rOqIPt3fIR5AAIJxl0");
	this.shape_168.setTransform(216.4,280.2);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f().s("#FF0000").ss(2,1,1).p("A17O0IPu3fIR4AAIKRmI");
	this.shape_169.setTransform(218,279.3);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f().s("#FF0000").ss(2,1,1).p("A2LO9IPt3fIR5AAIKxma");
	this.shape_170.setTransform(219.6,278.3);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f().s("#FF0000").ss(2,1,1).p("A2bPHIPt3fIR4AAILSmu");
	this.shape_171.setTransform(221.2,277.3);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f().s("#FF0000").ss(2,1,1).p("A2rPQIPt3eIR4AAILynB");
	this.shape_172.setTransform(222.8,276.4);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f().s("#FF0000").ss(2,1,1).p("A27PaIPt3eIR4AAIMSnV");
	this.shape_173.setTransform(224.4,275.4);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f().s("rgba(255,0,0,0.502)").ss(2,1,1).p("An2LwIPt3f");
	this.shape_174.setTransform(127.9,298.8);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f().s("#FF0000").ss(2,1,1).p("AvVD0IR5AAIMxnn");
	this.shape_175.setTransform(276.3,199.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_89}]},158).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).to({state:[{t:this.shape_135}]},1).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_138}]},1).to({state:[{t:this.shape_139}]},1).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[{t:this.shape_150}]},1).to({state:[{t:this.shape_151}]},1).to({state:[{t:this.shape_152}]},1).to({state:[{t:this.shape_153}]},1).to({state:[{t:this.shape_154}]},1).to({state:[{t:this.shape_155}]},1).to({state:[{t:this.shape_156}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_168}]},1).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[{t:this.shape_171}]},1).to({state:[{t:this.shape_172}]},1).to({state:[{t:this.shape_173}]},1).to({state:[{t:this.shape_175},{t:this.shape_174}]},1).wait(156));

	// Layer 35
	this.instance_9 = new lib.Tween20("synched",0);
	this.instance_9.parent = this;
	this.instance_9.setTransform(214.1,250.7);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(134).to({_off:false},0).to({alpha:1},15).wait(250));

	// Layer 29
	this.instance_10 = new lib.Tween14("synched",0);
	this.instance_10.parent = this;
	this.instance_10.setTransform(434.5,239.3);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(118).to({_off:false},0).to({alpha:1},12).wait(269));

	// Layer 24
	this.instance_11 = new lib.blue();
	this.instance_11.parent = this;
	this.instance_11.setTransform(156,257.1,1,1,0,0,0,0,-4.3);

	this.instance_12 = new lib.blue();
	this.instance_12.parent = this;
	this.instance_12.setTransform(156,257.1,1,1,0,0,0,0,-4.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_11,p:{x:156}}]},58).to({state:[{t:this.instance_12},{t:this.instance_11,p:{x:294}}]},30).wait(311));

	// Layer 34
	this.instance_13 = new lib.Tween19("synched",0);
	this.instance_13.parent = this;
	this.instance_13.setTransform(333.2,131.5);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(92).to({_off:false},0).to({alpha:1},11).wait(296));

	// Layer 33
	this.instance_14 = new lib.Tween18("synched",0);
	this.instance_14.parent = this;
	this.instance_14.setTransform(211.3,131.5);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(72).to({_off:false},0).to({alpha:1},10).wait(317));

	// Layer 32
	this.instance_15 = new lib.Tween17("synched",0);
	this.instance_15.parent = this;
	this.instance_15.setTransform(91.3,123.9);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(38).to({_off:false},0).to({alpha:1},10).wait(351));

	// Layer 22
	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f().s("#0066FF").ss(2,1,1).p("AgSAcIAlg3");
	this.shape_176.setTransform(79.5,370.8);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f().s("#0066FF").ss(2,1,1).p("AggAxIBBhh");
	this.shape_177.setTransform(80.9,368.8);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f().s("#0066FF").ss(2,1,1).p("AguBFIBdiJ");
	this.shape_178.setTransform(82.3,366.7);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f().s("#0066FF").ss(2,1,1).p("Ag7BaIB3iz");
	this.shape_179.setTransform(83.6,364.7);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f().s("#0066FF").ss(2,1,1).p("AhJBuICTjb");
	this.shape_180.setTransform(85,362.6);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f().s("#0066FF").ss(2,1,1).p("AhXCCICvkE");
	this.shape_181.setTransform(86.4,360.6);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f().s("#0066FF").ss(2,1,1).p("AhlCXIDLkt");
	this.shape_182.setTransform(87.8,358.6);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f().s("#0066FF").ss(2,1,1).p("AhyCrIDllV");
	this.shape_183.setTransform(89.1,356.5);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f().s("#0066FF").ss(2,1,1).p("AiADAIEBl/");
	this.shape_184.setTransform(90.5,354.5);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f().s("#0066FF").ss(2,1,1).p("AiODVIEdmp");
	this.shape_185.setTransform(91.9,352.4);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f().s("#0066FF").ss(2,1,1).p("AicDpIE5nR");
	this.shape_186.setTransform(93.3,350.4);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f().s("#0066FF").ss(2,1,1).p("AipD+IFTn6");
	this.shape_187.setTransform(94.6,348.3);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f().s("#0066FF").ss(2,1,1).p("Ai3ESIFvoj");
	this.shape_188.setTransform(96,346.3);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f().s("#0066FF").ss(2,1,1).p("AjFEmIGLpL");
	this.shape_189.setTransform(97.4,344.2);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f().s("#0066FF").ss(2,1,1).p("AjTE7IGnp1");
	this.shape_190.setTransform(98.8,342.2);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f().s("#0066FF").ss(2,1,1).p("AjhFPIHCqd");
	this.shape_191.setTransform(100.2,340.1);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f().s("#0066FF").ss(2,1,1).p("AjuFkIHdrH");
	this.shape_192.setTransform(101.5,338.1);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f().s("#0066FF").ss(2,1,1).p("Aj8F4IH5rv");
	this.shape_193.setTransform(102.9,336);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f().s("#0066FF").ss(2,1,1).p("AkKGNIIVsZ");
	this.shape_194.setTransform(104.3,334);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f().s("#0066FF").ss(2,1,1).p("AkYGhIIxtB");
	this.shape_195.setTransform(105.7,331.9);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f().s("#0066FF").ss(2,1,1).p("AklG2IJLtr");
	this.shape_196.setTransform(107,329.9);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f().s("#0066FF").ss(2,1,1).p("AkzHKIJnuT");
	this.shape_197.setTransform(108.4,327.8);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f().s("#0066FF").ss(2,1,1).p("AlBHfIKDu9");
	this.shape_198.setTransform(109.8,325.8);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f().s("#0066FF").ss(2,1,1).p("AlPHzIKfvl");
	this.shape_199.setTransform(111.2,323.8);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f().s("#0066FF").ss(2,1,1).p("AlcIHIK5wN");
	this.shape_200.setTransform(112.5,321.7);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f().s("#0066FF").ss(2,1,1).p("AlqIcILVw3");
	this.shape_201.setTransform(113.9,319.7);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f().s("#0066FF").ss(2,1,1).p("Al4IwILxxg");
	this.shape_202.setTransform(115.3,317.6);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f().s("#0066FF").ss(2,1,1).p("AmGJFIMNyJ");
	this.shape_203.setTransform(116.7,315.6);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f().s("#0066FF").ss(2,1,1).p("AmoJFIMMyJIBFAA");
	this.shape_204.setTransform(120.1,315.6);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f().s("#0066FF").ss(2,1,1).p("Am/JFIMMyJIBzAA");
	this.shape_205.setTransform(122.4,315.6);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f().s("#0066FF").ss(2,1,1).p("AnVJFIMMyJICfAA");
	this.shape_206.setTransform(124.6,315.6);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f().s("#0066FF").ss(2,1,1).p("AnsJFIMMyJIDNAA");
	this.shape_207.setTransform(126.9,315.6);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f().s("#0066FF").ss(2,1,1).p("AoCJFIMMyJID6AA");
	this.shape_208.setTransform(129.2,315.6);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f().s("#0066FF").ss(2,1,1).p("AoZJFIMMyJIEnAA");
	this.shape_209.setTransform(131.4,315.6);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f().s("#0066FF").ss(2,1,1).p("AowJFIMMyJIFVAA");
	this.shape_210.setTransform(133.7,315.6);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f().s("#0066FF").ss(2,1,1).p("ApHJFIMNyJIGCAA");
	this.shape_211.setTransform(136,315.6);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f().s("#0066FF").ss(2,1,1).p("ApdJFIMMyJIGvAA");
	this.shape_212.setTransform(138.2,315.6);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f().s("#0066FF").ss(2,1,1).p("Ap0JFIMMyJIHdAA");
	this.shape_213.setTransform(140.5,315.6);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f().s("#0066FF").ss(2,1,1).p("AqLJFIMMyJIILAA");
	this.shape_214.setTransform(142.8,315.6);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f().s("#0066FF").ss(2,1,1).p("AqhJFIMMyJII3AA");
	this.shape_215.setTransform(145,315.6);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f().s("#0066FF").ss(2,1,1).p("Aq4JFIMMyJIJlAA");
	this.shape_216.setTransform(147.3,315.6);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f().s("#0066FF").ss(2,1,1).p("ArPJFIMMyJIKSAA");
	this.shape_217.setTransform(149.6,315.6);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f().s("#0066FF").ss(2,1,1).p("ArlJFIMMyJIK/AA");
	this.shape_218.setTransform(151.8,315.6);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f().s("#0066FF").ss(2,1,1).p("Ar8JFIMMyJILtAA");
	this.shape_219.setTransform(154.1,315.6);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f().s("#0066FF").ss(2,1,1).p("AsSJFIMNyJIMYAA");
	this.shape_220.setTransform(156.3,315.6);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f().s("#0066FF").ss(2,1,1).p("AspJFIMNyJINGAA");
	this.shape_221.setTransform(158.6,315.6);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f().s("#0066FF").ss(2,1,1).p("AtAJFIMNyJIN0AA");
	this.shape_222.setTransform(160.9,315.6);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f().s("#0066FF").ss(2,1,1).p("AtWJFIMNyJIOgAA");
	this.shape_223.setTransform(163.1,315.6);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f().s("#0066FF").ss(2,1,1).p("AttJFIMNyJIPOAA");
	this.shape_224.setTransform(165.4,315.6);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f().s("#0066FF").ss(2,1,1).p("AuEJFIMNyJIP8AA");
	this.shape_225.setTransform(167.7,315.6);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f().s("#0066FF").ss(2,1,1).p("AuaJFIMNyJIQoAA");
	this.shape_226.setTransform(169.9,315.6);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f().s("#0066FF").ss(2,1,1).p("AuxJFIMNyJIRWAA");
	this.shape_227.setTransform(172.2,315.6);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f().s("#0066FF").ss(2,1,1).p("AvIJFIMNyJISEAA");
	this.shape_228.setTransform(174.5,315.6);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f().s("#0066FF").ss(2,1,1).p("AveJFIMNyJISwAA");
	this.shape_229.setTransform(176.7,315.6);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f().s("#0066FF").ss(2,1,1).p("Av1JFIMNyJITeAA");
	this.shape_230.setTransform(179,315.6);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f().s("#0066FF").ss(2,1,1).p("AwMJFIMNyJIUMAA");
	this.shape_231.setTransform(181.3,315.6);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f().s("#0066FF").ss(2,1,1).p("AwiJFIMNyJIU4AA");
	this.shape_232.setTransform(183.5,315.6);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f().s("#0066FF").ss(2,1,1).p("Aw5JFIMNyJIVmAA");
	this.shape_233.setTransform(185.8,315.6);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f().s("#0066FF").ss(2,1,1).p("AxcJZIMNyJIVmAAIBGgo");
	this.shape_234.setTransform(189.3,313.6);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f().s("rgba(0,102,255,0.984)").ss(2,1,1).p("AxpJgIMNyJIVmAAIBgg2");
	this.shape_235.setTransform(190.6,312.8);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f().s("rgba(0,102,255,0.965)").ss(2,1,1).p("Ax2JnIMNyJIVmAAIB6hF");
	this.shape_236.setTransform(191.9,312.1);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f().s("rgba(0,102,255,0.949)").ss(2,1,1).p("AyCJvIMNyJIVmAAICShT");
	this.shape_237.setTransform(193.1,311.4);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f().s("rgba(0,102,255,0.929)").ss(2,1,1).p("AyPJ2IMNyJIVmAAICshi");
	this.shape_238.setTransform(194.4,310.7);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f().s("rgba(0,102,255,0.914)").ss(2,1,1).p("AybJ9IMNyJIVmAAIDFhw");
	this.shape_239.setTransform(195.7,310);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f().s("rgba(0,102,255,0.898)").ss(2,1,1).p("AyoKEIMNyJIVmAAIDeh+");
	this.shape_240.setTransform(196.9,309.2);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f().s("rgba(0,102,255,0.878)").ss(2,1,1).p("Ay1KLIMNyJIVmAAID4iN");
	this.shape_241.setTransform(198.2,308.5);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f().s("rgba(0,102,255,0.863)").ss(2,1,1).p("AzCKTIMNyJIVmAAIESib");
	this.shape_242.setTransform(199.5,307.8);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f().s("rgba(0,102,255,0.847)").ss(2,1,1).p("AzOKaIMNyJIVmAAIEqiq");
	this.shape_243.setTransform(200.7,307.1);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f().s("rgba(0,102,255,0.827)").ss(2,1,1).p("AzbKhIMNyJIVmAAIFEi4");
	this.shape_244.setTransform(202,306.4);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f().s("rgba(0,102,255,0.812)").ss(2,1,1).p("AzoKoIMNyJIVmAAIFejG");
	this.shape_245.setTransform(203.3,305.6);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f().s("rgba(0,102,255,0.792)").ss(2,1,1).p("Az0KwIMNyJIVmAAIF2jV");
	this.shape_246.setTransform(204.5,304.9);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f().s("rgba(0,102,255,0.776)").ss(2,1,1).p("A0BK2IMNyJIVmAAIGQji");
	this.shape_247.setTransform(205.8,304.2);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f().s("rgba(0,102,255,0.761)").ss(2,1,1).p("A0OK+IMNyJIVmAAIGqjy");
	this.shape_248.setTransform(207.1,303.5);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f().s("rgba(0,102,255,0.741)").ss(2,1,1).p("A0aLFIMNyJIVmAAIHCkA");
	this.shape_249.setTransform(208.3,302.8);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f().s("rgba(0,102,255,0.725)").ss(2,1,1).p("A0nLMIMNyJIVmAAIHckO");
	this.shape_250.setTransform(209.6,302);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f().s("rgba(0,102,255,0.71)").ss(2,1,1).p("A00LTIMNyJIVmAAIH2kc");
	this.shape_251.setTransform(210.9,301.3);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f().s("rgba(0,102,255,0.69)").ss(2,1,1).p("A1ALaIMNyJIVmAAIIOkr");
	this.shape_252.setTransform(212.1,300.6);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f().s("rgba(0,102,255,0.675)").ss(2,1,1).p("A1NLiIMNyJIVmAAIIok6");
	this.shape_253.setTransform(213.4,299.9);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f().s("rgba(0,102,255,0.655)").ss(2,1,1).p("A1aLpIMNyJIVmAAIJClI");
	this.shape_254.setTransform(214.7,299.2);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f().s("rgba(0,102,255,0.639)").ss(2,1,1).p("A1mLwIMNyJIVmAAIJalW");
	this.shape_255.setTransform(215.9,298.4);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f().s("rgba(0,102,255,0.624)").ss(2,1,1).p("A1zL3IMNyJIVmAAIJ0lk");
	this.shape_256.setTransform(217.2,297.7);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f().s("rgba(0,102,255,0.604)").ss(2,1,1).p("A2AL+IMNyJIVmAAIKOlz");
	this.shape_257.setTransform(218.5,297);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f().s("rgba(0,102,255,0.588)").ss(2,1,1).p("A2NMGIMNyJIVnAAIKmmC");
	this.shape_258.setTransform(219.8,296.3);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f().s("rgba(0,102,255,0.573)").ss(2,1,1).p("A2ZMNIMNyJIVmAAILAmQ");
	this.shape_259.setTransform(221,295.6);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f().s("rgba(0,102,255,0.553)").ss(2,1,1).p("A2mMUIMNyJIVmAAILame");
	this.shape_260.setTransform(222.3,294.8);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f().s("rgba(0,102,255,0.537)").ss(2,1,1).p("A2zMbIMNyJIVmAAIL0ms");
	this.shape_261.setTransform(223.6,294.1);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f().s("rgba(0,102,255,0.518)").ss(2,1,1).p("A2/MjIMNyJIVmAAIMMm7");
	this.shape_262.setTransform(224.8,293.4);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f().s("rgba(0,102,255,0.502)").ss(2,1,1).p("AmGJFIMNyJ");
	this.shape_263.setTransform(116.7,315.6);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f().s("#0066FF").ss(2,1,1).p("AxFDlIVmAAIMlnJ");
	this.shape_264.setTransform(265.1,234.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_176}]},31).to({state:[{t:this.shape_177}]},1).to({state:[{t:this.shape_178}]},1).to({state:[{t:this.shape_179}]},1).to({state:[{t:this.shape_180}]},1).to({state:[{t:this.shape_181}]},1).to({state:[{t:this.shape_182}]},1).to({state:[{t:this.shape_183}]},1).to({state:[{t:this.shape_184}]},1).to({state:[{t:this.shape_185}]},1).to({state:[{t:this.shape_186}]},1).to({state:[{t:this.shape_187}]},1).to({state:[{t:this.shape_188}]},1).to({state:[{t:this.shape_189}]},1).to({state:[{t:this.shape_190}]},1).to({state:[{t:this.shape_191}]},1).to({state:[{t:this.shape_192}]},1).to({state:[{t:this.shape_193}]},1).to({state:[{t:this.shape_194}]},1).to({state:[{t:this.shape_195}]},1).to({state:[{t:this.shape_196}]},1).to({state:[{t:this.shape_197}]},1).to({state:[{t:this.shape_198}]},1).to({state:[{t:this.shape_199}]},1).to({state:[{t:this.shape_200}]},1).to({state:[{t:this.shape_201}]},1).to({state:[{t:this.shape_202}]},1).to({state:[{t:this.shape_203}]},1).to({state:[{t:this.shape_204}]},1).to({state:[{t:this.shape_205}]},1).to({state:[{t:this.shape_206}]},1).to({state:[{t:this.shape_207}]},1).to({state:[{t:this.shape_208}]},1).to({state:[{t:this.shape_209}]},1).to({state:[{t:this.shape_210}]},1).to({state:[{t:this.shape_211}]},1).to({state:[{t:this.shape_212}]},1).to({state:[{t:this.shape_213}]},1).to({state:[{t:this.shape_214}]},1).to({state:[{t:this.shape_215}]},1).to({state:[{t:this.shape_216}]},1).to({state:[{t:this.shape_217}]},1).to({state:[{t:this.shape_218}]},1).to({state:[{t:this.shape_219}]},1).to({state:[{t:this.shape_220}]},1).to({state:[{t:this.shape_221}]},1).to({state:[{t:this.shape_222}]},1).to({state:[{t:this.shape_223}]},1).to({state:[{t:this.shape_224}]},1).to({state:[{t:this.shape_225}]},1).to({state:[{t:this.shape_226}]},1).to({state:[{t:this.shape_227}]},1).to({state:[{t:this.shape_228}]},1).to({state:[{t:this.shape_229}]},1).to({state:[{t:this.shape_230}]},1).to({state:[{t:this.shape_231}]},1).to({state:[{t:this.shape_232}]},1).to({state:[{t:this.shape_233}]},1).to({state:[{t:this.shape_234}]},1).to({state:[{t:this.shape_235}]},1).to({state:[{t:this.shape_236}]},1).to({state:[{t:this.shape_237}]},1).to({state:[{t:this.shape_238}]},1).to({state:[{t:this.shape_239}]},1).to({state:[{t:this.shape_240}]},1).to({state:[{t:this.shape_241}]},1).to({state:[{t:this.shape_242}]},1).to({state:[{t:this.shape_243}]},1).to({state:[{t:this.shape_244}]},1).to({state:[{t:this.shape_245}]},1).to({state:[{t:this.shape_246}]},1).to({state:[{t:this.shape_247}]},1).to({state:[{t:this.shape_248}]},1).to({state:[{t:this.shape_249}]},1).to({state:[{t:this.shape_250}]},1).to({state:[{t:this.shape_251}]},1).to({state:[{t:this.shape_252}]},1).to({state:[{t:this.shape_253}]},1).to({state:[{t:this.shape_254}]},1).to({state:[{t:this.shape_255}]},1).to({state:[{t:this.shape_256}]},1).to({state:[{t:this.shape_257}]},1).to({state:[{t:this.shape_258}]},1).to({state:[{t:this.shape_259}]},1).to({state:[{t:this.shape_260}]},1).to({state:[{t:this.shape_261}]},1).to({state:[{t:this.shape_262}]},1).to({state:[{t:this.shape_264},{t:this.shape_263}]},1).wait(281));

	// Layer 14 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Ajzb0MAAAg3nIHnAAMAAAA3ng");
	var mask_graphics_1 = new cjs.Graphics().p("Ajzb0MAAAg3nIHnAAMAAAA3ng");
	var mask_graphics_2 = new cjs.Graphics().p("Ajzb0MAAAg3nIHnAAMAAAA3ng");
	var mask_graphics_3 = new cjs.Graphics().p("Ajzb0MAAAg3nIHnAAMAAAA3ng");
	var mask_graphics_4 = new cjs.Graphics().p("Ajzb0MAAAg3nIHnAAMAAAA3ng");
	var mask_graphics_5 = new cjs.Graphics().p("Ajzb0MAAAg3nIHnAAMAAAA3ng");
	var mask_graphics_6 = new cjs.Graphics().p("Ajzb0MAAAg3nIHnAAMAAAA3ng");
	var mask_graphics_7 = new cjs.Graphics().p("Ajzb0MAAAg3nIHnAAMAAAA3ng");
	var mask_graphics_8 = new cjs.Graphics().p("Ajzb0MAAAg3nIHnAAMAAAA3ng");
	var mask_graphics_9 = new cjs.Graphics().p("Ajzb0MAAAg3nIHnAAMAAAA3ng");
	var mask_graphics_10 = new cjs.Graphics().p("Ajzb0MAAAg3nIHnAAMAAAA3ng");
	var mask_graphics_11 = new cjs.Graphics().p("Ajzb0MAAAg3nIHnAAMAAAA3ng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:30.2,y:568}).wait(1).to({graphics:mask_graphics_1,x:30.2,y:535.4}).wait(1).to({graphics:mask_graphics_2,x:30.2,y:502.8}).wait(1).to({graphics:mask_graphics_3,x:30.2,y:470.2}).wait(1).to({graphics:mask_graphics_4,x:30.2,y:437.6}).wait(1).to({graphics:mask_graphics_5,x:30.2,y:405}).wait(1).to({graphics:mask_graphics_6,x:30.2,y:372.5}).wait(1).to({graphics:mask_graphics_7,x:30.2,y:339.9}).wait(1).to({graphics:mask_graphics_8,x:30.2,y:307.3}).wait(1).to({graphics:mask_graphics_9,x:30.2,y:274.7}).wait(1).to({graphics:mask_graphics_10,x:30.2,y:242.1}).wait(1).to({graphics:mask_graphics_11,x:30.2,y:209.5}).wait(388));

	// Layer 13
	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#000000").s().p("AgSAcQgGgJAAgTQAAgSAGgKQAGgJAMAAQANAAAGAKQAGAJAAASQAAATgGAKQgGAJgNAAQgMAAgGgKgAgGgbQgEACgBAEIgDAJIAAAMIAAANQABAFACAEQABAEADACQADACAEAAQAFAAADgCQADgCABgEQACgEABgFIAAgNIAAgMQgBgFgCgEQgBgEgDgCQgDgCgFAAQgEAAgCACg");
	this.shape_265.setTransform(36.4,291.8);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#000000").s().p("AgIAkIgIgFQgEgEgCgHQgDgGAAgKQAAgIADgIQACgHAEgGQAEgGAHgDQAGgDAJAAIAFAAIAEABIAAAKIgBAAIgEgCIgFAAQgKAAgGAGQgGAHgBALIAIgEQAEgBAEAAIAIABIAHADQAFADACAEQACAEAAAHQAAALgHAHQgIAHgKAAQgFAAgEgCgAgHAAIgIACIAAACIAAACQAAAIACAFQABAEADADIAFADIAFABQAHAAAEgEQAEgFAAgIIgBgHIgFgGIgFgBIgFAAIgHABg");
	this.shape_266.setTransform(30.1,291.8);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#000000").s().p("AgSAcQgGgJAAgTQAAgSAGgKQAGgJAMAAQANAAAGAKQAGAJAAASQAAATgGAKQgGAJgNAAQgMAAgGgKgAgGgbQgEACgBAEIgDAJIAAAMIAAANQABAFACAEQABAEADACQADACAEAAQAFAAADgCQADgCABgEQACgEABgFIAAgNIAAgMQgBgFgCgEQgBgEgDgCQgDgCgFAAQgEAAgCACg");
	this.shape_267.setTransform(36.4,101.7);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#000000").s().p("AgNAkIgKgDIAAgKIABAAIAJAEIALABIAGgBQADgBACgCQADgCABgDIABgHIgBgGIgEgEQgDgCgDAAIgHAAIgJAAIgGAAIAAgkIAqAAIAAAJIghAAIAAASIAEAAIAEAAIAJABQAFACAEACQADACADAEQACAEAAAGQAAAGgCAEQgCAFgDADQgEADgFACQgEACgGAAIgLgBg");
	this.shape_268.setTransform(30.2,101.8);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#000000").s().p("AgTAkIAAgHIAPAAIAAgvIgPAAIAAgIIAHAAIAFgBIAEgEQABgCAAgCIAHAAIAABAIAPAAIAAAHg");
	this.shape_269.setTransform(23.9,101.7);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#000000").s().p("AgSAcQgGgJAAgTQAAgSAGgKQAGgJAMAAQANAAAGAKQAGAJAAASQAAATgGAKQgGAJgNAAQgMAAgGgKgAgGgbQgEACgBAEIgDAJIAAAMIAAANQABAFACAEQABAEADACQADACAEAAQAFAAADgCQADgCABgEQACgEABgFIAAgNIAAgMQgBgFgCgEQgBgEgDgCQgDgCgFAAQgEAAgCACg");
	this.shape_270.setTransform(36.4,222.4);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#000000").s().p("AgSAcQgGgJAAgTQAAgSAGgKQAGgJAMAAQANAAAGAKQAGAJAAASQAAATgGAKQgGAJgNAAQgMAAgGgKgAgGgbQgEACgBAEIgDAJIAAAMIAAANQABAFACAEQABAEADACQADACAEAAQAFAAADgCQADgCABgEQACgEABgFIAAgNIAAgMQgBgFgCgEQgBgEgDgCQgDgCgFAAQgEAAgCACg");
	this.shape_271.setTransform(30.1,222.4);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#000000").s().p("AgTAlIAAgIIAPAAIAAgwIgPAAIAAgGIAHgBIAFgCIAEgDQABgBAAgDIAHAAIAABAIAPAAIAAAIg");
	this.shape_272.setTransform(23.9,222.4);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#000000").s().p("AgSAcQgGgJAAgTQAAgSAGgKQAGgJAMAAQANAAAGAKQAGAJAAASQAAATgGAKQgGAJgNAAQgMAAgGgKgAgGgbQgEACgBAEIgDAJIAAAMIAAANQABAFACAEQABAEADACQADACAEAAQAFAAADgCQADgCABgEQACgEABgFIAAgNIAAgMQgBgFgCgEQgBgEgDgCQgDgCgFAAQgEAAgCACg");
	this.shape_273.setTransform(36.4,326.5);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#000000").s().p("AAHAkIAAgUIghAAIAAgLIAigoIAJAAIAAArIAKAAIAAAIIgKAAIAAAUgAgUAIIAbAAIAAggg");
	this.shape_274.setTransform(30,326.5);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#000000").s().p("AAlABQgQgFgTAAIgCAAQgNAAgLADQgMACgJAFQgJAFgFAGIgHgDQAFgIAKgHQALgHANgEQANgEAOAAQAPAAANAEQAMAEALAHQALAHAFAIIgHADQgIgKgPgGg");
	this.shape_275.setTransform(11.5,146.4);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#000000").s().p("AgEAjQgNABgKgFQgJgFgFgIQgGgIAAgLQAAgPAJgIQAHgJAPgCIAAANQgLABgFAGQgEAEgBAKQAAALAJAGQAIAHARAAIAIAAQAPAAAIgGQAJgHAAgKQAAgKgEgFQgFgGgMgBIAAgNQAPACAJAJQAHAJABAPQAAAQgNAJQgLAKgUAAg");
	this.shape_276.setTransform(10.6,152.5);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#000000").s().p("AgBAYQgJAAgGgDQgHgDgEgFQgDgGAAgHQAAgGADgGQAEgFAGgDQAIgDAIAAIADAAQAJAAAGADQAHADADAFQAEAFAAAHQAAAHgEAGQgDAFgHADQgGADgIAAgAgSgLQgFAEAAAHQAAAHAFAFQAHAEAKAAIADAAQAKABAGgFQAGgFAAgHQAAgHgGgEQgFgEgKAAIgEAAQgKgBgHAFg");
	this.shape_277.setTransform(7.9,159.7);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#000000").s().p("AgbANQgNgEgLgHQgLgHgEgIIAIgDQAHAKAOAFQAPAFASABIAEAAQAZAAASgIQALgFAGgIIAHADQgFAIgLAHQgVAPgeAAQgOAAgNgEg");
	this.shape_278.setTransform(11.5,164.5);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#000000").s().p("AAAAdQgKAAgIgEQgIgEgEgHQgFgHAAgHQAAgNAJgIQAJgHAQAAIAEAAIAAAtQAKAAAHgFQAGgHAAgHQAAgGgDgEQgCgFgEgDIAFgIQAOAKAAAQQAAANgKAKQgJAIgPAAgAgUgMQgFAEAAAIQAAAGAFAFQAFAFAKABIAAgiIgBAAQgJABgFAEg");
	this.shape_279.setTransform(11.8,173.6);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#000000").s().p("AggARIAAgMIAIAAQgKgFAAgKIABgFIALAAIAAAFQgBALAKAEIAwAAIAAAMg");
	this.shape_280.setTransform(11.7,179);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#000000").s().p("AgiAbIAAgMIArAAQAQAAAAgNQAAgMgKgFIgxAAIAAgLIBEAAIAAALIgIAAQAJAHAAANQAAAKgHAGQgGAGgNAAg");
	this.shape_281.setTransform(11.9,185.1);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#000000").s().p("AgZATIAAgNIgRAAIAAgLIARAAIAAgMIAJAAIAAAMIApAAQAEAAACgBQACgCAAgEIgBgGIAKAAIACAJQgBAIgFADQgEAEgJAAIgpAAIAAANg");
	this.shape_282.setTransform(11,191);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#000000").s().p("AAAAUQgGgIAAgOIAAgLIgGAAQgGAAgEADQgDAEAAAGQAAAHADAEQADAEAFAAIAAAMQgGAAgEgEQgFgDgDgHQgDgGAAgHQAAgLAGgHQAGgHALAAIAeAAQAKAAAFgCIABAAIAAAMIgHACQAJAIAAAKQAAAKgGAHQgGAGgJAAQgLAAgEgIgAABgEQAAAVANAAQAFAAADgEQADgEAAgGQAAgEgDgFQgCgFgFgCIgOAAg");
	this.shape_283.setTransform(11.8,196.4);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#000000").s().p("AggARIAAgMIAIAAQgKgFAAgLIABgEIALAAIAAAFQgBAKAKAFIAwAAIAAAMg");
	this.shape_284.setTransform(11.7,201.8);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#000000").s().p("AAAAdQgKAAgIgEQgIgEgEgHQgFgHAAgHQAAgNAJgIQAJgHAQAAIAEAAIAAAuQAKgBAHgGQAGgFAAgIQAAgGgDgFQgCgEgEgDIAFgHQAOAIAAASQAAAMgKAJQgJAJgPAAgAgUgMQgFAFAAAHQAAAGAFAFQAFAFAKABIAAghIgBAAQgJAAgFAEg");
	this.shape_285.setTransform(11.8,207.8);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#000000").s().p("AguAdIAAgKIAIgBQgJgHAAgMQAAgMAJgIQAJgHARAAIABAAQAPAAAJAHQAKAHAAAMQAAAMgIAIIAhAAIAAALgAgfgLQgGAEAAAJQAAAKAJAGIAgAAQAJgGAAgLQAAgHgGgFQgHgFgMAAQgMAAgHAFg");
	this.shape_286.setTransform(13,214.8);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#000000").s().p("AggAwIAAgLIAHAAQgJgIAAgNQAAgOALgEQgFgDgDgGQgDgGAAgHQAAgXAYAAIAtAAIAAALIgtAAQgHABgEADQgDADAAAJQAAAGAEAEQAEAFAGAAIAtAAIAAALIgsAAQgPAAAAAOQAAAMAKAEIAxAAIAAAMg");
	this.shape_287.setTransform(11.7,224.3);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#000000").s().p("AAAAdQgKAAgIgEQgIgEgEgHQgFgHAAgHQAAgOAJgGQAJgIAQAAIAEAAIAAAtQAKAAAHgFQAGgHAAgHQAAgGgDgEQgCgFgEgDIAFgIQAOAKAAAQQAAANgKAKQgJAIgPAAgAgUgLQgFADAAAIQAAAGAFAFQAFAFAKABIAAgiIgBAAQgJABgFAFg");
	this.shape_288.setTransform(11.8,233.4);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#000000").s().p("AgtAkIAAhHIAKAAIAAAeIBRAAIAAALIhRAAIAAAeg");
	this.shape_289.setTransform(10.6,240.7);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#000000").s().p("AgSAcQgGgJAAgTQAAgSAGgKQAGgJAMAAQANAAAGAKQAGAJAAASQAAATgGAKQgGAJgNAAQgMAAgGgKgAgGgbQgEACgBAEIgDAJIAAAMIAAANQABAFACAEQABAEADACQADACAEAAQAFAAADgCQADgCABgEQACgEABgFIAAgNIAAgMQgBgFgCgEQgBgEgDgCQgDgCgFAAQgEAAgCACg");
	this.shape_290.setTransform(36.4,42.9);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#000000").s().p("AgSAcQgGgJAAgTQAAgSAGgKQAGgJAMAAQANAAAGAKQAGAJAAASQAAATgGAKQgGAJgNAAQgMAAgGgKgAgGgbQgEACgBAEIgDAJIAAAMIAAANQABAFACAEQABAEADACQADACAEAAQAFAAADgCQADgCABgEQACgEABgFIAAgNIAAgMQgBgFgCgEQgBgEgDgCQgDgCgFAAQgEAAgCACg");
	this.shape_291.setTransform(30.1,42.9);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#000000").s().p("AgYAlIAAgKIAKgJIAKgIIAMgOQAEgGgBgFQABgHgEgCQgEgEgFAAQgFAAgFACQgFABgGADIAAAAIAAgKIAJgDIAMgBQAKAAAGAFQAHAGgBAJIgBAIIgCAGIgFAGIgGAGIgKAKIgLAJIAnAAIAAAIg");
	this.shape_292.setTransform(23.8,42.9);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#000000").s().p("AgSAcQgGgJAAgTQAAgSAGgKQAGgJAMAAQANAAAGAKQAGAJAAASQAAATgGAKQgGAJgNAAQgMAAgGgKgAgGgbQgEACgBAEIgDAJIAAAMIAAANQABAFACAEQABAEADACQADACAEAAQAFAAADgCQADgCABgEQACgEABgFIAAgNIAAgMQgBgFgCgEQgBgEgDgCQgDgCgFAAQgEAAgCACg");
	this.shape_293.setTransform(36.4,191.5);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#000000").s().p("AgXAlIAAgKIAKgJIAJgJIAMgNQADgFABgHQgBgFgDgEQgEgDgGAAQgEAAgFACQgGABgFAEIAAAAIAAgKIAJgEIALgBQALAAAGAFQAGAGABAJIgBAHIgEAIIgEAFIgHAGIgJAKIgKAIIAlAAIAAAJg");
	this.shape_294.setTransform(30.2,191.4);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#000000").s().p("AgTAlIAAgIIAPAAIAAgvIgPAAIAAgHIAHgBIAFgBIAEgEQABgCAAgCIAHAAIAABAIAPAAIAAAIg");
	this.shape_295.setTransform(23.9,191.5);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#000000").s().p("AgSAcQgGgJAAgTQAAgSAGgKQAGgJAMAAQANAAAGAKQAGAJAAASQAAATgGAKQgGAJgNAAQgMAAgGgKgAgGgbQgEACgBAEIgDAJIAAAMIAAANQABAFACAEQABAEADACQADACAEAAQAFAAADgCQADgCABgEQACgEABgFIAAgNIAAgMQgBgFgCgEQgBgEgDgCQgDgCgFAAQgEAAgCACg");
	this.shape_296.setTransform(36.4,257.1);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#000000").s().p("AgSAgQgHgGAAgKQAAgFAEgFQADgGAHgBQgGgEgDgEQgDgDAAgGQAAgIAHgFQAHgGAJAAQALAAAGAGQAHAEAAAIQAAAFgDAFQgDAFgGADQAHACADAFQAEAEAAAGQAAAKgHAGQgIAGgLAAQgLAAgHgGgAgMAHQgDAEAAAFQAAAGAFAEQAEAFAGAAQAHAAAFgEQAEgEAAgGQAAgFgCgCQgCgCgGgDIgFgDIgGgCQgFADgCAEgAgJgbQgEADAAAFQAAADACAEQACACAEACIAFACIAGADQAFgEABgDQACgEAAgFQAAgEgEgEQgEgCgGAAQgFgBgEADg");
	this.shape_297.setTransform(30.1,257.1);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f("#000000").s().p("AgSAcQgGgJAAgTQAAgSAGgKQAGgJAMAAQANAAAGAKQAGAJAAASQAAATgGAKQgGAJgNAAQgMAAgGgKgAgGgbQgEACgBAEIgDAJIAAAMIAAANQABAFACAEQABAEADACQADACAEAAQAFAAADgCQADgCABgEQACgEABgFIAAgNIAAgMQgBgFgCgEQgBgEgDgCQgDgCgFAAQgEAAgCACg");
	this.shape_298.setTransform(36.4,361.2);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f("#000000").s().p("AgXAlIAAgKIAKgJIAJgJIAMgNQADgFABgHQgBgFgDgEQgEgDgGAAQgEAAgFACQgGACgFADIAAAAIAAgKIAJgEIALgBQALAAAGAFQAGAGABAJIgBAHIgEAHIgEAGIgHAGIgJAKIgKAIIAlAAIAAAJg");
	this.shape_299.setTransform(30.2,361.2);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f().s("#000000").ss(3,1,1).p("AAAalIAAjWIAAljIAAlYIAAlWIAAldIAAkzIAAuDIAApP");
	this.shape_300.setTransform(48,212.6);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f().s("#000000").ss(2,1,1).p("AAd0SIg5AAAgcmPIA5AAAAdhbIg5AAAAdJXIg5AAAgcECIA5AAAgcOwIA5AAAAdUTIg5AA");
	this.shape_301.setTransform(45.1,231.5);

	var maskedShapeInstanceList = [this.shape_265,this.shape_266,this.shape_267,this.shape_268,this.shape_269,this.shape_270,this.shape_271,this.shape_272,this.shape_273,this.shape_274,this.shape_275,this.shape_276,this.shape_277,this.shape_278,this.shape_279,this.shape_280,this.shape_281,this.shape_282,this.shape_283,this.shape_284,this.shape_285,this.shape_286,this.shape_287,this.shape_288,this.shape_289,this.shape_290,this.shape_291,this.shape_292,this.shape_293,this.shape_294,this.shape_295,this.shape_296,this.shape_297,this.shape_298,this.shape_299,this.shape_300,this.shape_301];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_301},{t:this.shape_300},{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274},{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265}]}).wait(399));

	// Layer 12 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_1 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_2 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_3 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_4 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_5 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_6 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_7 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_8 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_9 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_10 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_11 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_12 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_13 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_14 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_15 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_16 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_17 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_18 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_19 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_20 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_21 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_22 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_23 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_24 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_25 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_26 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");
	var mask_1_graphics_27 = new cjs.Graphics().p("EgotAEBIAAoBMBRbAAAIAAIBg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-241.2,y:396}).wait(1).to({graphics:mask_1_graphics_1,x:-241.2,y:396}).wait(1).to({graphics:mask_1_graphics_2,x:-241.2,y:396}).wait(1).to({graphics:mask_1_graphics_3,x:-241.2,y:396}).wait(1).to({graphics:mask_1_graphics_4,x:-241.2,y:396}).wait(1).to({graphics:mask_1_graphics_5,x:-241.2,y:396}).wait(1).to({graphics:mask_1_graphics_6,x:-241.2,y:396}).wait(1).to({graphics:mask_1_graphics_7,x:-241.2,y:396}).wait(1).to({graphics:mask_1_graphics_8,x:-241.2,y:396}).wait(1).to({graphics:mask_1_graphics_9,x:-241.2,y:396}).wait(1).to({graphics:mask_1_graphics_10,x:-241.2,y:396}).wait(1).to({graphics:mask_1_graphics_11,x:-241.2,y:396}).wait(1).to({graphics:mask_1_graphics_12,x:-207.2,y:396}).wait(1).to({graphics:mask_1_graphics_13,x:-173.3,y:396}).wait(1).to({graphics:mask_1_graphics_14,x:-139.4,y:396}).wait(1).to({graphics:mask_1_graphics_15,x:-105.5,y:396}).wait(1).to({graphics:mask_1_graphics_16,x:-71.5,y:396}).wait(1).to({graphics:mask_1_graphics_17,x:-37.6,y:396}).wait(1).to({graphics:mask_1_graphics_18,x:-3.7,y:396}).wait(1).to({graphics:mask_1_graphics_19,x:30.2,y:396}).wait(1).to({graphics:mask_1_graphics_20,x:64.1,y:396}).wait(1).to({graphics:mask_1_graphics_21,x:98.1,y:396}).wait(1).to({graphics:mask_1_graphics_22,x:132,y:396}).wait(1).to({graphics:mask_1_graphics_23,x:165.9,y:396}).wait(1).to({graphics:mask_1_graphics_24,x:199.8,y:396}).wait(1).to({graphics:mask_1_graphics_25,x:233.8,y:396}).wait(1).to({graphics:mask_1_graphics_26,x:267.7,y:396}).wait(1).to({graphics:mask_1_graphics_27,x:301.6,y:396}).wait(372));

	// Layer 1
	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#000000").s().p("AgQA8QAKgIAGgPQAFgQAAgTIAAgCQAAgNgDgLQgCgMgFgJQgFgJgGgFIADgHQAIAFAHAKQAHALAEANQAEANAAAOQAAAPgEANQgEAMgHALQgHALgIAFg");
	this.shape_302.setTransform(523.7,409.6);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f("#000000").s().p("AAVAuIgggrIgLAMIAAAfIgMAAIAAhbIAMAAIAAAtIAogtIAOAAIgjApIAnAyg");
	this.shape_303.setTransform(518.3,408.7);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#000000").s().p("AgEAFQgBAAAAgBQAAAAgBgBQAAAAAAgBQAAgBAAgBQAAgBACgCQACgDACAAQAEAAACADQABACAAABQAAABAAABQAAABAAAAQAAABgBAAQAAABAAAAQgCACgEAAQgCAAgCgCg");
	this.shape_304.setTransform(511.9,412.7);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#000000").s().p("AgOAtQgGgDgEgGIAGgGQAHAJALAAQAIAAAEgFQAFgFABgIIAAgHQgIAJgLAAQgMAAgIgKQgHgJAAgQQAAgRAHgJQAIgJAMAAQAMgBAHAJIABgHIAKAAIAABCQAAANgIAIQgIAIgNAAQgGAAgIgEgAgMgfQgEAHAAANQAAALAEAGQAGAHAHAAQALAAAGgKIAAgfQgGgKgLAAQgHABgGAGg");
	this.shape_305.setTransform(506.5,411.2);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#000000").s().p("AAVAuIgggrIgLAMIAAAfIgNAAIAAhbIANAAIAAAtIAogtIAOAAIgjApIAmAyg");
	this.shape_306.setTransform(499.4,408.7);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#000000").s().p("AgYAyIAmhjIALAAIgmBjg");
	this.shape_307.setTransform(492,409.1);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#000000").s().p("AgVAnQgHgGAAgNIAMAAQAAAIAEAEQAEAFAIAAQAIAAAFgFQAEgFAAgIIAAhBIAMAAIAABBQAAANgHAHQgJAIgNAAQgNAAgIgIg");
	this.shape_308.setTransform(485.6,408.8);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#000000").s().p("AAOAxIgWggIgIAIIAAAYIgLAAIAAhhIALAAIAAA6IAHgHIAUgWIAOAAIgZAcIAdAog");
	this.shape_309.setTransform(479.5,408.5);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#000000").s().p("AgBAzQgPgVAAgeQAAgOAEgNQAEgNAHgLQAHgLAIgEIADAIQgKAHgFAOQgFAPgBASIAAAEQAAAZAIASQAFALAIAGIgDAHQgIgFgHgLg");
	this.shape_310.setTransform(473.8,409.6);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#000000").s().p("AgUAwIgEgBIAAgJIADAAQAGAAADgDQADgCADgHIACgGIgYhDIAMAAIARAzIAQgzIAMAAIgbBOQgGARgOAAg");
	this.shape_311.setTransform(465,411.3);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f("#000000").s().p("AgcAwIAAheIALAAIAAAIQAIgJALAAQAMAAAHAJQAIAJAAARIAAABQAAAPgIAJQgGAKgNAAQgLAAgHgIIAAAhgAgQgcIAAAgQAFAJALAAQAHAAAFgGQAFgHAAgMQAAgMgFgHQgFgGgHAAQgLAAgFAJg");
	this.shape_312.setTransform(458.4,411.2);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#000000").s().p("AgFAxIAAhhIALAAIAABhg");
	this.shape_313.setTransform(453,408.5);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#000000").s().p("AgVAeQgGgGAAgJQAAgLAIgEQAIgGAOAAIALAAIAAgGQAAgGgDgEQgEgDgHAAQgGAAgEADQgEADAAAFIgMAAQAAgGAEgEQADgFAHgDQAGgDAGAAQAMAAAHAGQAHAGAAALIAAAeQAAAKACAFIAAABIgMAAIgCgHQgIAJgKAAQgKAAgHgGgAgQAOQAAAFAEADQAEADAGAAQAEAAAFgDQAFgCACgFIAAgOIgJAAQgVAAAAANg");
	this.shape_314.setTransform(447.9,409.9);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f("#000000").s().p("AAPAxIAAguQAAgGgDgEQgEgDgHAAQgEAAgEADQgFADgDAEIAAAxIgLAAIAAhhIALAAIAAAlQAJgJALAAQAVAAABAXIAAAug");
	this.shape_315.setTransform(440.9,408.5);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#000000").s().p("AgBAnQgEgGAAgIIAAgpIgNAAIAAgJIANAAIAAgRIALAAIAAARIAMAAIAAAJIgMAAIAAApQAAAEABACQACACAEAAIAGgBIAAAKIgJABQgIAAgDgEg");
	this.shape_316.setTransform(434.9,409.2);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#000000").s().p("AAPAjIAAgtQAAgHgDgEQgDgDgIAAQgEAAgFADQgEADgDAFIAAAwIgLAAIAAhDIALAAIAAAIQAIgKAMAAQAWAAAAAYIAAAtg");
	this.shape_317.setTransform(429.5,409.9);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#000000").s().p("AgdAuIAAhbIA6AAIAAAKIgtAAIAAAeIAnAAIAAAJIgnAAIAAAgIAuAAIAAAKg");
	this.shape_318.setTransform(422.5,408.7);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f().s("#000000").ss(3,1,1).p("EgjtAAAMBHbAAA");
	this.shape_319.setTransform(276.6,382.7);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f().s("#000000").ss(2,1,1).p("AR+ghIAABDAZKghIAABDA5JghIAABDAx9ghIAABDAqxghIAABDAjlghIAABDADmghIAABDAKyghIAABD");
	this.shape_320.setTransform(250.8,388.3);

	var maskedShapeInstanceList = [this.shape_302,this.shape_303,this.shape_304,this.shape_305,this.shape_306,this.shape_307,this.shape_308,this.shape_309,this.shape_310,this.shape_311,this.shape_312,this.shape_313,this.shape_314,this.shape_315,this.shape_316,this.shape_317,this.shape_318,this.shape_319,this.shape_320];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_320},{t:this.shape_319},{t:this.shape_318},{t:this.shape_317},{t:this.shape_316},{t:this.shape_315},{t:this.shape_314},{t:this.shape_313},{t:this.shape_312},{t:this.shape_311},{t:this.shape_310},{t:this.shape_309},{t:this.shape_308},{t:this.shape_307},{t:this.shape_306},{t:this.shape_305},{t:this.shape_304},{t:this.shape_303},{t:this.shape_302}]}).wait(399));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;
// library properties:
lib.properties = {
	id: '0E50EC2B75DADC43BEF2E0AD20798EE9',
	width: 580,
	height: 420,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['0E50EC2B75DADC43BEF2E0AD20798EE9'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;