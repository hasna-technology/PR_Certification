(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.vapoyure = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,204,255,0.502)").s().p("AgrAXQgTgKAAgNQAAgMATgKQASgKAZAAQAaAAASAKQATAKAAAMQAAANgTAKQgSAKgaAAQgZAAgSgKg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.vapoyure, new cjs.Rectangle(-6.3,-3.3,12.6,6.6), null);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,0,0)","#FFFF00","#FF0000"],[0,0.267,1],8.6,-8.5,-7.4,7.5).s().p("AhbgCIAfAeIB/iAIAiAiIiAB/IAfAhIhoAHg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.1,-10.1,20.2,20.2);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.094)").s().p("AjqGeQgCgCAAgFIAApKQAAg1ATggQASggAngLIGGhsQACgBACADQADADAAAEQAAAEgDAEQgCAEgCABImGBsQg9ARAABUIAAJLQAAAEgDAEQgCAEgCABIgCAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQgBgBAAAAgADmmbImGBsQglALgSAeQgSAfAAAzIAAJKIABAFQAAAAABAAQAAABABAAQAAAAABAAQAAAAABgBIACgCIACgFIAApLQAAhZBAgSIGGhsQAAAAAAAAQABAAAAgBQABAAAAAAQAAgBAAAAQACgDAAgDQAAAAAAgBQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAAAAAAAQgBgBAAAAQAAAAgBAAIAAAAg");
	this.shape.setTransform(24.9,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.196)").s().p("AjoGbIgBgFIAApKQAAgzASgfQASgeAlgLIGGhsQAAAAAAAAQABAAAAAAQABABAAAAQAAAAAAABQABAAAAAAQAAABABAAQAAABAAAAQAAABAAAAQAAADgCADQAAAAAAABQAAAAgBAAQAAABgBAAQAAAAAAAAImGBsQhAASAABZIAAJLIgCAFIgCACIgCABIgCgBgADmmWImGBsQgjAKgTAdQgQAdAAAxIAAJKIAAACIACAAIAAgBIABAAIAAgBIAApLQAAhdBDgTIGGhsIAAgBIABAAIAAgCIAAgBIgBAAIAAAAIAAAAg");
	this.shape_1.setTransform(24.9,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0.294)").s().p("AjmGXIAAgBIAApLQAAgxAQgdQATgdAjgKIGGhsIAAAAIABAAIAAABIAAACIgBAAIAAABImGBsQhDATAABdIAAJLIAAACIgBAAIAAAAIgBAAIgBAAg");
	this.shape_2.setTransform(24.9,0);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0.294)").s().p("AD0F9IAAAAIgBgCIAApAQAAhchHgNImfhMIgBAAIgBAAIAAgCIAAgBIABAAIABAAIGfBLQAlAIAUAbQARAaAAAxIAAJAIAAACIgBABIgBgCg");
	this.shape_3.setTransform(-23.4,1.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0.196)").s().p("ADxGAQgBgCAAgDIAApAQAAhXhFgNImehMQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBgBAAIgBgFQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAABAAIGeBMQAoAHATAdQATAcAAAzIAAJAQAAADgBACIgEABQAAAAgBgBQAAAAAAAAQgBAAAAgBQgBAAAAgBgAj1l9IAAABIAAACIABAAIABABIGeBMQBIANAABcIAAJAIAAACIABAAIAAABIACgBIAAgCIAApAQAAgwgSgbQgTgbgmgHImehMIgBAAg");
	this.shape_4.setTransform(-23.4,1.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.094)").s().p("AD0GHQgDgBgCgDQgDgEAAgEIAApAQAAhUhBgMImehMQgEAAgCgEQgCgEAAgEQAAgEACgDQACgCAEAAIGeBMQApAIAUAeQAUAeAAA0IAAJAQAAAEgCADQgCACgDAAIgBAAgAj3mAQAAAAAAAAQgBABAAAAQAAABAAAAQAAABAAABIABAFQABAAAAAAQAAABABAAQAAAAABABQAAAAABAAIGeBMQBFANAABXIAAJAQAAADABACQAAABABAAQAAAAABABQAAAAAAAAQABAAAAABIAEgBQABgCAAgDIAApAQAAgzgTgcQgTgdgogHImehMIgBAAQAAAAgBAAQAAAAAAAAQgBABAAAAQAAAAgBABg");
	this.shape_5.setTransform(-23.4,1.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-48.6,-41.6,97.2,83.2);


(lib.flamecopy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("AncOwQAiiYhDh2QhOhhAQhKQArAWgHgkIgGgiIAAABIAAgBQgdhrAwhZQAcgxgLhlQAiADAGBRQATgvgJhfIAAgGQAAhtBDgyQBOgzAKhoQAeALgFAvQBDg4AZiYQAThpAxgoQAwgogOg1QAqAggpBKQgsA8AMA/QAFhOBMgUQBagrATiCQAMiqB9hcQgTAfgDAhQBZgzAiiPQAMhUgfg2QBvBVg/D7QghB6AfB2QAwB3gOBaQBMh7gyiMQBrBbhDDuQgZCNAsCNQBZDKg5C/QgSA5gCBDQAKhKApg0QAcglAGhJQAeBIglB6QgZBiAkBeQBiJpq8AqQnxgHA8kXg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF0000").s().p("AhoSiQmmgYA3kDIAAgBQAeiGgxhqIgVgnQhIheALhYQAkAZgCgVQgCgQABAAQABgEgCgTQgFghAAgUIABgBIgBgBQgDg8AUg5QANgkACgzQABgigDgkQAWgNAHAmIADALQATg7AIhAIgDgIIAAgDQgOgxA6gUQAXgFAXgNQAfguAEhJIAAgDIADAAQATgBgBAYQAcghAbgsQAkgzAOhSIADgSQAMgUAGgGQAYguAcghQAogqgGg3IgBgCQAjADgZAsQgFAFgDAFQgNAZAUAZQAEgNAFgMQAEgbAnADIAMgCQAdgGAUgaQALgmARglQAIgVAMgSQAmhTBJhqIAMgQQgEAHgCAHQA2g6AMh2IAPgTQAbgrgQgaIgBgCQA3A0AaAbQAUAdAABMQACAXAJAaQgdBGADBbQANBEgBBDQABArgGAoQAZgWALgbQASgegVgnQAJANAHANQBHAkgGBkIgLAjQgcB9AOCWIADASQAfByAOBvQAQBegTBcQgLA9gGBFIADgQQAFgZAXgNIABgBQAWguAOhBIADAEQAaArgfAoIgBADQgBBhAXBgQADAugEAtQgCBZAABPQgZGqomAtIgzABIgwgBg");
	this.shape_1.setTransform(-0.4,4.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF0000").s().p("AnXNeIAAgBQAfiMg3hvIgXgnQhBhcAHhlQAcAcACgGQAAgBABgBQAAAAABAAQAAAAABABQABAAAAABIAAABIABABQAGAIgCgWQgFgpAAgPIAAgBQgIg+AMg+QAHgnACg0QABglgBgjQAPgeAFASIAEgBQAQg7ATguQgRgGASgJIACgBIAEgBIgHARQAIADAPADQAVAIAbgDQAbgugBhQIAAgDIACgBQANgOACAFQAYgpAggoQAwgxAOhUIADgTQASgKACALQAdgoAbgrQAggrAAg7IAAgDQAYgVgEAGIAdABQAFgLAHgKQAAAGALAOIAEAHQALATASADQAJgrAbgdQANgRAVgLQA3g1BCiMIASgiQgJgDgGgGQAfhHgMh5IAUgEQAqgFgCABQAwA6AtgpQAggWAdAlQAOAIAVASQgvA4gRBhQgCBDgIBLIgIBXQAOAJAOAHQAZALgPAAQAGAPAEAPQBJgRAfAQIgNAkQghB2gKCmIABATQAPB3AXB2QAZBhgJBfQgGBCgJBGIgCADQgCABAOAOIABAAIAnhxIAEAAIAEACIgFgWIABABQAZAhgVgMQARBYAJBZQAAAwgLAvQgKBdAMBUQAOHXowA7QgzADg1AAQm/gSA5kJg");
	this.shape_2.setTransform(-0.4,8.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0000").s().p("AnYNxIAAgBQAhiSg9hyQgOgTgMgVQg6hZAChzIAbAoIAKARIAAABIABABQAMAUgDgaIgFg6IABABIgBgCQgNg+AEhCIAEhgQABgpAAgiQAJguADgDIAEgMQAUhVAlgjIgFAJIgCAEQgoBLAnAlQASAVAfAGQAXgugFhXIAAgCIABgDQAGgcAGgNQAUgwAlgkQA6gvAPhWIADgUQAYABgBAcQAhgkAag0QAaguAFg/IAAgDIAbhHQADgJAFgHQAOgXAogYQAJgMAKgLQgSAegHAoIgEAQQgGAqAPAhQAGgvAngWQATgMAcgFQBHgWA9itQAGgTAFgVQgEgVgHgZQAHhTgkh9IAZALQA7AhAJAdIABACQArBAA/huQAthJA4gCQAbgFAhAJQhBApglBpQgQBBgQBTQgIAugEAtQAFApAQAnQAgA1gIAnQADARAAAQQBKhGBFhEIgPAkQgmBwghC3IgBAUQgCB9AgB8QAkBlgCBhQAABGgMBIIgGAVQgKAdAGAnIAAACQAOg+Adg2IAEgDQAbgKgWhwIgBgFQArBlgCBpQgEAygSAyQgRBfAYBZQAzIFo3BIQg1AGg5ABQnXgNA5kPg");
	this.shape_3.setTransform(-0.4,6.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FF0000").s().p("AnZObQAiiYhDh2QhPhhgDifQA7CYgEg3IgGg8IABABIgBgBQgdhrAFh/IAGikQAUh4A6gXQhfDjBwAzQATgvgJheIAAgGQgBhtBDgzQBOgzALhoQAdAMgEAuQBDg4AZiYQARhrAig4QAig4BEg+IhHCPQgYBCAMA/QAFhOBuAFQBYAIA2jOQAYh/hmjhQBkBXAaBDQAlBOBTi2QBTi2CPgDQiCAqg/D8QghB5AfB2QAwB3gPBbQBMh7BqiZQgxBohDDuQgYCNArCMQBZDKg5C/QgRA6gCBDQAJhLApgzQAdglgTjEQBfCXhOClQgZBiAkBeQBiJqq8AqQnwgHA8kXg");
	this.shape_4.setTransform(-0.2,2.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF0000").s().p("AkjSHQimg3gCiGQgKhOgBhWQgBhIgdg/Igjg6QgwhJALg7IABgDQAeAQAEgPQAEgIgDgNIgBgFIAAAAIAAgBIgEgUIgCgLIAAAAIAAgCQgShLAPhJQAHgkAPgmQAYg9gGhtQAbgOAGApIABgDQAPgHgFguIAAgCQADgfAugYIADgBIAAABIADgFQAhgeAPgyIABgFIADgJQANgrAGgvQAOgCAGAIQAFAEABAIQBDhOAtiXQAIgWAIgUQAJgcAZgGQAdgCgKgfIAAAAIAAgDQAtAMgYAeIgMAJQgNANAQAYIAGgRQAJgmAWgbQAQgVAWgSQAdgaASgqQAtgNAKglQAEgZgCgTQgFgUAUgLIACgCQAVgvAwgbIAIgFQgDARAEAMQAbgWATgiQAnhKAmheIANgnIgIgSQAFgNgEgiIATAEQAYALALAPQATAvgXAnQgOAfAFAXQAEA0AMAzQApCGgJBnQAdgSAEgaIAAgIQAPAkAKAsQAVBMgPBXQgBANgFARQgBAJABAKIgBAPQgBAqATAdIAKAMQBVDVg0C7QgOAxgLA0IgDAlQAFgfAlgNIAKgFQAWgKAGgbQAcBUghB0IgCAGIABADIAAAAQADADgCAKQgEAnAZAUQAKAhAAATQAbEiiQCOQgaAmggAiQhiCPjWA3QhoAUhfAAQhdAAhTgTgAGBr8IAMAMQAKARABAQQgKgYgNgVg");
	this.shape_5.setTransform(0,2.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF0000").s().p("AjTS3QjFglglh0QgohLAJhmQAHhRgbhHQgPgjgTggQg6hRAMhAIABgCQAiASABgWQABgLgCgMIgBgGIAAAAIgFgWIgCgNIgBgCQgRhQARhWQAIglAMguQAThIAAh2QAUgeAGACIABgEIALAeIABACQAFApAgAFIADABIADgGQAbgkAHg9IABgFIACgLQAJgyAGgyQALgLAGgDIAKgGQBEhlBBiWIAXgsQgDARAMAUIAGAVQAugHgIgRQgCgEgCgHQgDgTAWACQAEgKAGgIQAMgoAUgiQAMgaAPgaQAUgkAMgzIA2AUQAUgbAjgPIAJgGQANAEALgJQAZgcAQgpQAdheA0hbIASgfQgDACgDgCQADgFAJgEIgGAJQAKgFAEgjQAJgEAIgHQAUgKAJgRQAPAFgKhGQgHgNAFgaQAHA6ALA4QAkCTgFB0QAVAXABAMQgDANgMALIgMAKIAjCRQAeBbgOBYQADgKABgHIAGgLIAAgKQACgMAIgmIAEgKQBlDxg0DKQgPA3gRA1IgFApQABAOAhAZIAKAGQAYAQAJAEQAbBkgiB4IgCAHIADgDIABgBQAKgHgCAFQAFgFATgnQAJgMgBgeQA2FRh+CaQgRAwgVAuQgzDRjFBfQiaBEixAAQgqAAgrgEg");
	this.shape_6.setTransform(0.4,-0.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF0000").s().p("Am0TBQhEhJATh1QAOhagYhOQgNgogVgkQhEhZAOhFIAAgBQAnAUgDgdIgDgZIgBgGIAAAAIAAgBIgGgYIgCgNIAAgBIAAgDQgQhVAShhIARheQAPhSAGh/QAMgxAGgkIABgGQAKBJACArIABAHQAJByATAfIABADIAAABIADgIQAVgpAAhKQgBgDABgDIABgMQAFg6AHgzIANgjIAPgYQBEh7BWiVQAOgYAPgXQgOA+gCAuQgGBHgFAJIgBABIACgDQAygbAKg9IADggQAGg0AcgUQAGgKAIgIQAOgrATgoQAIgeAJglQALgtAFg8QBAA3AHApQAEAngfAlQAOgKASgGIAKgFQAcgLATgcQAWgiAMgwQAUhyBDhZQAQgWASgSQgNARgEATQAaAXAOg4QAIgLAHgQQAPgeAJgyQALglADizQgBg4AHhMQAJBAAKA9QAdCiABCAQANBAgDAxQgHAtgMAsIgMAiQABBPAWBUQAnBpgPBZIAQg/IAMgpIACgjQAChCgDhoIABghQBzENg0DXQgPA9gYA6QgEAWgCAXQgEA5AeBAIAJARQAbApALAjQAbB0gkB9IgCAHIAFgIIABgCQARgSgCAAQAQgwANhjQAHg4gChPQBSF/hsCmQgJA7gLA5QgEETi0CIQisB/kcAAQjlgUhIhig");
	this.shape_7.setTransform(1.2,-12.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF0000").s().p("AnySXQAiiYhDh2QhOhgAQhLQArAWgHgkIgGghIAAAAIAAgBIgGgaQgUhhAVh5QAYiKAZlXQAZFyAHBYIAAAEIAAABQATgvgJheIAAgHIAAgNQABhmARhKQBUi9CSjCQg+EKgFAvIgBACQBDg3AZiYQAThpAxgoIAihdQAKhKgEiCQCWCyiBCRQhCAsAHA6IABAIQAFhOBMgUQBagqATiDQAMipB9hdQgTAggDAgQAuAzAah4QALgzAHhRQAKhrAbnmQBBGSgRDyIgXCbQghB5AfB2QAwB3gOBaIAsi1QADgcABggQAFiLgTjPQCoGAiIEOQgZCMAsCMQBZDLg5C/IgCAIQAEgKAFgGQAYgdgCgEQApiXgFlIQBtGthbCzIAACKQBUKZq8AqQnxgHA8kXg");
	this.shape_8.setTransform(2.2,-23.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57.4,-123,115,246);


(lib.flamecopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#FFFF00","#FFF200","#FF6600"],[0,0.635,0.988],6.9,22.8,0,6.9,22.8,47.6).s().p("AncOwQAiiYhDh2QhOhhAQhKQArAWgHgkIgGgiIAAABIAAgBQgdhrAwhZQAcgxgLhlQAiADAGBRQATgvgJhfIAAgGQAAhtBDgyQBOgzAKhoQAeALgFAvQBDg4AZiYQAThpAxgoQAwgogOg1QAqAggpBKQgsA8AMA/QAFhOBMgUQBagrATiCQAMiqB9hcQgTAfgDAhQBZgzAiiPQAMhUgfg2QBvBVg/D7QghB6AfB2QAwB3gOBaQBMh7gyiMQBrBbhDDuQgZCNAsCNQBZDKg5C/QgSA5gCBDQAKhKApg0QAcglAGhJQAeBIglB6QgZBiAkBeQBiJpq8AqQnxgHA8kXg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#FFFF00","#FFF200","#FF6600"],[0,0.635,0.988],7,19.9,0,7,19.9,47.6).s().p("AiOSqQl7ggAtjwIAFgYQAYiAgyhoIgQgdQhJhfALhZQAkAZgDgVQgBgPABgBIAAABIAAAAQABgDgCgQQgFghAAgTIAAgBIAAgBQgGhCAXg+QAKgdADgoQADgrgDgvQARgJAIAWQAFAHAEAPQAQgtAKgwIgHgXIgBgCQgNgsBDgYIARgGQAngmALhDIABgFQAFgXADgZQAYgDACAbIAagaQAyg3ATiMQAMhJAUg2QAKgHANgDQAmgMgJgaQAhAugaA5IgCAFQgVAhAQAWQACgYAHgVQARgwAsgVQATgPARgRQAogrAehCQACgJgBgLQgDgWACgRQAFgXAZgRQAYg1A9gaIgBAHQgCAVAFANQA5gmAjhaQAOgmAHgwQAGhSghhBQAQAFAHALQA1BEAABeQAGA8AEARQgCAIABAHQAAAqAvBFIAYAdQABAigFAkIAIAMQAvBMgJBoQAHAcgDAlQACAiAPAgQgFBHAIBUQAQBDAEBGQAMB5gIB3QAAAUgDAUQgGA+AABFQAJgjAagRQAFgEADgFQAJgNACgaIADANQAOAQACAkQABATgJAMQgKAdACATQAKApAPApQAUBkgSBbIgSCiQg6FlnnAwQgjABgjAAQgoAAgmgCg");
	this.shape_1.setTransform(-0.1,2.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#FFFF00","#FFF200","#FF6600"],[0,0.635,0.988],7.1,17.4,0,7.1,17.4,47.6).s().p("AhrSUQmZgYAnjzIAFgbQAciIg4hsIgSgdQhEhdAHhpIAAAAQAcAdACgGQACgDADAEIABABIAAAAQAGAHgDgUIgFg3IAAAAIAAgBQgKhDANhEQAHgiACgpQADgxgCgsQAMgUAGAIQAFgFAFACQANgoAPgeQgRgGAPgMIABgBQAGAAAGgDIgLAWQAMAEAdABIASAAQAggpAEhMIABgGIAHgxQASgRAKAHIAbgcQA1gwASifQAJhIAOhCIARAKQAeAQgEAAQAaA+gTAvIADABQACAGASgSQAEgZAGgXQAOg1AjgeIAggnQAggnAigzQgMgIAEgGQAFgEAKgBIAIgCIgPAVIAHADQASg8BJgRIAEAEQAKAPANgBQA1goAjhmQAMgpABgzQABhQgihMQAGgJgBgFQBEBKAJBVQAPA/AaghIAFgDQAWgVBDAkQARAHARAKQgdA9gjBjQADAEgFANQgHALgHAIIARAkQAwBagLBjQASgDAOAAQAQACAagDQgNBFgHBeQADBEgGBOQAACAAJB9QADAVABAVQAFBCADBHQAIAFALARIADAEIAAALIACANQANgOAPAGIACACIgEgKIACAAQAEALgCgBIAVA6QAXBogeBjQgOBbAGBRQgLGfntBDQhJAIhMAAIgKAAgAIcDfIAGAQQgFgBgBgPg");
	this.shape_2.setTransform(-0.1,5.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["#FFFF00","#FFF200","#FF6600"],[0,0.635,0.988],7.1,15.7,0,7.1,15.7,47.6).s().p("AndN/IAEgcQAfiQg9hxIgUgeQg/hbACh4IAAgBIAcApIALAUIAAABIABABQAKAQgDgYIgFg5IAAgCQgPhFAFhJIAEhPQADg4gBgqQAHgfAEgFQAFgQAFgLQAUhBAhgbIgQAcIgCADQglBXBEAbQAJAEAKADQAagsgDhVIABgFQABgcAEgYQAOggARgMQANgPAPgNQA3gsARiwIAPiWIAMAeQAUAsACAaQASBPgKAlIAGgEQAZgUAVg7IAKgzQANg7AZglQAOgaAPgUQAkgzA3hAQgHANgIAMQgRAYgPAbQgOAkAQAlQALhDBVgJIAJADQAWAJAVgQQAxgsAihwQAKgsgDg3QgFhOgkhXQgEgWgJgWQBUBRASBMQAYBCAvhUIAMgUQAthVBVAEQAWgBAXAFQg7AtguBwQgNAfgMAvQgRA3AEA0IAOApQAvBogNBfIA9hHQAeggAmglQgWBCgWBoQgKBGgQBVQgMCGAaCGQAGAWAFAVQAQBGAFBIQAIAugEAyIgDARQgIAfgBAdIABAPQAKgtAdgWQAKgHgCgoIgHhRQAWArANArQAcBrgrBsQgUBeAVBYQAlHZnzBWQhRANhZACQm3gPAij2g");
	this.shape_3.setTransform(-0.2,7.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["#FFFF00","#FFF200","#FF6600"],[0,0.635,0.988],7.2,20.7,0,7.2,20.7,47.6).s().p("AnZObQAiiYhDh2QhPhhgDifQA7CYgEg3IgGg8IABABIgBgBQgdhrAFh/IAGikQAUh4A6gXQhfDjBwAzQATgvgJheIAAgGQgBhtBDgzQBOgzABlXQAnD7gEAuQBDg4AZiYQARhrAig4QAig4BEg+IhHCPQgYBCAMA/QAFhOBuAFQBYAIA2jOQAYh/hmjhQBkBXAaBDQAlBOBTi2QBTi2CPgDQiCAqg/D8QghB5AfB2QAwB3gPBbQBMh7BqiZQgxBohDDuQgYCNArCMQBZDKg5C/QgRA6gCBDQAJhLApgzQAdglgTjEQBfCXhOClQgZBiAkBeQBiJqq8AqQnwgHA8kXg");
	this.shape_4.setTransform(-0.2,2.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["#FFFF00","#FFF200","#FF6600"],[0,0.635,0.988],6.6,28.6,0,6.6,28.6,47.6).s().p("AnfPqQAiiYhDh2QhPhhAQhKQAsAWgHgkIgHgiIABABIgBgBQgdhrArhlQAbhIgDihQAgBiAHBRQATgwgJheIAAgGQgBhtA3g5QBQhWAsh/QAGBMgEAuQBDg4AZiYQAThpAxgoQAvgngMhoQBFBEg/BcQgzA5AMA+QAFhOBNgTQBagrASiDQANipB8hcQgSAfgEAgQBTgTAhiwQALhZgRijQBqDIg/D8QghB6AfB1QAwB3gPBbQBMh7gwjeQB7ClhVD2QgYCNArCNQBZDJg5DAQgRA5gCBDQALhNAogyQAfgmACitQAyChg5CGQgZBiAkBeQBiJqq8AqQnwgHA8kXg");
	this.shape_5.setTransform(0.4,-5.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.rf(["#FFFF00","#FFF200","#FF6600"],[0,0.635,0.988],6.1,34.4,0,6.1,34.4,47.6).s().p("AnkQkQAiiYhDh2QhPhhAQhKQAsAWgHglIgHghIABABIgBgBQgdhsAlhxQAahdAGjfQAeDCAHBQQATgvgJheIAAgHQgBhtArhAQBRh4BOiVQgRCMgEAuQBDg4AZiYQAThpAxgoQAvgogKiaQBfBohVBuQg5A1AMA/QAFhOBNgUQBagqASiDQANipB8hdQgSAggEAgQBOAMAdjRQALhfgCkOQBkE7g/D8QghB5AfB2QAwB3gPBbQBMh7gukvQCKDuhmD+QgYCNArCLQBZDLg5C/QgRA6gCBDQAOhPAmgwQAhgpgBkQQBGD6hNCTQgZBiAkBeQBiJqq8AqQnwgHA8kXg");
	this.shape_6.setTransform(0.9,-11.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["#FFFF00","#FFF200","#FF6600"],[0,0.635,0.988],5.6,40.2,0,5.6,40.2,47.6).s().p("AnpReQAiiYhDh2QhPhhAQhKQAsAWgHglIgHghIABABIgBgBQgdhrAfh9QAZh1APkaQAcEgAHBQQATgvgJheIAAgHQgBhtAfhIQBSiaBxitQgpDOgEAuQBDg4AZiYQAThpAxgoQAvgogJjNQB7CNhrCAQhAAxAMA/QAFhOBNgUQBagqASiDQANipB8hdQgSAggEAgQBIAqAbjxQAKhlANl6QBeGvg/D8QghB5AfB2QAwB3gPBbQBMh7gsmAQCZE3h3EGQgYCNArCLQBZDLg5C/QgRA6gCBDQAQhRAlgvQAigrgDl0QBaFUhhCgQgZBiAkBeQBiJqq8AqQnwgHA8kXg");
	this.shape_7.setTransform(1.4,-17.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.rf(["#FFFF00","#FFF200","#FF6600"],[0,0.635,0.988],5.1,45.9,0,5.1,45.9,47.6).s().p("AnuSXQAiiYhDh2QhPhgAQhLQAsAWgHgkIgHghIABAAIgBgBQgdhrAZiJQAYiKAYlXQAaF/AHBQQATgvgJheIAAgHQgBhuAThPQBUi9CSjCQhAEOgEAtQBDg3AZiYQAThpAxgoQAvgogHkBQCVCyiBCRQhGAvAMA/QAFhOBNgUQBagqASiDQANipB8hdQgSAggEAgQBCBJAZkSQAJhrAbnmQBZIjg/D8QghB5AfB2QAwB3gPBaQBMh6gqnRQCpGAiJEOQgYCMArCMQBZDLg5C/QgRA6gCBDQAShTAkguQAkgtgGnXQBuGth1CtQgZBiAkBeQBiJpq8AqQnwgHA8kXg");
	this.shape_8.setTransform(1.9,-23.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["#FFFF00","#FFF200","#FF6600"],[0,0.635,0.988],5.7,38.2,0,5.7,38.2,47.6).s().p("AnoRKQAiiYhDh2QhOhgAQhLQArAWgHgkIgGghIAAAAIAAgBQgdhrAgh5QAahsAMkHQAdEBAGBQQATgvgJheIAAgHQAAhuAihFQBSiPBlikQggC4gFAuQBDg4AZiYQAThpAxgoQAwgogKi9QBxCBhjB6Qg9AzAMA/QAFhOBMgUQBagqATiDQAMipB9hdQgTAggDAgQBJAgAcjnQAKhjAIlWQBgGJg/D8QghB5AfB2QAwB3gOBaQBMh6gtllQCUEfhxEDQgZCMAsCMQBZDLg5C/QgSA6gCBDQAPhRAmgvQAigrgClSQBTE2haCcQgZBiAkBeQBiJpq8AqQnxgHA8kXg");
	this.shape_9.setTransform(1.2,-15.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.rf(["#FFFF00","#FFF200","#FF6600"],[0,0.635,0.988],6.4,30.5,0,6.4,30.5,47.6).s().p("AnhP9QAiiYhDh2QhOhhAQhKQArAWgHgkIgGgiIAAABIAAgBQgdhrAohpQAbhPAAi2QAgCCAGBRQATgvgJhfIAAgGQAAhuAzg6QBQhiA3iGQgBBhgFAvQBDg4AZiYQAThpAxgoQAwgogMh5QBOBQhHBjQg0A3AMA/QAFhOBMgUQBagrATiCQAMiqB9hcQgTAfgDAhQBRgKAfi6QALhcgLjGQBnDvg/D7QghB6AfB2QAwB3gOBaQBMh7gwj4QCAC9haD4QgZCNAsCNQBZDKg5C/QgSA5gCBDQANhNAngyQAfgnACjOQA4C/g/CLQgZBiAkBeQBiJpq8AqQnxgHA8kXg");
	this.shape_10.setTransform(0.5,-7.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57.4,-123,115,246);


(lib.flame = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF6600").s().p("AncOwQAiiYhDh2QhOhhAQhKQArAWgHgkIgGgiIAAABIAAgBQgdhrAwhZQAcgxgLhlQAiADAGBRQATgvgJhfIAAgGQAAhtBDgyQBOgzAKhoQAeALgFAvQBDg4AZiYQAThpAxgoQAwgogOg1QAqAggpBKQgsA8AMA/QAFhOBMgUQBagrATiCQAMiqB9hcQgTAfgDAhQBZgzAiiPQAMhUgfg2QBvBVg/D7QghB6AfB2QAwB3gOBaQBMh7gyiMQBrBbhDDuQgZCNAsCNQBZDKg5C/QgSA5gCBDQAKhKApg0QAcglAGhJQAeBIglB6QgZBiAkBeQBiJpq8AqQnxgHA8kXg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF6600").s().p("AhoSiQmmgYA3kDIAAgBQAeiGgxhqIgVgnQhIheALhYQAkAZgCgVQgCgQABAAQABgEgCgTQgFghAAgUIABgBIgBgBQgDg8AUg5QANgkACgzQABgigDgkQAWgNAHAmIADALQATg7AIhAIgDgIIAAgDQgOgxA6gUQAXgFAXgNQAfguAEhJIAAgDIADAAQATgBgBAYQAcghAbgsQAkgzAOhSIADgSQAMgUAGgGQAYguAcghQAogqgGg3IgBgCQAjADgZAsQgFAFgDAFQgNAZAUAZQAEgNAFgMQAEgbAnADIAMgCQAdgGAUgaQALgmARglQAIgVAMgSQAmhTBJhqIAMgQQgEAHgCAHQA2g6AMh2IAPgTQAbgrgQgaIgBgCQA3A0AaAbQAUAdAABMQACAXAJAaQgdBGADBbQANBEgBBDQABArgGAoQAZgWALgbQASgegVgnQAJANAHANQBHAkgGBkIgLAjQgcB9AOCWIADASQAfByAOBvQAQBegTBcQgLA9gGBFIADgQQAFgZAXgNIABgBQAWguAOhBIADAEQAaArgfAoIgBADQgBBhAXBgQADAugEAtQgCBZAABPQgZGqomAtIgzABIgwgBg");
	this.shape_1.setTransform(-0.4,4.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF6600").s().p("AnXNeIAAgBQAfiMg3hvIgXgnQhBhcAHhlQAcAcACgGQAAgBABgBQAAAAABAAQAAAAABABQABAAAAABIAAABIABABQAGAIgCgWQgFgpAAgPIAAgBQgIg+AMg+QAHgnACg0QABglgBgjQAPgeAFASIAEgBQAQg7ATguQgRgGASgJIACgBIAEgBIgHARQAIADAPADQAVAIAbgDQAbgugBhQIAAgDIACgBQANgOACAFQAYgpAggoQAwgxAOhUIADgTQASgKACALQAdgoAbgrQAggrAAg7IAAgDQAYgVgEAGIAdABQAFgLAHgKQAAAGALAOIAEAHQALATASADQAJgrAbgdQANgRAVgLQA3g1BCiMIASgiQgJgDgGgGQAfhHgMh5IAUgEQAqgFgCABQAwA6AtgpQAggWAdAlQAOAIAVASQgvA4gRBhQgCBDgIBLIgIBXQAOAJAOAHQAZALgPAAQAGAPAEAPQBJgRAfAQIgNAkQghB2gKCmIABATQAPB3AXB2QAZBhgJBfQgGBCgJBGIgCADQgCABAOAOIABAAIAnhxIAEAAIAEACIgFgWIABABQAZAhgVgMQARBYAJBZQAAAwgLAvQgKBdAMBUQAOHXowA7QgzADg1AAQm/gSA5kJg");
	this.shape_2.setTransform(-0.4,8.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF6600").s().p("AnYNxIAAgBQAhiSg9hyQgOgTgMgVQg6hZAChzIAbAoIAKARIAAABIABABQAMAUgDgaIgFg6IABABIgBgCQgNg+AEhCIAEhgQABgpAAgiQAJguADgDIAEgMQAUhVAlgjIgFAJIgCAEQgoBLAnAlQASAVAfAGQAXgugFhXIAAgCIABgDQAGgcAGgNQAUgwAlgkQA6gvAPhWIADgUQAYABgBAcQAhgkAag0QAaguAFg/IAAgDIAbhHQADgJAFgHQAOgXAogYQAJgMAKgLQgSAegHAoIgEAQQgGAqAPAhQAGgvAngWQATgMAcgFQBHgWA9itQAGgTAFgVQgEgVgHgZQAHhTgkh9IAZALQA7AhAJAdIABACQArBAA/huQAthJA4gCQAbgFAhAJQhBApglBpQgQBBgQBTQgIAugEAtQAFApAQAnQAgA1gIAnQADARAAAQQBKhGBFhEIgPAkQgmBwghC3IgBAUQgCB9AgB8QAkBlgCBhQAABGgMBIIgGAVQgKAdAGAnIAAACQAOg+Adg2IAEgDQAbgKgWhwIgBgFQArBlgCBpQgEAygSAyQgRBfAYBZQAzIFo3BIQg1AGg5ABQnXgNA5kPg");
	this.shape_3.setTransform(-0.4,6.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FF6600").s().p("AnZObQAiiYhDh2QhPhhgDifQA7CYgEg3IgGg8IABABIgBgBQgdhrAFh/IAGikQAUh4A6gXQhfDjBwAzQATgvgJheIAAgGQgBhtBDgzQBOgzALhoQAdAMgEAuQBDg4AZiYQARhrAig4QAig4BEg+IhHCPQgYBCAMA/QAFhOBuAFQBYAIA2jOQAYh/hmjhQBkBXAaBDQAlBOBTi2QBTi2CPgDQiCAqg/D8QghB5AfB2QAwB3gPBbQBMh7BqiZQgxBohDDuQgYCNArCMQBZDKg5C/QgRA6gCBDQAJhLApgzQAdglgTjEQBfCXhOClQgZBiAkBeQBiJqq8AqQnwgHA8kXg");
	this.shape_4.setTransform(-0.2,2.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FF6600").s().p("AktSSQiUg3gFh9QgOhSgBhbQgDhDgag8Iglg/QgvhIAMg7IAAAAQAeAPAFgOQADgIgCgOIgCgFIABABIgBgBIgEgUIgCgMIAAAAIAAgCQgShJAPhJQAIglAPgpQAYg9gGhuQAZgOAHAkIABAKQAQgGgFgwIAAgCQADgaAkgXIACgBIAPgUQAZgZANglIACgEIAEgJQATg0AHg6QAHgBAFABQAPADACAPQBEhOAviYIAFgOQAGgjAegIQATgBAEgRIgBgBQAIgRAAgUQApAJgaAdQgXALAOAdIAEAIQAEgaAKgWQAPgtAoggQAOgNALgRQBHgFADgzQgCgOgEgMQgJgVAPgNIACgBQAQgyArgdQAagWAagYQgHAOAAAJIAIgJQA7hOA5hxIAAgIIAAgJQAMghADghQgCgcgIgdQALACAJADQA9AtgkBAQgFAKgCAJQgFBrAVBkQApCIgMBmQAGgEAEgFQAPgQABgSQgBgYgOgbIALAPQAvBCABBVQAIASgEAdQgFAJgJAKIAAAKIABAMQgLAyAPAgIAPAyQBkDthKDMIAAABQgSBDACBKQAFgNALgJQAQgOAVgJQAbgFACgiQAJAmgEAuQgEAqgJAzIgEAOQgCAKAFAMIACAGQACAjATAHQAMAtgEASQASEaidCFQgsAzgnArQhWBtiqAxQhsAXhjAAQhiAAhZgWg");
	this.shape_5.setTransform(-0.1,0.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FF6600").s().p("AjYTMQi1glgnhrQgvhOAJhsQAFhNgYhDQgQgmgUgjQg5hQANhAIAAgBQAiASABgWQABgLgCgMIgBgFIAAgBIgFgWIgDgNIABAAIgBgCQgQhPAQhVQAIgoAMgxQAUhJAAh4QASgdAHAAIABAKQANAkgBgCIAAACQAGAmAaADIABACIAAAAQAHgMAGgNQATgfAHgtIABgFIACgLQANg+AJg9IAKgIQAPgKAHgCQBHhlBDiXIAIgPQgHAYAOAVQAIAXABgEIAAAAQALgRAGgVQAogOgLgRQgJgbAZAGIAHgEQAGgcAKgaQAOgwAagzQAJgSAHgWIA1AaQASgdAhgQQAggWAagdQAEgDAEgNIAGgMQAqhoBKhlQABgEACgDIAEgDQARgZAKggQABgegDgiQAIgHAHgIQAXgBAGgaQAHBLALBFQAiCZgKBzIAGAJQAGAPgDANQgLAVgCAQIAJATQAwBUgFBWQAOgSAEgLQgDgGgIgFQABALACAGIgEgLIgEgKIAFAEQAAgQABgaIAUA3QBtEQhbDbIAAABQgRBLAHBRQAFAHAMAJQATAJASAMQAZAaAAAFQAEAtgIAxQgIAsgGAzQADgHAMgDIAFgBQAHAHAOgvQAKgJgEgwQAwFKiPCTQgmBCgNA8QgrCoibBWQicBMi9AAQgtAAgugEgAFFzPQABAJACAIQAIAsgGAYQgDgqgCgrg");
	this.shape_6.setTransform(0.2,-3.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FF6600").s().p("AmmTVQhQhLATh9QAOhVgVhKQgOgsgWgoQhEhXAOhFIAAgCQAnAUgDgdIgDgZIgBgGIAAABIAAgBIgGgZIgCgOIAAAAIgBgDQgPhUAShhIAShkQAPhUAGiCQAMgvAFgjIABAMQALBNACArIABAHQAIBoAQAeIABADIAAAAQAGgNAFgRQAMgkABg4IABgFIABgMQAHhKAKg+IAIgRIAcgqIChkSIAJgQQgUBTgBAzIgEA4QAPgRALgWQAoglACg+QAFhCAmgRIAIgRQAJgeALgcIAYh5QAEgYADgbQBfBTgXA4QgFANgJAMIAQgGQAlgVAagiQAPgVAIgkIAFgOQAciLBlhjQgFAHgDAHQgFALgBALQAggbAVgoQAEggABgpIALghQAZgyAEj6IABg1QAOCHAQB2QAaCqgHB/IACAZQgDAvgHAtQgVBBAKA9IAIAVQAvBmgJBYQASg2ANgzQgEgYgNgYIAGAJIAJANQgBhMgHh/IAXA7QB4E0hsDoIAAABQgRBVALBYQAGAaANAbQAWAgAQAiQAXA4gEAtQAAAzgMA0QgNA0gEA+QABgRAFgOQAIgYATgRQAFgEADgGQALgUAKhlQAHhAgDhyQBPF8iCCgQgfBSALBNQABDhiLB8QipCPk3ABQjVgVhKhYg");
	this.shape_7.setTransform(0.9,-13.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FF6600").s().p("AnuSXQAiiYhDh2QhPhgAQhLQAsAWgHgkIgHghIABAAIgBgBIgGgaQgUhhAWh5QAYiKAYlXQAZFyAHBYIABAEIAAABQATgvgJheIAAgHIAAgNQAAhmAShKQBUi9CSjCQg/EKgFAvIAAACQBDg3AZiYQAThpAxgoIAhhdQALhKgEiCQCVCyiBCRQhBAsAGA6IABAIQAFhOBNgUQBagqASiDQANipB8hdQgSAggEAgQArgYAdgtQALgzAIhRQAJhrAbnmQBBGSgQDyIgXCbQghB5AfB2QAwB3gPBaIAti1QgEgogPgqQAMAKAKAMQAFiLgTjPQCpGAiJEOQgYCMArCMQBZDLg5C/QgRA6gCBDQAJhLApg0QAHgIAFgJQAbhUgFmhQBuGth1CtQgZBiAkBeQBiJpq8AqQnwgHA8kXg");
	this.shape_8.setTransform(1.9,-23.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57.4,-123,115,246);


(lib.vapour = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 4
	this.instance = new lib.vapoyure();
	this.instance.parent = this;
	this.instance.setTransform(39,41,0.636,0.636);
	this.instance._off = true;
	this.instance.filters = [new cjs.BlurFilter(5, 5, 1)];
	this.instance.cache(-8,-5,17,11);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(53).to({_off:false},0).to({scaleX:6.05,scaleY:5.83,x:30.8,y:-26.5,alpha:0},59).wait(1));

	// Layer 3
	this.instance_1 = new lib.vapoyure();
	this.instance_1.parent = this;
	this.instance_1.setTransform(13.2,25.3,2.129,2.07);
	this.instance_1.alpha = 0.719;
	this.instance_1.filters = [new cjs.BlurFilter(5, 5, 1)];
	this.instance_1.cache(-8,-5,17,11);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:6.05,scaleY:5.83,x:15.5,y:-20.5,alpha:0},35).to({scaleX:0.64,scaleY:0.64,x:12.2,y:42.7,alpha:1},1).to({scaleX:6.05,scaleY:5.83,x:15.5,y:-20.5,alpha:0},59).to({scaleX:0.64,scaleY:0.64,x:12.2,y:42.7,alpha:1},1).to({scaleX:2.13,scaleY:2.07,x:13.2,y:25.3,alpha:0.719},16).wait(1));

	// Layer 2
	this.instance_2 = new lib.vapoyure();
	this.instance_2.parent = this;
	this.instance_2.setTransform(46.7,8,3.922,3.791);
	this.instance_2.alpha = 0.391;
	this.instance_2.filters = [new cjs.BlurFilter(5, 5, 1)];
	this.instance_2.cache(-8,-5,17,11);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({scaleX:6.05,scaleY:5.83,x:40.6,y:-14.6,alpha:0},17).to({scaleX:0.64,scaleY:0.64,x:56.2,y:42.7,alpha:1},1).to({scaleX:6.05,scaleY:5.83,x:40.6,y:-14.6,alpha:0},59).to({scaleX:0.64,scaleY:0.64,x:56.2,y:42.7,alpha:1},1).to({scaleX:3.92,scaleY:3.79,x:46.7,y:8,alpha:0.391},34).wait(1));

	// Layer 1
	this.instance_3 = new lib.vapoyure();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-17.4,42.7,0.636,0.636);
	this.instance_3.filters = [new cjs.BlurFilter(5, 5, 1)];
	this.instance_3.cache(-8,-5,17,11);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({scaleX:6.05,scaleY:5.83,x:-6,y:-16.6,alpha:0},59).to({scaleX:0.64,scaleY:0.64,x:-17.4,y:42.7,alpha:1},1).to({scaleX:6.05,scaleY:5.83,x:-6,y:-16.6,alpha:0},52).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.4,-10.5,113.4,69.1);


(lib.heat = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.Tween4("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(17.5,-17.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:0,y:0,alpha:0.16},9).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(7.4,-27.5,20.2,20.2);


// stage content:
(lib.icewatervapour_c = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgVAwIAAhdIAKAAIAAAOQAJgRARAAQAFAAACACIAAAKIgHgBQgKAAgGAFQgHAGgDAKIAABAg");
	this.shape.setTransform(135.9,346.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgbAnQgIgIAAgSIAAg8IALAAIAAA7QgBAbAWAAQAWAAAGgTIAAhDIALAAIAABdIgLAAIAAgLQgJANgUAAQgPAAgIgJg");
	this.shape_1.setTransform(127.4,346.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgeAkQgLgNAAgWIAAgBQgBgOAGgLQAFgLAKgGQAJgHAMAAQATAAAMAOQAMAOgBAVIAAABQAAAOgFAMQgFALgKAGQgJAFgNAAQgSAAgMgNgAgWgcQgJAKAAASIAAABQAAARAJALQAJALANAAQAOAAAJgLQAJgLAAgRIAAgBQAAgLgEgKQgEgIgIgFQgHgFgJgBQgNAAgJAMg");
	this.shape_2.setTransform(117.4,346.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AglBDIAAiDIAKAAIAAAOQAKgQATAAQARAAAKANQAJANAAAXIAAACQAAAVgJANQgKANgRAAQgSAAgLgOIAAAxgAgQg0QgHAFgEAJIAAAsQAEAJAHAEQAHAEAJAAQANAAAHgKQAIgLAAgTQAAgSgIgLQgHgKgNAAQgJAAgHAEg");
	this.shape_3.setTransform(107.5,348.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgcApQgJgHAAgMQAAgOALgHQAMgIAUAAIATAAIAAgKQAAgLgHgGQgGgFgMgBQgKAAgHAGQgIAGAAAHIgKAAQAAgKAKgJQALgJAOAAQAQABAKAHQAJAJAAAOIAAAsQAAANADAHIAAABIgMAAQgBgEAAgJQgGAIgJAEQgIADgJAAQgNAAgIgIgAgSAGQgJAFAAAKQAAAIAHAGQAFAFAJAAQAKAAAJgFQAIgGAEgIIAAgUIgTAAQgPAAgJAFg");
	this.shape_4.setTransform(97.4,346.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgEBAIgwh/IAMAAIAoBvIAAADIABgDIAohvIAMAAIgwB/g");
	this.shape_5.setTransform(87.1,344.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgVAwIAAhdIAKAAIAAAOQAJgRARAAQAFAAACACIAAAKIgHgBQgKAAgGAFQgHAGgDAKIAABAg");
	this.shape_6.setTransform(130.9,222.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgSAsQgJgHgFgKQgGgLAAgOIAAgCQAAgOAGgLQAEgLAKgGQAJgHALAAQARAAAKANQAKALAAAVIAAAFIhDAAIAAABQABARAIAKQAKALANAAQAJAAAGgDQAGgDAGgGIAGAEQgMASgVgBQgLAAgLgFgAgSgfQgHAJgDAPIA5AAIAAgBQAAgOgIgJQgIgJgLAAQgLABgJAIg");
	this.shape_7.setTransform(122.8,222.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgBA2QgFgGAAgMIAAg/IgSAAIAAgIIASAAIAAgZIAJAAIAAAZIAUAAIAAAIIgUAAIAAA/QAAAIADAEQADADAHAAIAIgBIABAJQgEACgIAAQgKAAgEgHg");
	this.shape_8.setTransform(114.9,221);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgdApQgIgHAAgMQAAgOAMgHQALgIATAAIATAAIAAgKQAAgLgFgGQgHgFgMgBQgKAAgHAGQgHAGAAAHIgLAAQAAgKALgJQAKgJAPAAQAPABAKAHQAJAJAAAOIAAAsQAAANADAIIAAAAIgLAAQgCgEgBgJQgFAIgIAEQgJADgIAAQgOAAgJgIgAgSAGQgJAFABAKQAAAIAFAGQAGAFAKAAQAJAAAIgFQAJgGADgIIAAgUIgSAAQgPAAgJAFg");
	this.shape_9.setTransform(107.3,222.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AAhBAIgehjIgDgNIgCANIgeBjIgKAAIggh/IALAAIAXBdIAEATIAEgSIAdheIAIAAIAcBeIAEASIAFgTIAWhdIALAAIggB/g");
	this.shape_10.setTransform(94.6,220.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgSArQgJgFgFgMQgGgKAAgOIAAgCQAAgOAGgLQAEgLAKgGQAKgHAKABQARAAAKAMQAKAMAAAUIAAAEIhDAAIAAACQABARAIAKQAKAMANAAQAJAAAGgEQAHgDAFgHIAGAGQgLARgWAAQgMgBgKgGgAgSgeQgIAIgCAOIA5AAIAAgBQAAgNgIgJQgHgJgMABQgLAAgJAJg");
	this.shape_11.setTransform(117,67.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgbAkQgLgNAAgWIAAgCQAAgOAFgLQAFgKAKgHQAJgFALAAQAQAAAKAJQAKAJAAAPIgJAAQgBgKgIgIQgHgGgLAAQgOAAgIAKQgHAKAAASIAAADQAAASAHAKQAIALAOAAQALAAAHgHQAIgGABgKIAJAAQAAAJgFAHQgFAHgIAEQgJAFgJAAQgSAAgLgOg");
	this.shape_12.setTransform(107.8,67.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgFBAIAAh/IAKAAIAAB/g");
	this.shape_13.setTransform(100.7,65.6);

	this.instance = new lib.heat();
	this.instance.parent = this;
	this.instance.setTransform(143.2,66.6,1,1,15);

	this.instance_1 = new lib.heat();
	this.instance_1.parent = this;
	this.instance_1.setTransform(76.8,66.6,1,1,0,-15,165);

	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(108.4,66.5,0.618,0.618);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("rgba(255,255,255,0.18)").ss(1,1,1).p("AkoAkIDwhAQAogKApAGIEQAr");
	this.shape_14.setTransform(109.2,80.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("rgba(0,153,255,0.431)").ss(1,1,1).p("AkhjgIDwhBQAogKApAGIEQAsQALADAAATIAAGXQACAageAOIjsBHQghAKgigIIkcg2QgCAAgCAAQgKgDAAgQIAAmdQAAgZAZgGg");
	this.shape_15.setTransform(108.5,63.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(0,204,255,0.333)").s().p("AgQElIkcg2IgEAAQgKgDAAgQIAAmdQAAgZAZgGIDwhBQAogKApAGIEQAsQALADAAATIAAGXQACAageAOIjsBHQgSAFgTAAQgOAAgQgDgAgxCKIjwBBIDwhBQAZgHAZAAIAZACIAGABIEQAsIkQgsIgGgBIgZgCIAAAAQgZAAgZAHg");
	this.shape_16.setTransform(108.5,63.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("rgba(255,255,255,0.18)").ss(1,1,1).p("AmgABQgOAEAAABQgEABAAAEQAAAFARABQAHAAALgBQABAAABAAIA1ABQARACA9AHQA8AGAgAAQACACAQgCQAdgDAZAAAAWgfQAMgKAwgFQA+gGAVgGQAPgEAWgCQAYgCAQgDQANgDAMgEQAGgDARgGAAUAjQAoAFAMAPQADAEAHAMQAHAKANAJQAXAPAqACQAYABAwgBAESACQAAgFAXgBQALAAAOABQAKAAAPABQAQABAMAAQAfAAANgCQAPgDAAgHQAAgLgcgMQgTgHgOgDAFxhkQABgDAAgDAlYhCQAYAEAIAEQAKAFAAALQAAAKgHAFQgHAGgWAEAlignQAFACAFAB");
	this.shape_17.setTransform(111,93.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(0,204,255,0.333)").s().p("AB9B7QgogJgMgWIgJgRQgHgJgNgFQgggPhdAAQgXAAggAEIgkAEIgHAAIgFAAIgVAAQgogCg5gHQgmgFgvgBQgqAAgTgEQAKgaA/gKIAqgJQATgFAAgJQAAgKgPgKIgOgJQAYAEAIAEQAKAEAAALQAAALgHAFQgHAFgWAEQAWgEAHgFQAHgFAAgLQAAgLgKgEQgIgEgYgEIgIgGQgEgDADgCIAFgEQABgCAIgCIEIgzQApgGAoADIEbAfQAbALAHAFIAQANQAIAIAQAHIAjALQAyARAAAXQAAAQgVAFQgNADgegEIgogFQgJgBgsABQgrACBQAXQCCAcgtAbQgtAahmAFQgnACgeAAQgwAAgZgFgADwB4IgqAAIgeAAQgrgDgXgPQgMgIgIgLIgKgQQgLgPgpgEQApAEALAPIAKAQQAIALAMAIQAXAPArADIAeAAIAqAAgAmNAdIA2ABIBOAIQA8AGAgAAQABACARgCQAdgDAZAAQgZAAgdADQgRACgBgCQggAAg8gGIhOgIIg2gBIgBAAIgTAAQgQgBAAgEQAAgEAEgCIAOgEIgOAEQgEACAAAEQAAAEAQABIATAAIABAAgAEpAIQgWAAAAAGQAAgGAWAAIAEAAIAEAAIAAAAIABAAIAEAAIANAAIAZABIAcABQAfAAANgCQAPgDAAgGQAAgKgdgMQgSgIgPgDQAPADASAIQAdAMAAAKQAAAGgPADQgNACgfAAIgcgBIgZgBIgNAAIgEAAIgBAAIAAAAIgEAAIgEAAgAELhAIgYAIQgQADgYACQgWABgPAEQgVAGg+AGQgwAFgMALQAMgLAwgFQA+gGAVgGQAPgEAWgBQAYgCAQgDIAYgIIAYgJIgYAJg");
	this.shape_18.setTransform(110.9,91.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("rgba(0,153,255,0.431)").ss(1,1,1).p("AJFAAIyJAA");
	this.shape_19.setTransform(110,200.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("rgba(0,153,255,0.431)").ss(3,1,1).p("ApElYIAAD+IAAGTQAAAgAXAAIRbAAQAXAAAAggIAAmTIAAj+");
	this.shape_20.setTransform(110,209.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("rgba(255,255,255,0.431)").ss(1,1,1).p("AEzBFIB+AAAEHhpIB+AAACzAEIB+AAAhzgjIB+AAAgHBTIB9AAAAHhEIB+AAAmvgcIB+AAAl8BqIB/AAAlBAAIB/AA");
	this.shape_21.setTransform(105.6,222.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(0,204,255,0.333)").s().p("AotDaQgWAAgBggIAAmTISIAAIAAGTQABAggXAAgAkpBtIh+AAgABKBXIh9AAgAGFBIIh+AAgAEFAIIh+AAgAjvAEIh+AAgAldgYIh+AAgAgggfIh/AAgABZhAIh9AAgAFZhlIh/AAg");
	this.shape_22.setTransform(110,222.1);

	this.instance_3 = new lib.vapour();
	this.instance_3.parent = this;
	this.instance_3.setTransform(90.1,317.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("rgba(0,153,255,0.431)").ss(1,1,1).p("AJFAAIyJAA");
	this.shape_23.setTransform(110,365.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("rgba(0,153,255,0.431)").ss(3,1,1).p("ApElYIAAFrIAAEmQAAAgAXAAIRbAAQAXAAAAggIAAkmIAAlr");
	this.shape_24.setTransform(110,363.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("rgba(255,255,255,0.431)").ss(1,1,1).p("Al8BXIB/AAAmvguIB+AAAgHBAIB9AAAhzg1IB+AAAAHhWIB+AAAEzAyIB+AAACzgNIB+AAAlBgSIB/AA");
	this.shape_25.setTransform(105.6,378.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(0,204,255,0.333)").s().p("AotCjQgWAAgBghIAAkkISIAAIAAEkQABAhgXAAgAkpA2Ih+AAgABKAfIh9AAgAGFASIh+AAgAEFguIh+AAgAjvgzIh+AAgAldhPIh+AAgAgghWIh/AAgABZh3Ih9AAg");
	this.shape_26.setTransform(110,381.6);

	this.instance_4 = new lib.flamecopy();
	this.instance_4.parent = this;
	this.instance_4.setTransform(106.5,409.6,0.081,0.067,0,-29.7,-18.4);

	this.instance_5 = new lib.flame();
	this.instance_5.parent = this;
	this.instance_5.setTransform(106.4,409.3,0.092,0.077,0,-29.7,-18.4);

	this.instance_6 = new lib.flamecopy2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(106.2,408.8,0.102,0.085,0,-29.7,-18.4);

	this.instance_7 = new lib.flamecopy();
	this.instance_7.parent = this;
	this.instance_7.setTransform(110.1,406.9,0.084,0.084);

	this.instance_8 = new lib.flame();
	this.instance_8.parent = this;
	this.instance_8.setTransform(110.3,406.5,0.095,0.095);

	this.instance_9 = new lib.flamecopy2();
	this.instance_9.parent = this;
	this.instance_9.setTransform(110.3,405.7,0.106,0.106);

	this.instance_10 = new lib.flamecopy();
	this.instance_10.parent = this;
	this.instance_10.setTransform(114.5,406.7,0.084,0.084,23.1);

	this.instance_11 = new lib.flame();
	this.instance_11.parent = this;
	this.instance_11.setTransform(114.8,406.4,0.095,0.095,23.1);

	this.instance_12 = new lib.flamecopy2();
	this.instance_12.parent = this;
	this.instance_12.setTransform(115.1,405.7,0.106,0.106,23.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("rgba(153,0,0,0.431)").ss(1,1,1).p("ABEAkIiHhH");
	this.shape_27.setTransform(116.7,420.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["#FFCC99","#660000"],[0,1],0.6,-1.3,-0.5,1.4).s().p("AhfgmIAMgGICzBIIgxASgAA3AiIiHhHg");
	this.shape_28.setTransform(118,420.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("rgba(153,0,0,0.431)").ss(1,1,1).p("AhDAkICHhH");
	this.shape_29.setTransform(103.3,420.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["#FFCC99","#660000"],[0,1],-0.6,-1.3,0.6,1.4).s().p("AhfAcICzhJIAMAHIiPBUgAg2AiICGhHg");
	this.shape_30.setTransform(102.1,420.8);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("rgba(153,0,0,0.431)").ss(1,1,1).p("AAvAyIhdhj");
	this.shape_31.setTransform(111.5,420.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["#FFCC99","#660000"],[0,1],1,-0.6,-1.5,1.5).s().p("AhLg2IAPgDICIBwIg4ADgAAhAyIhehjg");
	this.shape_32.setTransform(112.9,420.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("rgba(153,0,0,0.431)").ss(1,1,1).p("AguAyIBdhj");
	this.shape_33.setTransform(108.5,420.3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.lf(["#FFCC99","#660000"],[0,1],-1,-0.6,1.5,1.5).s().p("AhLA3ICIhwIAPADIhfBwgAggAyIBehjg");
	this.shape_34.setTransform(107.1,420.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.instance_3},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(153.1,263,133.9,393.4);
// library properties:
lib.properties = {
	id: 'F0355AD083AEC74B882559E7C5BCB10C',
	width: 220,
	height: 460,
	fps: 12,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['F0355AD083AEC74B882559E7C5BCB10C'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;